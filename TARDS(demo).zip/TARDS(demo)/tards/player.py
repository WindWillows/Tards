from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING
from .constants import EVENT_CARD_PLAYED, EVENT_DRAW, EVENT_CARD_ADDED_TO_HAND, EVENT_MILLED, EVENT_DISCARDED, EVENT_BEFORE_POINT
from .cost import Cost
from .cost_modifier import CostModifier, CostModifierSystem
from .cards import Card, Conspiracy, MineralCard, MinionCard, Strategy, Minion

if TYPE_CHECKING:
    from .board import Board
    from .card_db import Pack
    from .cards import Minion
    from .game import Game


def _give_card_to_hand(player: "Player", card_def_name: str, reason: str, game: Optional["Game"] = None):
    from .card_db import DEFAULT_REGISTRY
    card_def = DEFAULT_REGISTRY.get(card_def_name)
    if not card_def:
        return
    card = card_def.to_game_card(player)
    player.add_card_to_hand(card, game=game, reason=reason, emit_events=False)


class Player:
    def __init__(self, side: int, name: str, diver: str, card_deck: List[Card], original_deck_defs: Optional[List[Any]] = None):
        self.side = side
        self.diver = diver
        self.name = name
        self.card_deck = card_deck[:]
        self.card_hand: List[Card] = []
        self.extra_hand: List[Card] = []
        self.card_dis: List[Card] = []
        self.original_deck_defs: List[Any] = list(original_deck_defs) if original_deck_defs else []  # CardDefinition 列表，用于开发
        self.active_conspiracies: List[Conspiracy] = []
        self.health = 30
        self.health_max = 30

        # 资源系统
        self.t_point = 0
        self.t_point_max = 0
        self.c_point = 0
        self.c_point_max = 0
        self.b_point = 0
        self.s_point = 0

        self.card_hand_max = 8
        self.extra_hand_max = 0
        self.draw_fail = 0
        self.bell = False
        self.braked = False
        self.t_changed_this_round = False
        self.board_ref: Optional["Board"] = None

        # 献祭选择器：由外部注入，接收 (required_blood) -> Optional[List[Minion]]
        self.sacrifice_chooser: Optional[Callable[[int], Optional[List["Minion"]]]] = None

        # 沉浸度增益
        self.immersion_points: Dict["Pack", int] = {}
        self.squirrel_deck: List[Card] = []
        self.squirrel_exchanged_this_turn: bool = False
        self.squirrel_draw_enabled: bool = False
        self._cards_played_this_phase: int = 0
        self._underworld_candle_20_given: bool = False
        self._underworld_candle_10_given: bool = False

        # 自动化事件回调（时间节点触发）
        self.on_turn_start: Optional[Callable] = None
        self.on_turn_end: Optional[Callable] = None
        self.on_phase_start: Optional[Callable] = None
        self.on_phase_end: Optional[Callable] = None

        # 部署增益与费用修正（雕像等机制使用）
        self._deploy_buffs: List[Callable[["Minion"], None]] = []
        self._cost_modifier_system = CostModifierSystem()
        # 向后兼容：_cost_modifiers 指向 CostModifierSystem
        self._cost_modifiers = self._cost_modifier_system

        # 通用状态标志（任何卡牌都可以通过 effect_fn / special_fn 设置）
        self._skip_next_draw = False
        self._skip_next_action = False
        self._on_develop_callbacks: List[Callable[["Player", "Game"], None]] = []
        self._double_s_gain: bool = False

    @property
    def minions_on_board(self) -> List["Minion"]:
        """返回该玩家当前在场上的所有异象（动态计算，无需手动同步）。"""
        if self.board_ref:
            return [m for m in self.board_ref.minion_place.values() if m.owner is self]
        return []

    def get_friendly_rows(self) -> tuple:
        return (3, 4) if self.side == 0 else (0, 1)

    def get_enemy_rows(self) -> tuple:
        return (0, 1) if self.side == 0 else (3, 4)

    def health_change(self, delta: int, source: Any = None) -> bool:
        """改变生命值。delta < 0 时表示【受到伤害】，触发伤害替换、血契2级、player_damage 事件。
        delta > 0 时表示恢复生命。
        source: 可选的伤害来源（如攻击者 Minion），用于历史记录追溯。"""
        game = getattr(self.board_ref, "game_ref", None)

        # === BEFORE_HEALTH_CHANGE ===
        if game:
            from .constants import EVENT_BEFORE_HEALTH_CHANGE
            event = game.emit_event(
                EVENT_BEFORE_HEALTH_CHANGE,
                source=source,
                target=self,
                player=self,
                delta=delta,
            )
            if getattr(event, "cancelled", False):
                return False
            delta = event.get("delta", delta)

        actual_delta = delta
        # 伤害替换（"取消该伤害"等机制）：仅对伤害生效
        if delta < 0:
            if game:
                actual_damage = game.apply_damage_replacements(self, -delta, None)
                actual_delta = -actual_damage

        self.health += actual_delta
        if self.health > self.health_max:
            self.health = self.health_max
        if actual_delta > 0:
            print(f"{self.name} 恢复 {actual_delta} 点生命，剩余 {self.health} HP")
        elif actual_delta < 0:
            print(f"{self.name} 受到 {-actual_delta} 点伤害，剩余 {self.health} HP")
            # 血契2级：受到单次≥3伤害时，+3S
            if -actual_delta >= 3:
                from .card_db import Pack
                if self.immersion_points.get(Pack.BLOOD, 0) >= 2:
                    self.s_point += 3
                    print(f"  {self.name} 血契沉浸度触发：受到不小于3点伤害，获得3S")
            if game:
                from .constants import EVENT_PLAYER_DAMAGE
                game.emit_event(EVENT_PLAYER_DAMAGE, source=source, target=self, player=self, damage=-actual_delta)

        # === HEALTH_CHANGED ===
        if game:
            from .constants import EVENT_HEALTH_CHANGED
            game.emit_event(
                EVENT_HEALTH_CHANGED,
                source=None,
                target=self,
                player=self,
                delta=actual_delta,
                old=self.health - actual_delta,
                new=self.health,
            )
            # 记录HP损失到状态日志，用于"本阶段失去HP"类统计
            if hasattr(game, "_state_log") and actual_delta < 0:
                game._state_log.append({
                    "event": "health_lost",
                    "player": self,
                    "amount": -actual_delta,
                    "turn": getattr(game, "current_turn", 0),
                    "phase": getattr(game, "current_phase", ""),
                })

        self._check_underworld_candle()

        if self.health <= 0:
            print(f"{self.name} 战败！")
            return True
        return False

    def lose_hp(self, amount: int) -> bool:
        """【流失生命值】：不受坚韧/伤害替换影响，不触发'受到伤害时'效果（如血契2级、player_damage 事件）。
        抽干卡组的疲劳惩罚、血契1级沉浸度、以及卡牌中'失去X点HP/生命值'的效果应使用此方法。"""
        if amount <= 0:
            return False
        self.health -= amount
        print(f"{self.name} 失去 {amount} 点生命值，剩余 {self.health} HP")

        self._check_underworld_candle()

        if self.health <= 0:
            print(f"{self.name} 战败！")
            return True
        return False

    def _check_underworld_candle(self):
        """冥刻3级：HP≤20给烛烟，HP≤10给大团烛烟。"""
        from .card_db import Pack
        if self.immersion_points.get(Pack.UNDERWORLD, 0) >= 3:
            if self.health <= 20 and not self._underworld_candle_20_given:
                self._underworld_candle_20_given = True
                _give_card_to_hand(self, "烛烟", "冥刻沉浸度触发")
            if self.health <= 10 and not self._underworld_candle_10_given:
                self._underworld_candle_10_given = True
                _give_card_to_hand(self, "大团烛烟", "冥刻沉浸度触发")

    def health_max_change(self, delta: int) -> bool:
        self.health_max += delta
        if self.health > self.health_max:
            self.health = self.health_max
        if delta >= 0:
            print(f"{self.name} 生命上限增加 {delta}，当前生命 {self.health}")
        else:
            print(f"{self.name} 生命上限减少 {-delta}，当前生命 {self.health}")
        if self.health <= 0:
            print(f"{self.name} 战败！")
            return True
        return False

    def _try_stack_to_hand(self, card: "Card") -> Optional["Card"]:
        """尝试将卡牌堆叠到手牌中已有的同名卡牌上（包括矿物手牌区）。
        
        仅当卡牌 stack_limit > 1 且手牌中有同名卡牌未达上限时成功。
        成功时增加目标卡牌的 stack_count，返回被堆叠的目标卡牌。
        失败时返回 None，调用方需要将卡牌 append 到手牌。
        """
        if card.stack_limit <= 1:
            return None
        for existing in self.card_hand + self.extra_hand:
            if existing.name == card.name and existing.stack_count < existing.stack_limit:
                existing.stack_count += 1
                print(f"  {self.name} 的 [{card.name}] 堆叠至 {existing.stack_count}/{existing.stack_limit}")
                return existing
        return None

    def _get_hand_card(self, serial: int) -> Optional[Card]:
        """根据 serial（1-based）获取手牌中的卡牌（涵盖 card_hand + extra_hand）。"""
        if serial < 1:
            return None
        if serial <= len(self.card_hand):
            return self.card_hand[serial - 1]
        idx = serial - len(self.card_hand) - 1
        if idx < len(self.extra_hand):
            return self.extra_hand[idx]
        return None

    def _hand_space_for(self, card: Card) -> tuple[bool, Optional[str]]:
        """检查手牌是否有空间容纳该卡。
        
        返回 (can_add, target)。target 为 "stack" / "mineral" / "normal" / None。
        """
        # 先尝试堆叠
        if card.stack_limit > 1:
            for existing in self.card_hand + self.extra_hand:
                if existing.name == card.name and existing.stack_count < existing.stack_limit:
                    return True, "stack"
        
        if isinstance(card, MineralCard) and len(self.extra_hand) < self.extra_hand_max:
            return True, "mineral"
        
        if len(self.card_hand) < self.card_hand_max:
            return True, "normal"
        
        return False, None

    def add_card_to_hand(self, card: Card, game: Optional["Game"] = None,
                         reason: str = "", emit_events: bool = True,
                         mark_drawn: bool = False) -> Optional[Card]:
        """将卡牌加入手牌（自动处理堆叠、矿物优先入 extra_hand、满牌弃置）。
        
        返回实际生效的 Card 对象（考虑堆叠时返回被堆叠的那张），None 表示因满牌被弃置。
        """
        can_add, target = self._hand_space_for(card)
        
        actual_card = card
        
        if target == "stack":
            for existing in self.card_hand + self.extra_hand:
                if existing.name == card.name and existing.stack_count < existing.stack_limit:
                    existing.stack_count += 1
                    actual_card = existing
                    print(f"  {self.name} 的 [{card.name}] 堆叠至 {existing.stack_count}/{existing.stack_limit}")
                    break
        elif target == "mineral":
            self.extra_hand.append(card)
            card.move_to("hand", game)
        elif target == "normal":
            self.card_hand.append(card)
            card.move_to("hand", game)
        else:
            # 手牌满，弃置
            card.move_to("discard", game)
            self.card_dis.append(card)
            print(f"  {self.name} 手牌已满，{card.name} 被弃置")
            if game and emit_events:
                game.emit_event(EVENT_DISCARDED, player=self, card=card, reason="mill")
                game.emit_event(EVENT_MILLED, player=self, card=card)
            return None
        
        if mark_drawn:
            actual_card._acquired_by_draw = True
        if reason:
            print(f"  {self.name} {reason}：获得 [{card.name}]")
        else:
            print(f"  {self.name} 获得 [{card.name}]")
        if game and emit_events:
            game.emit_event(EVENT_DRAW, player=self, card=card)
            game.emit_event(EVENT_CARD_ADDED_TO_HAND, player=self, card=actual_card, by_draw=mark_drawn)
        return actual_card

    def _compact_extra_hand(self):
        """当 extra_hand 有空位时，将 card_hand 中的矿物移动到 extra_hand。"""
        while len(self.extra_hand) < self.extra_hand_max:
            moved = False
            for card in list(self.card_hand):
                if isinstance(card, MineralCard):
                    self.card_hand.remove(card)
                    self.extra_hand.append(card)
                    print(f"  {self.name} 的 [{card.name}] 从普通手牌区移入矿物手牌区")
                    moved = True
                    break
            if not moved:
                break

    def draw_card(self, amount: int, game: Optional["Game"] = None, deck_owner: Optional["Player"] = None) -> List["Card"]:
        drawn_cards: List["Card"] = []
        deck = (deck_owner or self).card_deck
        while amount > 0:
            if game and game.game_over:
                break
            if len(deck) == 0:
                self.draw_fail += 1
                print(f"  {self.name} 牌库已空，虚空侵蚀！失去 {self.draw_fail} 点生命")
                self.lose_hp(self.draw_fail)
                amount -= 1
                continue
            card = deck.pop()
            stacked = self._try_stack_to_hand(card)
            if stacked is not None:
                # 堆叠成功，不占用新手牌位
                card._acquired_by_draw = True
                drawn_cards.append(stacked)
                amount -= 1
                if game:
                    game.emit_event(EVENT_DRAW, player=self, card=card)
                # 触发"抽取"效果
                draw_trigger = getattr(card, "hidden_keywords", {}).get("抽取")
                if draw_trigger:
                    try:
                        draw_trigger(self, game, card)
                    except Exception as e:
                        print(f"  [抽取效果错误] {card.name}: {e}")
                continue
            
            ok = self.add_card_to_hand(card, game=game, emit_events=True, mark_drawn=True)
            if ok is not None:
                drawn_cards.append(ok)
            else:
                # 手牌满被弃置（磨牌）：仍然返回该卡牌，便于调用方知晓被抽的牌
                drawn_cards.append(card)
            amount -= 1
            # 触发"抽取"效果
            draw_trigger = getattr(card, "hidden_keywords", {}).get("抽取")
            if draw_trigger:
                try:
                    draw_trigger(self, game, card)
                except Exception as e:
                    print(f"  [抽取效果错误] {card.name}: {e}")
        if drawn_cards:
            names = [c.name for c in drawn_cards]
            print(f"  {self.name} 抽取了: {', '.join(names)}")
        return drawn_cards

    def mulligan(self, cards_to_replace: List[Any], game: Optional["Game"] = None):
        """将选中的手牌洗回牌库，然后抽取等量牌。"""
        count = 0
        for card in list(cards_to_replace):
            if card in self.card_hand:
                self.card_hand.remove(card)
                self.card_deck.append(card)
                count += 1
        if count > 0:
            import random
            random.shuffle(self.card_deck)
            from card_pools.effect_utils import clear_shown_in_deck
            clear_shown_in_deck(self)
            print(f"  {self.name} 调整手牌: 将 {count} 张牌洗回牌库并重新抽取")
            self.draw_card(count, game=game)

    def t_point_change(self, delta: int):
        self.t_point += delta
        if self.t_point < 0:
            self.t_point = 0
        if delta != 0:
            self.t_changed_this_round = True
    
    def s_point_change(self, delta: int):
        if delta > 0 and getattr(self, "_double_s_gain", False):
            delta *= 2
            print(f"  {self.name} 双倍血契触发，获得 {delta}S")
        self.s_point += delta
    
    def b_point_change(self, delta: int):
        self.b_point += delta

    def t_point_max_change(self, delta: int):
        """改变T槽上限。减少时记录到 game._state_log 用于全局统计。"""
        old = self.t_point_max
        self.t_point_max = max(0, self.t_point_max + delta)
        actual_delta = self.t_point_max - old
        game = getattr(self.board_ref, "game_ref", None)
        if game:
            from .constants import EVENT_T_MAX_CHANGED
            game.emit_event(
                EVENT_T_MAX_CHANGED,
                player=self,
                old=old,
                new=self.t_point_max,
            )
        if actual_delta < 0 and game and hasattr(game, "_state_log"):
            game._state_log.append({
                "event": "t_max_lost",
                "player": self,
                "amount": abs(actual_delta),
                "turn": getattr(game, "current_turn", 0),
            })

    def c_point_max_change(self, delta: int):
        """改变C槽上限。"""
        old = self.c_point_max
        self.c_point_max = max(0, self.c_point_max + delta)
        actual_delta = self.c_point_max - old
        game = getattr(self.board_ref, "game_ref", None)
        if game:
            from .constants import EVENT_C_MAX_CHANGED
            game.emit_event(
                EVENT_C_MAX_CHANGED,
                player=self,
                old=old,
                new=self.c_point_max,
            )

    def c_point_change(self, delta: int):
        game = getattr(self.board_ref, "game_ref", None)

        # === BEFORE_C_CHANGE ===
        if game and delta != 0:
            from .constants import EVENT_BEFORE_C_CHANGE
            event = game.emit_event(
                EVENT_BEFORE_C_CHANGE,
                source=None,
                target=self,
                player=self,
                delta=delta,
            )
            if getattr(event, "cancelled", False):
                return
            delta = event.get("delta", delta)

        self.c_point += delta
        if self.c_point < 0:
            self.c_point = 0
        if self.c_point_max > 0 and self.c_point > self.c_point_max:
            self.c_point = self.c_point_max

        # === C_CHANGED ===
        if game and delta != 0:
            from .constants import EVENT_C_CHANGED
            game.emit_event(
                EVENT_C_CHANGED,
                source=None,
                target=self,
                player=self,
                delta=delta,
                old=self.c_point - delta,
                new=self.c_point,
            )

    def get_valid_targets(self, card: Card):
        if callable(card.targets):
            return card.targets(self, self.board_ref if self.board_ref else None)
        return card.targets

    def exchange_mineral(self, mineral_card: MineralCard, game: Optional["Game"] = None) -> bool:
        """花费兑换费用获取一张矿物卡并加入手牌（优先放入 extra_hand）。"""
        if not mineral_card.exchange_cost.can_afford(self):
            return False
        if not mineral_card.exchange_cost.pay(self):
            return False
        # 1. 优先在 extra_hand 中堆叠
        stacked = False
        if mineral_card.stack_limit > 1:
            for existing in self.extra_hand:
                if existing.name == mineral_card.name and existing.stack_count < existing.stack_limit:
                    existing.stack_count += 1
                    print(f"  {self.name} 的 [{mineral_card.name}] 堆叠至 {existing.stack_count}/{existing.stack_limit}")
                    stacked = True
                    break
        # 2. extra_hand 未满，直接放入（优先于 card_hand 中的堆叠）
        if not stacked and len(self.extra_hand) < self.extra_hand_max:
            self.extra_hand.append(mineral_card)
            mineral_card.move_to("hand", game)
            print(f"  {self.name} 兑换了 [{mineral_card.name}]")
            if game:
                game.emit_event("mineral_exchanged", player=self, card=mineral_card)
            return True
        # 3. extra_hand 满了，再尝试在 card_hand 中堆叠
        if not stacked and self._try_stack_to_hand(mineral_card):
            mineral_card.move_to("hand", game)
            print(f"  {self.name} 兑换了 [{mineral_card.name}]（堆叠）")
            stacked = True
        # 4. 放入普通手牌区或弃置
        if not stacked:
            self.add_card_to_hand(mineral_card, game=game, reason="兑换了", emit_events=False)
        if game:
            game.emit_event("mineral_exchanged", player=self, card=mineral_card)
        return True

    def _get_play_cost(self, card):
        """获取经过修正后的实际支付费用。"""
        from .cards import MinionCard, Strategy
        # 回响：异象部署花费固定为 2T
        if isinstance(card, MinionCard) and card.keywords.get("回响", False):
            cost = Cost(t=2)
        else:
            cost = card.cost.copy()
        if isinstance(card, (MinionCard, Strategy)):
            # 统一费用修正系统（同时管理玩家级和卡牌级修正）
            self._cost_modifier_system.apply(card, cost)
            # 向后兼容：处理尚未迁移到 CostModifierSystem 的卡牌级裸函数
            for fn in getattr(card, "_card_cost_modifiers", []):
                fn(card, cost)
        return cost

    def card_can_play(self, serial: int, target: Any) -> tuple[bool, str]:
        card = self._get_hand_card(serial)
        if card is None:
            return False, "手牌序号无效"
        cost = self._get_play_cost(card)
        cost = self._get_play_cost(card)
        ok, reason = cost.can_afford_detail(self)
        if not ok:
            return False, reason
        if card.can_play is False:
            return False, "该卡牌当前无法打出（can_play=False）"
        # 绝缘：策略卡无法以对方的绝缘异象为直接目标
        from .cards import Strategy, Minion
        if isinstance(card, Strategy) and isinstance(target, Minion):
            if target.keywords.get("绝缘", False) and target.owner != self:
                return False, f"{target.name} 具有绝缘，无法被策略选中"
            # 虎的全局绝缘：对方无法使用策略指向友方异象
            if target.owner and target.owner != self:
                if getattr(target.owner, "_global_insulation_count", 0) > 0:
                    return False, f"{target.name} 受虎保护，无法被策略选中"
        # 虚化：无法被任何指向性效果选为目标
        if isinstance(target, Minion):
            if target.keywords.get("虚化", False) or target.temp_keywords.get("虚化", False):
                return False, f"{target.name} 处于虚化状态"
        valid_targets = self.get_valid_targets(card)
        if target not in valid_targets:
            return False, "目标位置无效"
        return True, ""

    def discard_card(self, card: Card, game: Optional["Game"] = None, reason: str = "effect") -> None:
        """从手牌中弃置一张卡。触发 EVENT_DISCARDED（正常打出不算弃置）。

        Args:
            card: 要弃置的卡（必须在手牌中）。
            game: Game 实例。
            reason: 弃置原因，"effect" 为效果弃置，"mill" 为手牌满磨牌。
        """
        removed = False
        if card in self.card_hand:
            self.card_hand.remove(card)
            removed = True
        elif card in self.extra_hand:
            self.extra_hand.remove(card)
            removed = True
        if not removed:
            return
        card.move_to("discard", game)
        self.card_dis.append(card)
        if game:
            game.emit_event(EVENT_DISCARDED, player=self, card=card, reason=reason)
        print(f"  {self.name} 弃置了 [{card.name}]")
        if isinstance(card, MineralCard):
            self._compact_extra_hand()

    def _remove_card_from_hand(self, card: Card) -> bool:
        """从手牌中移除一张卡（不触发事件）。返回是否成功移除。"""
        if card in self.card_hand:
            self.card_hand.remove(card)
            return True
        if card in self.extra_hand:
            self.extra_hand.remove(card)
            return True
        return False

    def _add_echo_to_hand(self, echo_card: Card):
        """将回响卡加入手牌（优先普通手牌区）。"""
        if len(self.card_hand) < self.card_hand_max:
            self.card_hand.append(echo_card)
        elif isinstance(echo_card, MineralCard) and len(self.extra_hand) < self.extra_hand_max:
            self.extra_hand.append(echo_card)
        else:
            self.card_hand.append(echo_card)

    def play_card(self, serial: int, target: Any, game: "Game", bluff: bool = False, extra_targets: Optional[List[Any]] = None) -> bool:
        ok, reason = self.card_can_play(serial, target)
        if not ok:
            print(f"  {reason}")
            return False
        card = self._get_hand_card(serial)
        if card is None:
            return False

        # 堆叠处理：若 stack_count > 1，减1并用副本执行效果
        original_card = card
        if getattr(card, "stack_count", 1) > 1:
            card.stack_count -= 1
            import copy
            card = copy.copy(card)
            card.stack_count = 1
            card._is_stack_copy = True
            print(f"  [{original_card.name}] 消耗1张，剩余 {original_card.stack_count} 张")

        # 支付费用（普通资源+CT+矿物）
        cost = self._get_play_cost(card)
        if not cost.pay(self):
            # 费用支付失败，回滚堆叠计数
            if hasattr(card, "_is_stack_copy"):
                original_card.stack_count += 1
            return False
        self._cards_played_this_phase += 1

        # === 若未传入 extra_targets，串行获取 ===
        if extra_targets is None:
            extra_targets = self._resolve_extra_targets(card, game)
            if extra_targets is None:
                # 玩家取消：回滚费用与堆叠计数
                if hasattr(card, "_is_stack_copy"):
                    original_card.stack_count += 1
                self.t_point_change(cost.t)
                self.b_point_change(cost.b)
                self.s_point_change(cost.s)
                self.c_point_change(cost.c)
                cost.rollback(self)
                self._cards_played_this_phase -= 1
                return False

        if isinstance(card, MinionCard):
            card._deploy_target = target
            # 指向异象前的事件（供海市蜃楼等阴谋拦截）
            if target is not None and isinstance(target, Minion):
                event = game.emit_event(EVENT_BEFORE_POINT, source=card, target=target, player=self)
                target = event.data.get("target", target)
            def deploy_fn():
                # 先离开手牌，进入临时结算区（effect 执行时不在手牌中）
                if not getattr(card, "_is_stack_copy", False):
                    self._remove_card_from_hand(card)
                card.move_to("resolving", game)
                effect = card.effect(player=self, target=target, game=game, extra_targets=extra_targets)
                if effect:
                    card.move_to("board", game)
                    if card.echo_level > 0:
                        echo_card = MinionCard(
                            name=card.name,
                            owner=self,
                            cost=Cost(t=2),
                            targets=card.targets,
                            attack=1,
                            health=1,
                            special=card.special,
                            keywords=card.keywords.copy() if card.keywords else None,
                        )
                        echo_card.echo_level = card.echo_level - 1
                        echo_card._is_echo = True
                        self._add_echo_to_hand(echo_card)
                        print(f"  {self.name} 获得异放 [{echo_card.name}]（异放 {echo_card.echo_level}）")
                    game.emit_event(EVENT_CARD_PLAYED, player=self, card=card)
                else:
                    # 部署失败，回滚：卡移回手牌，费用返还
                    if hasattr(card, "_is_stack_copy"):
                        original_card.stack_count += 1
                    else:
                        card.move_to("hand", game)
                        self.card_hand.append(card)
                    self.t_point_change(cost.t)
                    self.b_point_change(cost.b)
                    self.s_point_change(cost.s)
                    self.c_point_change(cost.c)
                    cost.rollback(self)
            game.effect_queue.resolve(f"部署 [{card.name}]", deploy_fn, source=card)
            return True

        elif isinstance(card, (Strategy, MineralCard)):
            is_mineral = isinstance(card, MineralCard)
            # 指向异象前的事件（供海市蜃楼等阴谋拦截）
            if target is not None and isinstance(target, Minion):
                event = game.emit_event(EVENT_BEFORE_POINT, source=card, target=target, player=self)
                target = event.data.get("target", target)

            def play_fn():
                # 先离开手牌，进入临时结算区（effect 执行时不在手牌中）
                if not getattr(card, "_is_stack_copy", False):
                    self._remove_card_from_hand(card)
                card.move_to("resolving", game)
                prev = getattr(game, "_current_strategy_player", None)
                game._current_strategy_player = self
                try:
                    effect = card.effect(player=self, target=target, game=game, extra_targets=extra_targets)
                finally:
                    game._current_strategy_player = prev
                if effect:
                    card.move_to("discard", game)
                    self.card_dis.append(card)
                    game.emit_event(EVENT_CARD_PLAYED, player=self, card=card)
                    if is_mineral:
                        print(f"  {self.name} 因打出矿物，失去所有剩余 C 点")
                        self.c_point = 0
                        self._compact_extra_hand()
                    if card.echo_level > 0:
                        import copy
                        echo_card = copy.copy(card)
                        echo_card.echo_level = card.echo_level - 1
                        self._add_echo_to_hand(echo_card)
                        print(f"  {self.name} 获得异放 [{echo_card.name}]（异放 {echo_card.echo_level}）")
                else:
                    # 效果失败，回滚
                    if hasattr(card, "_is_stack_copy"):
                        original_card.stack_count += 1
                    else:
                        card.move_to("hand", game)
                        self.card_hand.append(card)
                    self.t_point_change(card.cost.t)
                    self.b_point += card.cost.b
                    self.s_point += card.cost.s
                    self.c_point_change(card.cost.c)
                    card.cost.rollback(self)
            game.effect_queue.resolve(f"打出 [{card.name}]", play_fn, source=card)
            return True

        elif isinstance(card, Conspiracy):
            if bluff:
                print(f"  {self.name} 假装激活了 [{card.name}]（虚张声势）")
                return True
            else:
                def activate_fn():
                    # 阴谋激活时同样先离开手牌
                    self._remove_card_from_hand(card)
                    card.move_to("active_conspiracy", game)
                    print(f"  {self.name} 暗中激活了阴谋 [{card.name}]")
                    self.active_conspiracies.append(card)
                    # 注册到事件总线（通配符监听器）
                    game.register_conspiracy(card, self)
                game.effect_queue.resolve(f"激活阴谋 [{card.name}]", activate_fn)
                return True

        return True

    def _resolve_extra_targets(self, card: Card, game: "Game") -> Optional[List[Any]]:
        """串行解析 extra_targeting_stages，返回目标列表；取消返回 None。

        .. deprecated::
            extra_targeting_stages 已废弃。所有部署后的额外指向应在 special_fn / effect_fn
            内部通过 TargetingRequest 完成。保留本函数仅作为向后兼容。
        """
        import warnings
        stages = list(getattr(card, "extra_targeting_stages", []))
        if not stages:
            return []

        warnings.warn(
            "extra_targeting_stages is deprecated. Use internal TargetingRequest instead.",
            DeprecationWarning,
            stacklevel=2,
        )

        from .targeting import TargetingRequest

        results: List[Any] = []
        for stage_def in stages:
            if isinstance(stage_def, (list, tuple)) and len(stage_def) >= 3:
                fn, count, repeat = stage_def[0], stage_def[1], stage_def[2]
            elif isinstance(stage_def, dict):
                fn = stage_def.get("fn")
                count = stage_def.get("count", 1)
                repeat = stage_def.get("repeat", False)
            else:
                continue

            # 单目标：count > 1 拆分为 count 次独立请求
            for i in range(count):
                scope = fn
                # 若不允许重复，排除已选目标
                if not repeat and results:
                    original_fn = fn
                    excluded = list(results)
                    def scope(p, b, orig=original_fn, exc=excluded):
                        return [c for c in orig(p, b) if c not in exc]

                req = TargetingRequest(
                    source=card,
                    scope_fn=scope,
                    prompt=f"[{card.name}] 请选择额外目标 ({i+1}/{count})",
                    deciding_player=self,
                )
                result = game.targeting_system.request_target(req)
                if result is None:
                    return None
                results.append(result)

        return results

    def request_sacrifice(self, required_blood: int) -> Optional[List["Minion"]]:
        """请求玩家选择献祭目标。若外部未注入选择器，返回 None。"""
        if self.sacrifice_chooser:
            return self.sacrifice_chooser(required_blood)
        return None

    def reset_turn_flags(self):
        self.t_changed_this_round = False
        self.bell = False
        self.braked = False
