# 冥刻卡包复杂效果辅助函数
# 该文件不被 translate_packs.py 覆盖，供 underworld.py 引用

from tards.targets import target, target_mix
from card_pools.effect_decorator import special, strategy
from card_pools.effect_utils import (
    add_deathrattle,
    buff_minion,
    convert_cost_to_t,
    create_card_by_name,
    create_echo_card,
    deal_damage_to_minion,
    deal_damage_to_player,
    destroy_minion,
    draw_cards,
    draw_cards_of_type,
    empty_positions,
    gain_keyword,
    gain_resource,
    heal_minion,
    initiate_combat,
    on,
    on_before_attack,
    redirect_damage,
    return_minion_to_hand,
    summon_minion_by_name,
)
from tards import DEFAULT_REGISTRY, Pack, Rarity, CardType
from tards.cards import Minion, MinionCard, Strategy
from tards.constants import EVENT_TURN_START, EVENT_SACRIFICE, EVENT_DISCARDED, EVENT_PHASE_START, EVENT_PHASE_END, EVENT_DEPLOYED, EVENT_AFTER_DESTROY, EVENT_BEFORE_DAMAGE, EVENT_AFTER_ATTACK, EVENT_CARD_PLAYED, EVENT_BEFORE_DESTROY, EVENT_BEFORE_DEPLOY, EVENT_DEATH

SPECIAL_MAP = {
    "松鼠球": "_songshuqiu_special",
    "雕": "_diao_special",
    "鹏": "_peng_special",
    "天牛": "_tianniu_special",
    "寄居蟹": "_jijuxie_special",
    "烛烟": "_zhuyan_special",
    "大团烛烟": "_datuanzhuyan_special",
    "猫": "_mao_special",
    "白鼬": "_baiyou_special",
    "弱狼": "_ruolang_special",
    "西瓜": "_xigua_special",
    "信鸽": "_xinge_special",
    "鸮": "_xiao_special",
    "臭虫": "_chouchong_special",
    "林鼠": "_linshu_special",
    "狐": "_hu_special",
    "13号孩子": "_13_haizi_special",
    "13号": "_13_hao_special",
    "猹": "_cha_special",
    "信天翁": "_xintianweng_special",
    "兀鹫": "_wujiu_special",
    "黑山羊": "_heishanyang_special",
    "兵蚁": "_bingyi_special",
    "嘲鸫": "_chaodong_special",
    "地鼠": "_dishu_special",
    "夜枭": "_yexiao_special",
    "狼": "_lang_special",
    "灰熊": "_huixiong_special",
    "棕熊": "_zongxiong_special",
    "陆龟": "_lugui_special",
    "翠鸟": "_cuiniao_special",
    "鹰": "_ying_special",
    "雀": "_que_special",
    "鹞": "_yao_special",
    "鸥": "_ou_special",
    "雄鹿": "_xionglu_special",
    "雌鹿": "_cilu_special",
    "豪猪": "_haozhu_special",
    "牛蛙": "_niuwa_special",
    "林蛙": "_linwa_special",
    "河狸": "_heli_special",
    "河坝": "_heba_special",
    "蛇": "_she_special",
    "箭毒蛙": "_jianduwa_special",
    "松毛虫": "_songmaochong_special",
    "螳螂": "_tanglang_special",
    "象群": "_xiangqun_special",
    "隼": "_sun_special",
    "鸠": "_jiu_special",
    "幼狼": "_youlang_special",
    "成狼": "_chenglang_special",
    "狼王": "_langwang_special",
    "幼鸟": "_youniao_special",
    "巨蛾": "_ju_e_special",
    "群猿": "_qunyuan_special",
    "鲲": "_kun_special",
    "鹤": "_he_special",
    "鮟鱇": "_ankang_special",
    "食蚁兽": "_shiyi_shou_special",
    "头鹿": "_tou_lu_special",
    "老鹿": "_lao_lu_special",
    "豺": "_chai_special",
    "追猎者": "_zhuiliezhe_special",
    "木鹊": "_muque_special",
    "牛虻": "_niufeng_special",
    "野牛": "_yeniue_special",
    "跳蛛": "_tiaozhu_special",
    "石钱子": "_shiqianzi_special",
    "断尾": "_duanwei_special",
    "蚁穴": "_yixue_special",
}

STRATEGY_MAP = {
    "钳子": "_qianzi_effect",
    "扇子": "_shanzi_strategy",
    "炸弹夫人的遥控器": "_zhadan_yao_effect",
    "胶水": "_jiaoshui_effect",
    "冰块": "_bingkuai_effect",
    "骤雨": "_zhouyu_effect",
    "继代": "_jidai_effect",
    "野火": "_yehuo_effect",
    "善潜": "_shanqian_effect",
    "粗粝": "_culi_effect",
    "新月": "_xinyue_effect",
}

__all__ = [
    "_arthropod_top_effect",
    "_arthropod_bottom_effect",
    "_aquatic_top_effect",
    "_aquatic_bottom_effect",
    "_predator_top_effect",
    "_predator_bottom_effect",
    "_sacrifice_top_effect",
    "_sacrifice_bottom_effect",
    "_avian_top_effect",
    "_avian_bottom_effect",
    "_diao_special",
    "_peng_special",
    "_songshuqiu_special",
    "_jijuxie_special",
    "_tianniu_special",
    "_zhuyan_special",
    "_datuanzhuyan_special",
    "_mao_special",
    "_baiyou_special",
    "_ruolang_special",
    "_xigua_special",
    "_xinge_special",
    "_xiao_special",
    "_chouchong_special",
    "_linshu_special",
    "_hu_special",
    "_hu_tiger_special",
    "_huanxingchong_special",
    "_jin_yachi_strategy",
    "_shanzi_strategy",
    "target_any_minion_or_enemy_player",
    "_jiandao_effect",
    "_fange_effect",
    "_xurui_effect",
    "_moshui_effect",
    "_jinfeng_effect",
    "_liqun_effect",
    "_ruhe_effect",
    "_guaishi_effect",
    "_haishi_effect",
    "_yanxing_effect",
    "_yexi_effect",
    "_songshuping_effect",
    "_shudong_effect",
    "_xueping_effect",
    "_qianzi_effect",
    "_linshu_daobing_effect",
    "_guwang_effect",
    "_guwangzhi_hui_effect",
    "_guwangzhi_shang_effect",
    "_lazhu_effect",
    "_lazhu_cost_modifier",
    "_zhiwuxuejia_effect",
    "_pimaoshang_effect",
    "_lieren_effect",
    "_yugou_effect",
    "_bopidao_effect",
    "_yanping_effect",
    "_lanyue_effect",
    "_zhadan_yao_effect",
    "_xiangji_effect",
    "_shalou_effect",
    "_xueyue_effect",
    "_jiaoshui_effect",
    "_shizhong_effect",
    "_yinghuo_effect",
    "_bingkuai_effect",
    "_mudiaoshi_effect",
    "_muqi_effect",
    "_make_effect",
    "_hanji_effect",
    "_shanhong_effect",
    "_shuiyi_effect",
    "_shachen_effect",
    "_kuangfeng_effect",
    "_gaozhi_effect",
    "_zhouyu_effect",
    "_fansheng_effect",
    "_tudao_effect",
    "_zhenban_effect",
    "_haichen_effect",
    "_jidai_effect",
    "_yehuo_effect",
    "_lunhui_effect",
    "_gengti_effect",
    "_poxiao_effect",
    "_liulinfengsheng_effect",
    "_hesheng_effect",
    "_shanqian_effect",
    "_culi_effect",
    "_xinyue_effect",
    "_fushu_special",
    "_biyi_special",
    "_13_haizi_special",
    "_13_hao_special",
    "_cha_special",
    "_xintianweng_special",
    "_wujiu_special",
    "_heishanyang_special",
    "_bingyi_special",
    "_chaodong_special",
    "_dishu_special",
    "_yexiao_special",
    "_lang_special",
    "_huixiong_special",
    "_zongxiong_special",
    "_lugui_special",
    "_cuiniao_special",
    "_ying_special",
    "_que_special",
    "_yao_special",
    "_ou_special",
    "_xionglu_special",
    "_cilu_special",
    "_haozhu_special",
    "_niuwa_special",
    "_linwa_special",
    "_heli_special",
    "_heba_special",
    "_she_special",
    "_jianduwa_special",
    "_songmaochong_special",
    "_tanglang_special",
    "_xiangqun_special",
    "_sun_special",
    "_jiu_special",
    "_youlang_special",
    "_chenglang_special",
    "_langwang_special",
    "_youniao_special",
    "_chengniao_evolve",
    "_qiguai_de_yong_draw_trigger",
    "_ju_e_special",
    "_qunyuan_special",
    "_kun_special",
    "_he_special",
    "_ankang_special",
    "_shiyi_shou_special",
    "_shiyi_shou_draw_trigger",
    "_tou_lu_special",
    "_lao_lu_special",
    "_lao_lu_evolve",
    "_wujing_effect",
    "_chai_special",
    "_zhuiliezhe_special",
    "_muque_special",
    "_niufeng_special",
    "_yeniue_special",
    "_tiaozhu_special",
    "_guan_special",
    "_yan_special",
    "_mang_effect",
    "_mang_special",
    "_xuebao_special",
    "_shuishiyan_special",
    "_shuixiqun_special",
    "_yachong_special",
    "_wen_special",
    "_luci_special",
    "_hu_special",
    "_sheshei_special",
    "_liegou_special",
    "_shelie_special",
    "_jinyangpi_effect",
    "_shudong_targets",
    "_pimaoshang_choice",
    "_lieren_targets",
    "_yanping_targets",
    "_shalou_cost_modifier",
    "_shizhong_targets",
    "_muqi_targets",
    "_make_targets",
    "_shanhong_targets",
    "_gaozhi_cost_modifier",
    "_zhenban_targets",
    "_haichen_targets",
    "_yehuo_targets",
    "_yehuo_minion_choice",
    "_lunhui_targets",
    "_lunhui_target_choice",
    "_gengti_targets",
    "_liulinfengsheng_targets",
    "_shiqianzi_special",
    "_duanwei_special",
    "_yixue_special",
]






def _arthropod_top_effect(game, top):
    for m in game.board.get_minions_of_player(top.owner):
        if "昆虫" in getattr(m, "tags", []):
            if not m.base_keywords.get("亡语"):
                m.base_keywords["亡语"] = lambda minion, owner, board: None
            m.recalculate()
    opp = game.p1 if top.owner == game.p2 else game.p2
    opp.health_change(-1)


def _arthropod_bottom_effect(game, bottom, top):
    def buff(m):
        if "昆虫" in getattr(m, "tags", []):
            m.perm_attack_bonus += 1
            m.perm_max_health_bonus += 1
            m.perm_health_bonus += 1
            m.recalculate()
    bottom.owner._deploy_buffs.append(buff)


def _aquatic_top_effect(game, top):
    def mod(card, cost):
        aquatic = "两栖" in card.keywords or "水生" in card.keywords or "两栖" in getattr(card, "tags", []) or "水生" in getattr(card, "tags", [])
        if aquatic:
            cost.t = max(0, cost.t - 1)
    top.owner._cost_modifiers.append(mod)


def _aquatic_bottom_effect(game, bottom, top):
    for m in game.board.get_minions_of_player(bottom.owner):
        if "两栖" in m.keywords or "水生" in m.keywords or "两栖" in getattr(m, "tags", []) or "水生" in getattr(m, "tags", []):
            m.base_keywords["先攻"] = 1
            m.recalculate()


def _predator_top_effect(game, top):
    def buff(m):
        if "陆生" in getattr(m, "tags", []) and "肉食动物" in getattr(m, "tags", []):
            m.perm_attack_bonus += 2
            m.perm_max_health_bonus += 1
            m.perm_health_bonus += 1
            m.recalculate()
    top.owner._deploy_buffs.append(buff)


def _predator_bottom_effect(game, bottom, top):
    def mod(card, cost):
        if "陆生" in getattr(card, "tags", []) and "肉食动物" in getattr(card, "tags", []):
            cost.b = max(0, cost.b - 1)
    bottom.owner._cost_modifiers.append(mod)


def _sacrifice_top_effect(game, top):
    def buff(m):
        if m.source_card and m.source_card.cost.b == 0 and not getattr(top.owner, "_fertile_top_used", False):
            top.owner._fertile_top_used = True
            m.base_keywords["献祭"] = m.base_keywords.get("献祭", 0) + 1
            m.recalculate()
    top.owner._deploy_buffs.append(buff)
    old = top.owner.on_turn_start
    def reset(g, e, p):
        p._fertile_top_used = False
        if old:
            old(g, e, p)
    top.owner.on_turn_start = reset


def _sacrifice_bottom_effect(game, bottom, top):
    for m in game.board.get_minions_of_player(bottom.owner):
        if m.source_card and m.source_card.cost.b == 0:
            m.base_keywords["丰饶"] = m.base_keywords.get("丰饶", 0) + 1
            m.recalculate()


def _avian_top_effect(game, top):
    for m in game.board.get_minions_of_player(top.owner):
        if "飞禽" in getattr(m, "tags", []):
            m.base_keywords["迅捷"] = True
            m.recalculate()


def _avian_bottom_effect(game, bottom, top):
    for m in game.board.get_minions_of_player(bottom.owner):
        if "飞禽" in getattr(m, "tags", []):
            m.perm_attack_bonus += 2
            m.recalculate()


# ===== 复杂卡牌手动效果 =====

# 雕(铁) - 先攻3；首次攻击后永久失去先攻3，-3攻击力，获得空袭
def _diao_special(minion, player, game, extras=None):
    minion._diao_triggered = False
    def on_attack(attacker, target):
        if attacker is not minion:
            return
        if getattr(minion, "_diao_triggered", False):
            return
        minion._diao_triggered = True
        fs = minion.keywords.get("先攻", 0)
        if isinstance(fs, int) and fs > 0:
            minion.base_keywords["先攻"] = max(0, fs - 3)
        minion.perm_attack_bonus -= 3
        minion.base_keywords["空袭"] = True
        minion.recalculate()
        print(f"  {minion.name} 首次攻击后失去先攻3，攻击力-3，获得空袭")
    if not hasattr(minion, "_pre_attack_fns"):
        minion._pre_attack_fns = []
    minion._pre_attack_fns.append(on_attack)


# 鹏(铁) - 所有花费≤5的非飞禽异象部署时具有休眠2（不分敌我）；部署：使敌方花费≤4的异象返回手牌
def _peng_special(minion, player, game, extras=None):
    # 部署时：使敌方场上花费≤4的异象返回手牌
    from card_pools.effect_utils import get_all_minions
    enemies = [m for m in get_all_minions(game) if m.owner is not player and m.is_alive()]
    for e in enemies:
        sc = getattr(e, 'source_card', None)
        if sc and sc.cost.t <= 4:
            game.board.remove_minion(e.position)
            bc = e.source_card
            new_card = MinionCard(
                name=bc.name,
                owner=e.owner,
                cost=bc.cost,
                targets=bc.targets,
                attack=bc.attack,
                health=bc.health,
                special=getattr(bc, 'special', None),
                keywords=dict(bc.keywords) if hasattr(bc, 'keywords') else {},
            )
            if hasattr(bc, "tags"):
                new_card.tags = list(bc.tags)
            if len(e.owner.card_hand) < e.owner.card_hand_max:
                e.owner.card_hand.append(new_card)
            else:
                e.owner.card_dis.append(new_card)
            print(f"  {e.name} 被鹏遣返回手牌")

    # 部署钩子：花费≤5的非飞禽异象获得休眠2
    def deploy_hook(g, deployed):
        sc = getattr(deployed, 'source_card', None)
        if sc and sc.cost.t <= 5 and "飞禽" not in getattr(deployed, "tags", []):
            deployed.base_keywords["休眠"] = 2
            deployed.recalculate()
            print(f"  {deployed.name} 因鹏获得休眠2")
    minion.register_deploy_hook(game, deploy_hook)


# 松鼠球(铁) - 受到伤害后向相邻陆地移动一格，在原地留下松鼠
def _songshuqiu_special(minion, player, game, extras=None):
    from card_pools.effect_utils import (
        get_adjacent_positions, move, summon_minion_by_name, add_deathrattle
    )
    import random

    def on_damage():
        if not minion.is_alive():
            return
        adj = get_adjacent_positions(minion.position, game.board)
        candidates = [p for p in adj if p not in game.board.minion_place]
        if not candidates:
            return
        old_pos = minion.position
        new_pos = random.choice(candidates)
        if move(minion, new_pos, game):
            summon_minion_by_name(game, "松鼠", player, old_pos)
    minion._on_take_combat_damage.append(on_damage)

    # 亡语：在原地留下一只松鼠
    def _dr(m, p, b):
        pos = m.position
        g = b.game_ref if hasattr(b, 'game_ref') else None
        if g:
            summon_minion_by_name(g, "松鼠", p, pos)
    add_deathrattle(minion, _dr)


# 寄居蟹(铁) - 回合结束向相邻移动一格；记录被其伤害异象的回响，回合开始时加入手牌再弃掉
@special
def _jijuxie_special(minion, player, game, extras=None):
    """寄居蟹：回合结束：向相邻方向移动一格。将受到其伤害的异象的回响加入手牌，回合开始时弃掉。"""
    from card_pools.effect_utils import get_adjacent_positions, move, create_echo_card
    import random

    _recorded_minions: list = []

    # 记录被寄居蟹伤害的异象
    def on_after_damage(event, g):
        if not minion.is_alive():
            return
        source = event.data.get("source_minion")
        if source is not minion:
            return
        target = event.data.get("target")
        from tards.cards import Minion
        if not isinstance(target, Minion):
            return
        if target not in _recorded_minions:
            _recorded_minions.append(target)
            print(f"  寄居蟹记录了 {target.name} 的回响")

    # 回合结束（结算阶段结束）：移动 + 加入回响
    def on_phase_end(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        if not minion.is_alive():
            return

        # 向相邻方向移动一格
        adj = get_adjacent_positions(minion.position, g.board)
        candidates = [p for p in adj if p not in g.board.minion_place]
        if candidates:
            new_pos = random.choice(candidates)
            if move(minion, new_pos, g):
                print(f"  寄居蟹回合结束移动至 {new_pos}")

        # 将记录的异象回响加入手牌
        for target in list(_recorded_minions):
            _recorded_minions.remove(target)
            if not target.is_alive():
                continue
            source_card = getattr(target, "source_card", None)
            if not source_card:
                continue
            echo = create_echo_card(source_card, echo_level=1)
            echo.owner = player
            echo._jijuxie_echo = True
            player.add_card_to_hand(echo, game=game, emit_events=False)

    # 回合开始（结算阶段开始）：弃掉寄居蟹生成的回响
    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        to_discard = [c for c in player.card_hand if getattr(c, "_jijuxie_echo", False)]
        for card in to_discard:
            player.card_hand.remove(card)
            player.card_dis.append(card)
            card.move_to("discard", game)
            print(f"  寄居蟹：{card.name} 的回响在回合开始时被弃掉")

    game.history.listen("after_damage", on_after_damage, owner=minion)
    game.history.listen(EVENT_PHASE_END, on_phase_end, owner=minion)
    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    return True


@special
def _shelie_special(minion, player, game, extras=None):
    """猞猁：相邻异象受到伤害时，改为由本异象承受。回合结束：若本异象本回合未受到伤害，对对手造成2点伤害。"""
    from card_pools.effect_utils import get_adjacent_positions

    minion._shelie_damaged_this_turn = False

    def on_before_damage(event, g):
        if not minion.is_alive():
            return
        # 防止递归
        if getattr(minion, "_shelie_redirecting", False):
            return

        target = event.data.get("target")
        damage = event.data.get("damage", 0)
        if damage <= 0:
            return
        if not hasattr(target, "position"):
            return

        # 效果1：相邻异象受伤 → 猞猁承受
        adjacent_positions = set(get_adjacent_positions(minion.position, g.board))
        if target.position in adjacent_positions and target is not minion:
            event.cancelled = True
            event.data["damage"] = 0
            print(f"  {target.name} 本应受到 {damage} 点伤害，由猞猁承担")
            minion._shelie_redirecting = True
            try:
                source = event.data.get("source_minion")
                minion.take_damage(damage, source_minion=source)
            finally:
                minion._shelie_redirecting = False
            return

        # 效果2追踪：猞猁自己受伤
        if target is minion:
            minion._shelie_damaged_this_turn = True

    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        minion._shelie_damaged_this_turn = False

    def on_phase_end(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        if not minion.is_alive():
            return
        if minion._shelie_damaged_this_turn:
            return
        opponent = g.p1 if player == g.p2 else g.p1
        opponent.health_change(-2, source=minion)
        print(f"  猞猁本回合未受到伤害，对 {opponent.name} 造成2点伤害")

    game.history.listen("before_damage", on_before_damage, owner=minion)
    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    game.history.listen(EVENT_PHASE_END, on_phase_end, owner=minion)
    return True


# 天牛(铁) - 回合结束：使同列敌方前排异象移动至后排，后排异象返回对方手牌
def _tianniu_special(minion, player, game, extras=None):
    from card_pools.effect_utils import move, return_minion_to_hand

    def on_turn_end(g, e, m=minion):
        col = m.position[1]
        enemies = [x for x in g.board.get_enemy_minions_in_column(col, m.owner) if x.is_alive()]
        if not enemies:
            return
        enemies.sort(key=lambda x: abs(x.position[0] - 2))
        front = enemies[0]
        backs = [x for x in enemies if x is not front]
        # 移动前排到后排（敌方区域的远端）
        enemy_rows = front.owner.get_friendly_rows()
        for r in sorted(enemy_rows, key=lambda x: abs(x - front.position[0]), reverse=True):
            dest = (r, col)
            if dest not in g.board.minion_place:
                move(front, dest, g)
                break
        # 后排返回手牌
        for back in backs:
            if back.is_alive():
                return_minion_to_hand(back, g)
    minion.on_turn_end = on_turn_end


# =============================================================================
# 冥刻包 — 代表性效果（特殊资源机制）
# =============================================================================

def _zhuyan_special(minion, player, game, extras=None):
    """烛烟：亡语：抽1张牌。部署时增加烛烟使用计数。"""
    player._zhuyan_used_count = getattr(player, "_zhuyan_used_count", 0) + 1

    def _dr(m, p, b):
        draw_cards(p, 1, game=b.game_ref if hasattr(b, "game_ref") else None)
    add_deathrattle(minion, _dr)


# =============================================================================
# 新实现 — 简单亡语/回合效果
# =============================================================================

# 西瓜 — 亡语：双方各抽2张牌。
@special
def _xigua_special(minion, player, game, extras=None):
    """西瓜：亡语：双方各抽2张牌。"""
    def _dr(m, p, b):
        g = b.game_ref if hasattr(b, "game_ref") else None
        draw_cards(p, 2, game=g)
        opponent = game.p1 if p == game.p2 else game.p2
        draw_cards(opponent, 2, game=g)
        print(f"  西瓜亡语：双方各抽2张牌")
    add_deathrattle(minion, _dr)


# 信鸽(铁)(I) — 回合结束：返回手牌，抽一张牌。
@special
def _xinge_special(minion, player, game, extras=None):
    """信鸽(铁)(I)：回合结束：返回手牌，抽一张牌。"""
    def on_turn_end(g, event_data, source=minion):
        if not source.is_alive():
            return
        return_minion_to_hand(source, g)
        draw_cards(player, 1, game=g)
        print(f"  信鸽回合结束：返回手牌并抽1张牌")
    minion.on_turn_end = on_turn_end


def _datuanzhuyan_special(minion, player, game, extras=None):
    """大团烛烟：亡语：抽2张牌。部署时增加烛烟使用计数。"""
    player._zhuyan_used_count = getattr(player, "_zhuyan_used_count", 0) + 1

    def _dr(m, p, b):
        draw_cards(p, 2, game=b.game_ref if hasattr(b, "game_ref") else None)
    add_deathrattle(minion, _dr)


def _mao_special(minion, player, game, extras=None):
    """猫(铁)：不会因献祭而被消灭。标记该异象免疫献祭消灭，献祭时只提供B点而不被移除。"""
    minion._immune_to_sacrifice = True


def _baiyou_special(minion, player, game, extras=None):
    """白鼬(铁)：受到战斗伤害后，将其消灭。"""
    def _on_combat_damage():
        if minion.is_alive():
            destroy_minion(minion, game)
            print(f"  白鼬受到战斗伤害后自毁")
    minion._on_take_combat_damage.append(_on_combat_damage)


def _ruolang_special(minion, player, game, extras=None):
    """弱狼(铁)：亡语：造成3点伤害，随机分配至敌方主角与伤害来源。简化实现：3点伤害全部给敌方主角（伤害来源追踪较复杂）。"""
    def _dr(m, p, b):
        opponent = game.p1 if p == game.p2 else game.p2
        # 造成3点伤害给敌方主角
        deal_damage_to_player(opponent, 3, source=m, game=game)
        print(f"  弱狼亡语：对 {opponent.name} 造成3点伤害")
    add_deathrattle(minion, _dr)


@special
def _xiao_special(minion, player, game, extras=None):
    """鸮(铁)：攻击时，改为与目标对战。消灭一个异象后，获得等同于其攻击力的HP。"""
    def _on_before_attack(event):
        attacker = event.data.get("attacker")
        if attacker is not minion:
            return
        # 避免递归：initiate_combat 内部也会触发 before_attack
        if getattr(minion, "_in_initiate_combat", False):
            return
        target = event.data.get("target")
        if not target or not hasattr(target, "is_alive") or not target.is_alive():
            return

        # 记录目标攻击力（用于战后恢复）
        target_atk = getattr(target, "current_attack", 0)

        # 取消原攻击，改为对战
        event.cancelled = True
        print(f"  {minion.name} 攻击时改为与 {target.name} 对战")
        initiate_combat(minion, target, game)

        # 若目标被消灭，恢复HP = 目标攻击力
        if not target.is_alive() and target_atk > 0:
            heal_minion(minion, target_atk)
            print(f"  {minion.name} 消灭目标后恢复 {target_atk} HP")

    on_before_attack(minion, game, _on_before_attack)


# =============================================================================
# 冥刻包 — 新增卡牌效果（臭虫、林鼠、狐、金牙齿、扇子）
# =============================================================================

@special
def _chouchong_special(minion, player, game, extras=None):
    """臭虫：与其同列的敌方异象具有-1攻击力（光环效果）。"""

    def aura_fn(target):
        if not minion.is_alive():
            return 0
        if target.owner is minion.owner:
            return 0
        bug_pos = minion.position
        target_pos = target.position
        if bug_pos is None or target_pos is None:
            return 0
        if bug_pos[1] == target_pos[1]:
            return -1
        return 0

    # 给所有当前敌方异象添加 aura
    for m in game.board.minion_place.values():
        if m.owner is not minion.owner and m.is_alive():
            minion.provide_aura_attack(m, aura_fn)

    # 新部署的敌方异象也获得 aura
    def on_deployed(event):
        deployed = event.data.get("minion")
        if not deployed or not deployed.is_alive():
            return
        if deployed.owner is minion.owner:
            return
        minion.provide_aura_attack(deployed, aura_fn)

    on("deployed", on_deployed, game, minion=minion)


@special
def _linshu_special(minion, player, game, extras=None):
    """林鼠：部署：抉择：抽一张策略，或将1只0T的松鼠加入手牌。"""
    choice = game.request_choice(
        player,
        ["抽一张策略", "将1只0T的松鼠加入手牌"],
        title="林鼠：选择一项",
    )
    if choice == "抽一张策略":
        from tards.cards import Strategy

        drawn = draw_cards_of_type(player, 1, Strategy, game)
        if drawn:
            print(f"  林鼠：{player.name} 抽到策略 {drawn[0].name}")
        else:
            print(f"  林鼠：{player.name} 牌库中没有策略")
    elif choice == "将1只0T的松鼠加入手牌":
        card = create_card_by_name("松鼠", player)
        if card:
            card.cost.t = 0
            player.add_card_to_hand(card, game=game, emit_events=False)


@special
def _hu_special(minion, player, game, extras=None):
    """狐：攻击后，获得+1攻击力。免疫偶数伤害。"""
    # 免疫偶数伤害
    redirect_damage(minion, lambda d, s: d % 2 == 0, 0, "even_immunity")
    print(f"  狐：{minion.name} 免疫偶数伤害")

    # 攻击后永久+1攻击力
    def on_after_attack(event):
        attacker = event.data.get("attacker")
        if attacker is not minion:
            return
        if not minion.is_alive():
            return
        buff_minion(minion, atk_delta=1, permanent=True)
        print(f"  狐：{minion.name} 攻击后获得+1攻击力")

    on("after_attack", on_after_attack, game, minion=minion)


@special
def _cha_special(minion, player, game, extras=None):
    """"猹"：回合结束：场上异象更少的一方抽一张牌。亡语：将一张"西瓜"加入原位。"""

    def _on_turn_end_fn(event):
        if not minion.is_alive():
            return
        friendly_count = len([m for m in game.board.minion_place.values() if m.owner == player and m.is_alive()])
        opponent = game.p1 if player == game.p2 else game.p2
        enemy_count = len([m for m in game.board.minion_place.values() if m.owner == opponent and m.is_alive()])

        if friendly_count < enemy_count:
            draw_cards(player, 1, game)
            print(f'  "猹"回合结束：友方异象更少，{player.name} 抽1张牌')
        elif enemy_count < friendly_count:
            draw_cards(opponent, 1, game)
            print(f'  "猹"回合结束：敌方异象更少，{opponent.name} 抽1张牌')
        # 相等时不触发

    from card_pools.effect_utils import on_turn_end
    on_turn_end(minion, game, _on_turn_end_fn)

    def deathrattle(m, p, board):
        death_pos = m.position
        if death_pos and death_pos not in game.board.minion_place:
            result = summon_minion_by_name(game, "西瓜", p, death_pos)
            if result:
                print(f'  "猹"亡语：将西瓜加入原位 {death_pos}')
                return

        # 原位不可用，随机选合法空位
        valid_positions = empty_positions(p, board)
        if valid_positions:
            import random
            pos = random.choice(valid_positions)
            result = summon_minion_by_name(game, "西瓜", p, pos)
            if result:
                print(f'  "猹"亡语：原位被占，将西瓜加入 {pos}')
        else:
            print(f'  "猹"亡语：没有合法空位，无法召唤西瓜')

    add_deathrattle(minion, deathrattle)
    return True


@special
def _bingyi_special(minion, player, game, extras=None):
    """兵蚁：场上每有一个友方昆虫异象，+1攻击力。"""
    def insect_count(m):
        if not m.is_alive():
            return 0
        return sum(1 for x in m.board.minion_place.values()
                   if x.owner == m.owner and x.is_alive() and "昆虫" in getattr(x, "tags", []))

    minion.add_aura_attack(insect_count)
    return True


@special
def _dishu_special(minion, player, game, extras=None):
    """地鼠：如可能，移动以承担指向友方目标的伤害。回合结束：将HP改为6。"""
    friendly_rows = player.get_friendly_rows()
    front_row = friendly_rows[0]  # 靠近敌方的那一行

    def on_before_attack(event):
        if not minion.is_alive():
            return
        attacker = event.data.get("attacker")
        target = event.data.get("target")
        if attacker is None or target is None:
            return
        # 只拦截敌方异象的攻击
        if not hasattr(attacker, "owner") or attacker.owner == player:
            return

        move_to = None

        if hasattr(target, "is_alive") and hasattr(target, "owner"):
            # 目标是异象
            if target.owner != player:
                return
            target_row = target.position[0]
            if target_row == front_row:
                return  # 目标在前排，无法挡刀
            col = target.position[1]
            move_to = (front_row, col)
        else:
            # 目标是玩家
            from tards.player import Player
            if not isinstance(target, Player):
                return
            col = attacker.position[1]
            move_to = (front_row, col)

        # 地鼠已在该位置，直接替挡
        if minion.position == move_to:
            event.data["target"] = minion
            event.data["defender"] = minion
            print(f"  地鼠在 {move_to} 替 {getattr(target, 'name', target)} 挡刀")
            return

        # 位置被占，无法移动
        if move_to in game.board.minion_place:
            return

        # 尝试移动
        if game.board.move_minion(minion, move_to):
            event.data["target"] = minion
            event.data["defender"] = minion
            print(f"  地鼠移动到 {move_to} 替 {getattr(target, 'name', target)} 挡刀")

    on("before_attack", on_before_attack, game, minion=minion)

    # 回合结束：HP重置为6
    def on_turn_end_fn(event):
        if not minion.is_alive():
            return
        minion.perm_max_health_bonus = 0
        minion.temp_max_health_bonus = 0
        minion._aura_max_health_fns.clear()
        minion.current_max_health = minion.base_max_health
        minion.current_health = minion.base_max_health
        minion.recalculate()
        print(f"  地鼠回合结束：HP重置为 {minion.current_health}/{minion.current_max_health}")

    from card_pools.effect_utils import on_turn_end
    on_turn_end(minion, game, on_turn_end_fn)
    return True


@special
def _yexiao_special(minion, player, game, extras=None):
    """夜枭：敌方场上异象数量变化时，对对手造成1点伤害。"""
    opponent = game.p1 if player == game.p2 else game.p2

    def on_entered(event):
        if not minion.is_alive():
            return
        entered = event.data.get("minion")
        if entered and hasattr(entered, "owner") and entered.owner == opponent:
            opponent.health_change(-1)
            print(f"  夜枭：{entered.name} 进入战场，对 {opponent.name} 造成 1 点伤害")

    def on_left(event):
        if not minion.is_alive():
            return
        left = event.data.get("minion")
        if left and hasattr(left, "owner") and left.owner == opponent:
            opponent.health_change(-1)
            print(f"  夜枭：{left.name} 离开战场，对 {opponent.name} 造成 1 点伤害")

    on("entered_battlefield", on_entered, game, minion=minion)
    on("removed", on_left, game, minion=minion)
    return True


@special
def _lang_special(minion, player, game, extras=None):
    """狼：攻击时跳过HP不大于2的异象。回合开始：对本列除自身外的一个异象造成2点伤害。（效果预设）"""
    from card_pools.effect_utils import set_effect_target_scope, get_effect_target
    from tards.cards import Minion

    # 攻击目标过滤：跳过HP <= 2的异象
    def _filter(target):
        return target.current_health > 2
    minion._attack_target_filter = _filter
    print("  狼：攻击时跳过HP不大于2的异象")

    # 回合开始：对本列除自身外的一个异象造成2点伤害
    def _scope(p, board):
        col = minion.position[1] if minion.position else -1
        return [m for m in board.minion_place.values()
                if m.is_alive() and m.position[1] == col and m is not minion]

    set_effect_target_scope(minion, _scope)

    def on_turn_start_fn(event):
        if not minion.is_alive():
            return
        target = get_effect_target(minion, game=game)
        if target is None:
            return
        if isinstance(target, Minion) and target.is_alive():
            target.take_damage(2, source_minion=minion, source_type="effect")
            print(f"  狼回合开始：对 {target.name} 造成 2 点伤害")

    from card_pools.effect_utils import on_turn_start
    on_turn_start(minion, game, on_turn_start_fn)
    return True


@special
def _huixiong_special(minion, player, game, extras=None):
    """灰熊：对方从手牌部署异象时，对方失去1T。"""
    opponent = game.p1 if player == game.p2 else game.p2

    def on_deployed(event):
        if not minion.is_alive():
            return
        deployed_player = event.data.get("player")
        deployed_minion = event.data.get("minion")
        if deployed_player is None or deployed_minion is None:
            return
        if deployed_player == opponent:
            opponent.t_point_change(-1)
            print(f"  灰熊：{deployed_minion.name} 部署，{opponent.name} 失去 1T")

    on("deployed", on_deployed, game, minion=minion)
    return True


@special
def _zongxiong_special(minion, player, game, extras=None):
    """棕熊：对攻击力≤3的异象伤害+2。"""
    def on_before_damage(event):
        if not minion.is_alive():
            return
        source = event.data.get("source_minion")
        if source is not minion:
            return
        target = event.data.get("target")
        if target is None or not hasattr(target, "current_attack"):
            return
        if target.current_attack <= 3:
            old_damage = event.data.get("damage", 0)
            event.data["damage"] = old_damage + 2
            print(f"  棕熊：对 {target.name}（攻击力{target.current_attack}）伤害+2，从 {old_damage} 提升至 {old_damage + 2}")

    on("before_damage", on_before_damage, game, minion=minion)
    return True


@special
def _lugui_special(minion, player, game, extras=None):
    """陆龟：处于协同时，受到的战斗伤害翻倍。（先翻倍再坚韧）"""
    def on_before_damage(event):
        if not minion.is_alive():
            return
        target = event.data.get("target")
        if target is not minion:
            return
        if not event.data.get("is_combat_damage", False):
            return
        col = minion.position[1] if minion.position else -1
        if col < 0:
            return
        # 检查同列是否有其它友方存活异象
        has_synergy = any(
            m.is_alive() and m is not minion and m.position[1] == col
            for m in game.board.get_minions_in_column(col, friendly_to=player)
        )
        if has_synergy:
            old_damage = event.data.get("damage", 0)
            event.data["damage"] = old_damage * 2
            print(f"  陆龟处于协同：战斗伤害从 {old_damage} 翻倍至 {old_damage * 2}")

    on("before_damage", on_before_damage, game, minion=minion)
    return True


@special
def _cuiniao_special(minion, player, game, extras=None):
    """翠鸟：部署：若在水路，获得潜水和空袭。"""
    if minion.position and minion.position[1] == 4:
        minion.base_keywords["潜水"] = True
        minion.base_keywords["空袭"] = True
        minion.recalculate()
        print(f"  翠鸟部署于水路，获得潜水和空袭")
    return True


@special
def _ying_special(minion, player, game, extras=None):
    """鹰：受到其伤害的目标此前每被本异象攻击过一次，受到的伤害+1。（跨回合累计）"""
    if not hasattr(minion, "_ying_attack_count"):
        minion._ying_attack_count = {}

    def on_after_attack(event):
        attacker = event.data.get("attacker")
        target = event.data.get("target")
        if attacker is not minion:
            return
        if target is not None:
            minion._ying_attack_count[target] = minion._ying_attack_count.get(target, 0) + 1

    def on_before_damage(event):
        if not minion.is_alive():
            return
        source = event.data.get("source_minion")
        if source is not minion:
            return
        target = event.data.get("target")
        if target is None:
            return
        if not event.data.get("is_combat_damage", False):
            return
        count = minion._ying_attack_count.get(target, 0)
        if count > 0:
            old_damage = event.data.get("damage", 0)
            event.data["damage"] = old_damage + count
            print(f"  鹰：对 {getattr(target, 'name', target)} 此前攻击过 {count} 次，伤害从 {old_damage} 提升至 {old_damage + count}")

    on("after_attack", on_after_attack, game, minion=minion)
    on("before_damage", on_before_damage, game, minion=minion)
    return True


@special
def _que_special(minion, player, game, extras=None):
    """雀：部署时：将其复制加入战场。回合结束：将其复制加入战场。（需本结算阶段开始时存在，玩家指定位置）"""
    from card_pools.effect_utils import empty_positions, summon_minion_by_name, set_effect_target_scope, get_effect_target

    def _summon_copy(target_pos):
        if target_pos is None:
            return
        summon_minion_by_name(game, "雀", player, target_pos)

    # 部署时复制（部署时刻可以同步指向）
    from tards.targeting import TargetingRequest
    valid_deploy = empty_positions(player, game.board)
    if valid_deploy:
        req = TargetingRequest()
        req.source = minion
        req.scope_fn = lambda p, b: valid_deploy
        req.prompt = "雀：选择一个友方空位，将其复制加入战场"
        req.deciding_player = player
        pos = game.targeting_system.request_target(req)
        _summon_copy(pos)

    # 回合结束复制：采用效果预设机制（出牌阶段预设空位）
    set_effect_target_scope(minion, lambda p, board: empty_positions(p, board))

    def on_turn_start(g, event_data, m):
        m._existed_at_resolve_start = True

    def on_turn_end(g, event_data, m):
        if not getattr(m, "_existed_at_resolve_start", False):
            return
        m._existed_at_resolve_start = False
        if not m.is_alive():
            return
        # 仅拥有者回合结束触发
        if event_data.get("first") is not player:
            return
        target_pos = get_effect_target(m, game=g)
        if target_pos is None:
            return
        _summon_copy(target_pos)

    minion.on_turn_start = on_turn_start
    minion.on_turn_end = on_turn_end
    return True


@special
def _yao_special(minion, player, game, extras=None):
    """鹞：受到伤害时，改为失去1点HP。无法获得HP（含最大生命值加成）。"""
    def on_before_damage(event):
        if not minion.is_alive():
            return
        target = event.data.get("target")
        if target is not minion:
            return
        if getattr(event, "cancelled", False):
            return
        event.cancelled = True
        minion.current_health -= 1
        print(f"  鹞：受到伤害改为失去1HP，当前HP {minion.current_health}/{minion.current_max_health}")
        if minion.current_health <= 0:
            minion.minion_death()

    on("before_damage", on_before_damage, game, minion=minion)

    # 阻止治疗
    def blocked_heal(heal):
        print(f"  鹞无法获得HP，治疗被阻止")
        return
    minion.minion_heal = blocked_heal

    # 阻止最大生命值加成
    def blocked_gain(delta, permanent=True):
        print(f"  鹞无法获得HP，生命值加成被阻止")
        return
    minion.gain_health_bonus = blocked_gain

    return True


@special
def _ou_special(minion, player, game, extras=None):
    """鸥：免疫非战斗伤害。亡语：抽1张异象，使其具有两栖。"""
    # 免疫非战斗伤害
    def on_before_damage(event):
        if not minion.is_alive():
            return
        target = event.data.get("target")
        if target is not minion:
            return
        if not event.data.get("is_combat_damage", False):
            event.cancelled = True
            print(f"  鸥免疫非战斗伤害")

    on("before_damage", on_before_damage, game, minion=minion)

    # 亡语：抽1张异象，使其具有两栖
    def deathrattle(m, p, board):
        from tards.cards import MinionCard
        drawn_idx = None
        drawn = None
        for i, card in enumerate(p.card_deck):
            if isinstance(card, MinionCard):
                drawn_idx = i
                drawn = card
                break
        if drawn is None:
            print("  鸥亡语：牌库中没有异象")
            return
        p.card_deck.pop(drawn_idx)
        p.add_card_to_hand(drawn, game=game, emit_events=False)
        drawn.keywords["两栖"] = True

    add_deathrattle(minion, deathrattle)
    return True


@special
def _xionglu_special(minion, player, game, extras=None):
    """雄鹿：无法攻击对手。回合结束：若本回合未受到伤害，获得+1/1并对对手造成等同于其攻击力的伤害。"""
    # 无法攻击对手
    def on_before_attack(event):
        if not minion.is_alive():
            return
        if event.data.get("attacker") is not minion:
            return
        target = event.data.get("target")
        from tards.player import Player
        if isinstance(target, Player):
            event.cancelled = True
            print("  雄鹿无法攻击对手")

    on("before_attack", on_before_attack, game, minion=minion)

    # 追踪本回合是否受到伤害
    def on_damaged(event):
        if event.data.get("target") is not minion:
            return
        minion._took_damage_this_turn = True

    on("damaged", on_damaged, game, minion=minion)

    # 回合结束效果
    def on_turn_end(g, event_data, m):
        if not m.is_alive():
            return
        # 仅拥有者回合结束触发
        if event_data.get("first") is not m.owner:
            return
        took_damage = getattr(m, "_took_damage_this_turn", False)
        m._took_damage_this_turn = False
        if not took_damage:
            m.perm_attack_bonus += 1
            m.perm_max_health_bonus += 1
            m.current_health += 1
            m.recalculate()
            opponent = g.p1 if m.owner == g.p2 else g.p2
            opponent.health_change(-m.current_attack, source=m)
            print(f"  雄鹿回合结束：+1/1，对 {opponent.name} 造成 {m.current_attack} 点伤害")

    minion.on_turn_end = on_turn_end
    return True


@special
def _cilu_special(minion, player, game, extras=None):
    """雌鹿：攻击力最高的敌方异象无法攻击。"""
    def on_before_attack(event):
        if not minion.is_alive():
            return
        attacker = event.data.get("attacker")
        if attacker is None or not hasattr(attacker, "owner") or attacker.owner == player:
            return
        enemies = [x for x in game.board.minion_place.values() if x.owner != player and x.is_alive()]
        if not enemies:
            return
        max_attack = max(x.current_attack for x in enemies)
        if attacker.current_attack == max_attack:
            event.cancelled = True
            print(f"  雌鹿：{attacker.name} 攻击力最高，无法攻击")

    on("before_attack", on_before_attack, game, minion=minion)
    return True


@special
def _haozhu_special(minion, player, game, extras=None):
    """豪猪：受到伤害后，对伤害来源造成等量伤害（原始伤害）。"""
    def on_damaged(event):
        if not minion.is_alive():
            return
        target = event.data.get("target")
        if target is not minion:
            return
        # 防止反弹循环
        if event.data.get("source_type") == "rebound":
            return
        source = event.data.get("source_minion")
        original = event.data.get("original", 0)
        if original <= 0:
            return
        if source and hasattr(source, "is_alive") and source.is_alive():
            source.take_damage(original, source_minion=minion, source_type="rebound", is_combat_damage=False)
            print(f"  豪猪反弹：对 {source.name} 造成 {original} 点伤害")

    on("damaged", on_damaged, game, minion=minion)
    return True


@special
def _niuwa_special(minion, player, game, extras=None):
    """牛蛙：部署：将其复制加入同一列，使其具有迅捷。"""
    from card_pools.effect_utils import summon_minion_by_name
    col = minion.position[1] if minion.position else -1
    if col < 0:
        return True
    friendly_rows = player.get_friendly_rows()
    target_pos = None
    for r in friendly_rows:
        pos = (r, col)
        if pos != minion.position and pos not in game.board.minion_place:
            target_pos = pos
            break
    if target_pos is None:
        print("  牛蛙：同列没有友方空位，无法召唤复制")
        return True
    new_minion = summon_minion_by_name(game, "牛蛙", player, target_pos)
    if new_minion:
        new_minion.keywords["迅捷"] = True
        new_minion.recalculate()
        print(f"  牛蛙：在同一列 {target_pos} 召唤复制，使其具有迅捷")
    return True


@special
def _linwa_special(minion, player, game, extras=None):
    """林蛙：部署：消灭场上攻击力最低的异象（不含自身），获得其攻击力与防御力（叠加）。"""
    candidates = [m for m in game.board.minion_place.values() if m.is_alive() and m is not minion]
    if not candidates:
        print("  林蛙：场上没有其他异象")
        return True
    min_attack = min(m.current_attack for m in candidates)
    target = next(m for m in candidates if m.current_attack == min_attack)

    target_atk = target.current_attack
    target_hp = target.current_health

    from card_pools.effect_utils import destroy_minion
    destroy_minion(target, game)
    print(f"  林蛙：消灭 {target.name}（{target_atk}/{target_hp}）")

    minion.perm_attack_bonus += target_atk
    minion.perm_max_health_bonus += target_hp
    minion.current_health += target_hp
    minion.recalculate()
    print(f"  林蛙：获得 +{target_atk}攻击 +{target_hp}生命，当前 {minion.current_attack}/{minion.current_health}")
    return True


@special
def _heli_special(minion, player, game, extras=None):
    """河狸：回合开始：将一张"河坝"加入对方手牌。"""
    opponent = game.p1 if player == game.p2 else game.p2

    def on_turn_start(g, event_data, m):
        if not m.is_alive():
            return
        from tards.card_db import DEFAULT_REGISTRY
        heba_def = DEFAULT_REGISTRY.get("河坝")
        if not heba_def:
            print("  河狸：找不到河坝定义")
            return
        heba_card = heba_def.to_game_card(opponent)
        opponent.add_card_to_hand(heba_card, game=game, emit_events=False)

    minion.on_turn_start = on_turn_start
    return True


@special
def _heba_special(minion, player, game, extras=None):
    """河坝：回合开始：将其消灭。"""
    def on_turn_start(g, event_data, m):
        if not m.is_alive():
            return
        from card_pools.effect_utils import destroy_minion
        destroy_minion(m, game)
        print(f"  河坝回合开始：自我消灭")

    minion.on_turn_start = on_turn_start
    return True


@special
def _she_special(minion, player, game, extras=None):
    """蛇：对HP不小于本异象的目标，伤害+1。亡语：对全体敌方目标造成1点伤害。"""
    def on_before_damage(event):
        if not minion.is_alive():
            return
        source = event.data.get("source_minion")
        if source is not minion:
            return
        target = event.data.get("target")
        if target is None:
            return
        target_hp = getattr(target, "current_health", getattr(target, "health", 0))
        if target_hp >= minion.current_health:
            old_damage = event.data.get("damage", 0)
            event.data["damage"] = old_damage + 1
            print(f"  蛇：目标HP({target_hp})不小于自身HP({minion.current_health})，伤害+1")

    on("before_damage", on_before_damage, game, minion=minion)

    def deathrattle(m, p, board):
        opponent = game.p1 if p == game.p2 else game.p1
        from card_pools.effect_utils import deal_damage_to_minion, all_enemy_minions
        for enemy in all_enemy_minions(game, p):
            if enemy.is_alive():
                deal_damage_to_minion(enemy, 1, source=m, game=game)
        opponent.health_change(-1, source=m)
        print(f"  蛇亡语：对全体敌方目标造成1点伤害")

    add_deathrattle(minion, deathrattle)
    return True


@special
def _jianduwa_special(minion, player, game, extras=None):
    """箭毒蛙：对对手造成的伤害翻倍。亡语：对方所有手牌花费+1T。"""
    def on_before_health_change(event):
        if not minion.is_alive():
            return
        source = event.data.get("source")
        if source is not minion:
            return
        target = event.data.get("target")
        if target is None:
            return
        # 确认目标是对手玩家（不是异象）
        opponent = game.p2 if player == game.p1 else game.p1
        if target is not opponent:
            return
        delta = event.data.get("delta", 0)
        if delta < 0:
            event.data["delta"] = delta * 2
            print(f"  {minion.name}：对对手造成的伤害翻倍，从 {-delta} 变为 {-delta * 2}")

    on("before_health_change", on_before_health_change, game, minion=minion)

    def deathrattle(m, p, g):
        opponent = g.p2 if p == g.p1 else g.p1
        for card in opponent.card_hand:
            card.cost.t += 1
            card._jianduwa_extra_t = getattr(card, '_jianduwa_extra_t', 0) + 1
        print(f"  {m.name} 亡语：{opponent.name} 所有手牌花费 +1T")

        def on_card_leave(event):
            card = event.data.get("card")
            if card and hasattr(card, '_jianduwa_extra_t'):
                card.cost.t -= card._jianduwa_extra_t
                del card._jianduwa_extra_t

        if not getattr(opponent, '_jianduwa_listener_registered', False):
            opponent._jianduwa_listener_registered = True
            from tards.constants import EVENT_CARD_PLAYED, EVENT_DISCARDED
            g.history.listen(EVENT_CARD_PLAYED, on_card_leave)
            g.history.listen(EVENT_DISCARDED, on_card_leave)

    add_deathrattle(minion, deathrattle)
    return True


@special
def _songmaochong_special(minion, player, game, extras=None):
    """松毛虫：对对手造成的伤害翻倍。亡语：对方所有手牌获得：打出时，受到1点伤害。"""
    def on_before_health_change(event):
        if not minion.is_alive():
            return
        source = event.data.get("source")
        if source is not minion:
            return
        target = event.data.get("target")
        if target is None:
            return
        opponent = game.p2 if player == game.p1 else game.p1
        if target is not opponent:
            return
        delta = event.data.get("delta", 0)
        if delta < 0:
            event.data["delta"] = delta * 2
            print(f"  {minion.name}：对对手造成的伤害翻倍，从 {-delta} 变为 {-delta * 2}")

    on("before_health_change", on_before_health_change, game, minion=minion)

    def deathrattle(m, p, g):
        opponent = g.p2 if p == g.p1 else g.p1
        for card in opponent.card_hand:
            card._songmaochong_poison = getattr(card, '_songmaochong_poison', 0) + 1
        print(f"  {m.name} 亡语：{opponent.name} 所有手牌获得打出时受到1点伤害")

        def on_card_played(event):
            played_card = event.data.get("card")
            played_player = event.data.get("player")
            if played_card and hasattr(played_card, '_songmaochong_poison') and played_player is opponent:
                count = played_card._songmaochong_poison
                opponent.health_change(-count, source=m)
                print(f"  松毛虫亡语：{opponent.name} 打出 [{played_card.name}] 受到 {count} 点伤害")
                del played_card._songmaochong_poison

        def on_card_discarded(event):
            discarded_card = event.data.get("card")
            if discarded_card and hasattr(discarded_card, '_songmaochong_poison'):
                del discarded_card._songmaochong_poison

        if not getattr(opponent, '_songmaochong_listener_registered', False):
            opponent._songmaochong_listener_registered = True
            from tards.constants import EVENT_CARD_PLAYED, EVENT_DISCARDED
            g.history.listen(EVENT_CARD_PLAYED, on_card_played)
            g.history.listen(EVENT_DISCARDED, on_card_discarded)

    add_deathrattle(minion, deathrattle)
    return True


@special
def _tanglang_special(minion, player, game, extras=None):
    """螳螂：受伤时，友方陆地异象具有+1攻击力。"""
    def mantis_aura(target_m):
        if not minion.is_alive():
            return 0
        if minion.current_health >= minion.current_max_health:
            return 0
        if target_m.owner != player:
            return 0
        if target_m.position[1] == 4:  # 水路
            return 0
        return 1

    def add_aura_to(m):
        if mantis_aura not in m._aura_attack_fns:
            m.add_aura_attack(mantis_aura)

    # 给当前所有存活异象添加 aura（友方/敌方都会加，但 aura 内部会筛选友方）
    for m in game.board.minion_place.values():
        if m.is_alive():
            add_aura_to(m)

    # 新部署的异象
    def on_entered(event):
        new_m = event.data.get("minion")
        if new_m and new_m.is_alive():
            add_aura_to(new_m)

    on("entered_battlefield", on_entered, game, minion=minion)

    # 螳螂死亡/移除时清理 aura
    def on_removed(event):
        dead = event.data.get("minion")
        if dead is minion:
            for m in list(game.board.minion_place.values()):
                if m.is_alive() and mantis_aura in m._aura_attack_fns:
                    m.remove_aura_attack(mantis_aura)

    on("removed", on_removed, game, minion=minion)
    return True


@special
def _xiangqun_special(minion, player, game, extras=None):
    """象群：部署：对所有异象造成1点伤害。回合开始时，随机眩晕一个敌方异象。"""
    import random
    from card_pools.effect_utils import deal_damage_to_minion

    # 1. 部署：对所有异象造成1点伤害
    for m in list(game.board.minion_place.values()):
        if m.is_alive():
            deal_damage_to_minion(m, 1, source=minion, game=game)
    print(f"  {minion.name} 部署：对所有异象造成1点伤害")

    # 2. 回合开始时，随机眩晕一个敌方异象
    def on_turn_start(m, p, g):
        enemies = [x for x in g.board.minion_place.values() if x.owner != p and x.is_alive()]
        if enemies:
            target = random.choice(enemies)
            target._stun_layers = getattr(target, '_stun_layers', 0) + 1
            print(f"  {m.name} 回合开始：{target.name} 获得1层眩晕（当前 {target._stun_layers} 层）")

    minion.on_turn_start = on_turn_start

    # 3. 注册全局眩晕系统（只注册一次）
    if not getattr(game, '_stun_system_registered', False):
        game._stun_system_registered = True

        def on_phase_start(event):
            if event.data.get("phase") != game.PHASE_RESOLVE:
                return
            for m in game.board.minion_place.values():
                if m.is_alive() and getattr(m, '_stun_layers', 0) > 0:
                    m._skip_resolve_attack = True

        def on_phase_end(event):
            if event.data.get("phase") != game.PHASE_RESOLVE:
                return
            for m in list(game.board.minion_place.values()):
                layers = getattr(m, '_stun_layers', 0)
                if layers > 0:
                    m._stun_layers = layers - 1
                    if m._stun_layers <= 0:
                        m._skip_resolve_attack = False
                        if hasattr(m, '_stun_layers'):
                            del m._stun_layers
                        print(f"  {m.name} 眩晕解除")
                    else:
                        print(f"  {m.name} 眩晕层数剩余 {m._stun_layers}")

        on("phase_start", on_phase_start, game)
        on("phase_end", on_phase_end, game)

    return True


@special
def _sun_special(minion, player, game, extras=None):
    """隼：攻击后，返回手牌。"""
    def on_after_attack(event):
        attacker = event.data.get("attacker")
        if attacker is not minion:
            return
        if not minion.is_alive():
            return
        from card_pools.effect_utils import return_minion_to_hand
        return_minion_to_hand(minion, game)
        print(f"  {minion.name} 攻击后返回手牌")

    on("attacked", on_after_attack, game, minion=minion)
    return True


@special
def _jiu_special(minion, player, game, extras=None):
    """鸠：友方异象被消灭后，加入其位置并攻击。友方异象部署时，本异象返回手牌。"""
    from card_pools.effect_utils import return_minion_to_hand

    # 1. 友方异象被消灭后，加入其位置并攻击
    def on_death(event):
        if not minion.is_alive():
            return
        dead = event.data.get("minion")
        if dead is None or dead.owner != player or dead is minion:
            return
        dead_pos = getattr(dead, 'position', None)
        if dead_pos is None:
            return
        # 移动到死亡异象的位置
        moved = game.board.move_minion(minion, dead_pos)
        if moved:
            print(f"  {minion.name} 移动到 {dead.name} 的位置 ({dead_pos})")
            # 标准攻击逻辑
            target = game.board.get_front_minion(minion.position[1], minion.owner, attacker=minion)
            if target and target.is_alive():
                minion.attack_target(target)
            else:
                enemy = game.p2 if player == game.p1 else game.p1
                minion.attack_target(enemy)
        else:
            print(f"  {minion.name} 移动失败，目标位置可能已被占据")

    on("death", on_death, game, minion=minion)

    # 2. 友方异象部署时，本异象返回手牌
    def on_deployed(event):
        if not minion.is_alive():
            return
        deployed = event.data.get("minion")
        if deployed and deployed.owner == player and deployed is not minion:
            return_minion_to_hand(minion, game)
            print(f"  鸠：友方异象 {deployed.name} 部署，鸠返回手牌")

    on("entered_battlefield", on_deployed, game, minion=minion)
    return True


@special
def _youlang_special(minion, player, game, extras=None):
    """幼狼：成长时，若不是组队状态，重置计时。"""
    def on_grow(m, p, g):
        # 检查同列是否有其他友方存活异象（组队状态）
        col = m.position[1]
        has_ally = False
        for x in g.board.minion_place.values():
            if x is not m and x.owner == p and x.is_alive() and x.position[1] == col:
                has_ally = True
                break
        if not has_ally:
            # 重置成长计时为初始值
            original_grow = getattr(m.source_card, 'keywords', {}).get("成长", 1)
            m.keywords["成长"] = original_grow
            print(f"  {m.name} 不处于组队状态，成长计时重置为 {original_grow}")
            return True  # 取消本次成长
        return False

    if not hasattr(minion, '_on_grow_callbacks'):
        minion._on_grow_callbacks = []
    minion._on_grow_callbacks.append(on_grow)
    return True


@special
def _chenglang_special(minion, player, game, extras=None):
    """成狼：成长前，若未消灭过异象，失去成长2。"""
    # 追踪是否消灭过异象（通过攻击致死）
    def on_death(event):
        dead = event.data.get("minion")
        if dead and getattr(dead, '_last_attacker', None) is minion:
            minion._has_killed_minion = True

    on("death", on_death, game, minion=minion)

    # 成长前检查
    def on_grow(m, p, g):
        if not getattr(m, '_has_killed_minion', False):
            m.keywords.pop("成长", None)
            print(f"  {m.name} 未消灭过异象，失去成长")
            return True  # 取消本次成长
        return False

    if not hasattr(minion, '_on_grow_callbacks'):
        minion._on_grow_callbacks = []
    minion._on_grow_callbacks.append(on_grow)
    return True


@special
def _langwang_special(minion, player, game, extras=None):
    """狼王：所有友方异象具有坚韧1。"""
    def tough_aura(target_m):
        if not minion.is_alive():
            return {}
        if target_m.owner != player:
            return {}
        return {"坚韧": 1}

    # 给当前所有友方存活异象添加光环
    for m in game.board.minion_place.values():
        if m.is_alive() and m.owner == player:
            minion.provide_aura_keywords(m, tough_aura)

    # 新部署的友方异象
    def on_entered(event):
        new_m = event.data.get("minion")
        if new_m and new_m.is_alive() and new_m.owner == player:
            minion.provide_aura_keywords(new_m, tough_aura)

    on("entered_battlefield", on_entered, game, minion=minion)
    return True


@special
def _youniao_special(minion, player, game, extras=None):
    """幼鸟：部署：指向一个友方飞禽异象，使其获得+3防御力和"友方幼鸟虚化"。

    防御力 = 最大生命值/当前生命值 +3。
    "友方幼鸟虚化" = 该飞禽异象成为光环源，使友方所有名为"幼鸟"的异象获得"虚化"。
    """
    from tards.targeting import TargetingRequest

    # 1. 内置指向：选择一个友方飞禽异象
    def scope(p, board):
        return [m for m in board.minion_place.values()
                if m.is_alive() and m.owner == p and "飞禽" in getattr(m, "tags", [])]

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = "幼鸟：选择一个友方飞禽异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    # 记录指向的异象（供成鸟进化时使用）
    minion._youniao_target = target

    # 2. +3防御力（最大生命值和当前生命值各+3）
    target.perm_max_health_bonus += 3
    target.current_health += 3
    target.recalculate()
    print(f"  幼鸟：{target.name} 获得+3防御力")

    # 3. 给该飞禽异象设置"友方幼鸟虚化"光环
    def baby_bird_protection(baby):
        if not target.is_alive():
            return {}
        if baby.owner != target.owner:
            return {}
        if baby.name == "幼鸟":
            return {"虚化": True}
        return {}

    # 给当前所有友方幼鸟提供光环
    for m in game.board.minion_place.values():
        if m.is_alive() and m.owner == player and m.name == "幼鸟":
            target.provide_aura_keywords(m, baby_bird_protection)

    # 注册部署钩子：新部署的友方幼鸟也获得光环
    def deploy_hook(deployed):
        if deployed.owner == target.owner and deployed.name == "幼鸟":
            target.provide_aura_keywords(deployed, baby_bird_protection)
            print(f"  {target.name} 的光环：新部署的幼鸟获得虚化")

    target.register_deploy_hook(game, deploy_hook)
    print(f"  幼鸟：{target.name} 获得'友方幼鸟虚化'")

    return True


def _chengniao_evolve(new_minion, player, game):
    """成鸟：若指向异象存活，将本异象转换为指向异象。"""
    old = getattr(new_minion, '_transformed_from', None)
    if not old:
        print("  成鸟：找不到前身幼鸟，无法转换")
        return

    target = getattr(old, '_youniao_target', None)
    if not target:
        print("  成鸟：幼鸟没有记录指向异象")
        return

    if not target.is_alive():
        print(f"  成鸟：指向异象 {target.name} 已死亡，无法转换")
        return

    from card_pools.effect_utils import transform_minion_to
    result = transform_minion_to(new_minion, target.name, game)
    if result:
        print(f"  成鸟：转换为 {target.name}")


@special
def _chaodong_special(minion, player, game, extras=None):
    """嘲鸫：友方异象在受到致命伤害前，先获得+1HP。"""
    def on_before_damage(event):
        if not minion.is_alive():
            return
        victim = event.data.get("target")
        if victim is None or not hasattr(victim, "is_alive"):
            return
        if not victim.is_alive() or victim.owner != player:
            return
        damage = event.data.get("damage", 0)
        if damage >= victim.current_health:
            victim.gain_health_bonus(1, permanent=True)
            victim.current_health += 1
            print(f"  嘲鸫：{victim.name} 受到致命伤害前获得+1HP（剩余 {victim.current_health}/{victim.max_health}）")

    on("before_damage", on_before_damage, game, minion=minion)
    return True


def _qiguai_de_yong_draw_trigger(player, game, card):
    """奇怪的蛹：抽取时注册监听器。出牌阶段结束时若仍在手牌，则弃掉自己并将巨蛾洗入卡组。"""
    listener_id = None

    def on_phase_end(event):
        nonlocal listener_id
        phase = event.data.get("phase")
        if phase != game.PHASE_ACTION:
            return

        # 若已不在手牌（被打出/部署或其他方式移除），注销监听器
        if card not in player.card_hand:
            if listener_id is not None:
                game.history.unlisten(listener_id)
            return

        # 弃掉此牌：从手牌移除并放入弃牌堆
        player.card_hand.remove(card)
        player.card_dis.append(card)
        print(f"  奇怪的蛹：出牌阶段结束，弃掉此牌")

        # 将巨蛾洗入卡组
        from tards.card_db import DEFAULT_REGISTRY
        from card_pools.effect_utils import shuffle_into_deck
        ju_e_def = DEFAULT_REGISTRY.get("巨蛾")
        if ju_e_def:
            ju_e_card = ju_e_def.to_game_card(player)
            shuffle_into_deck(player, ju_e_card)
            print(f"  奇怪的蛹：将巨蛾洗入卡组")

        # 执行完毕后注销监听器
        if listener_id is not None:
            game.history.unlisten(listener_id)

    listener_id = game.history.listen("phase_end", on_phase_end, owner=card)


@special
def _ju_e_special(minion, player, game, extras=None):
    """巨蛾：友方迅捷异象具有+1攻击力。"""
    def swift_aura(target_m):
        if not minion.is_alive():
            return 0
        if target_m.owner != player:
            return 0
        if target_m.keywords.get("迅捷", False):
            return 1
        return 0

    # 给当前所有友方异象注册攻击力光环（内部条件判断是否为迅捷）
    for m in game.board.minion_place.values():
        if m.is_alive() and m.owner == player:
            minion.provide_aura_attack(m, swift_aura)

    # 新部署的友方异象也获得光环
    def on_deployed(event):
        deployed = event.data.get("minion")
        if not deployed or not deployed.is_alive():
            return
        if deployed.owner != player:
            return
        minion.provide_aura_attack(deployed, swift_aura)

    on("deployed", on_deployed, game, minion=minion)
    return True


@special
def _qunyuan_special(minion, player, game, extras=None):
    """群猿：每有一个其它异象被献祭，+1/1，丰饶等级+1。"""

    def on_sacrifice(event):
        if not minion.is_alive():
            return
        sacrificed = event.data.get("minion")
        if sacrificed is minion:
            return  # 其它异象被献祭才触发，自己不触发

        # +1攻击力
        minion.perm_attack_bonus += 1
        # +1生命值（最大和当前）
        minion.perm_max_health_bonus += 1
        minion.current_health += 1
        # 丰饶等级+1
        minion.base_keywords["丰饶"] = minion.base_keywords.get("丰饶", 0) + 1
        # 重新计算
        minion.recalculate()
        print(f"  群猿：其它异象 {sacrificed.name if sacrificed else 'unknown'} 被献祭，获得+1/1，丰饶等级+1，当前 {minion.current_attack}/{minion.current_health} 丰饶{minion.base_keywords['丰饶']}")

    on("sacrifice", on_sacrifice, game, minion=minion)
    return True


@special
def _he_special(minion, player, game, extras=None):
    """鹤：回合开始：重置一个异象的攻击力与防御力，你获得+1HP。

    采用提前指向（预设目标）机制：出牌阶段通过 set_effect_target action
    为鹤预设目标，结算阶段开始时自动执行效果。
    """
    from card_pools.effect_utils import set_effect_target_scope, get_effect_target

    set_effect_target_scope(minion, lambda p, board: [
        m for m in board.minion_place.values() if m.is_alive() and m is not minion
    ])
    # 标记：预输入箭头仅对所有者可见，完成指向后才对对手可见
    minion._hidden_effect_pending = True

    def on_turn_start_fn(event):
        if not minion.is_alive():
            return

        target = get_effect_target(minion, game=game)
        if target is None:
            return

        # 重置攻击力与防御力（清除所有 bonus 并回满血）
        target.perm_attack_bonus = 0
        target.temp_attack_bonus = 0
        target.perm_max_health_bonus = 0
        target.temp_max_health_bonus = 0
        target.temp_health_bonus = 0
        target.recalculate()
        target.current_health = target.current_max_health
        print(f"  鹤：重置 {target.name} 的攻击力与防御力为 {target.current_attack}/{target.current_max_health}")

        # 你获得+1HP（恢复玩家生命）
        player.health_change(1)
        print(f"  鹤：{player.name} 获得+1HP")

    from card_pools.effect_utils import on_turn_start
    on_turn_start(minion, game, on_turn_start_fn)
    return True


@special
def _ankang_special(minion, player, game, extras=None):
    """鮟鱇：结算阶段结束：指向一个异象。下回合结算阶段开始：将其消灭。

    采用延迟效果预设机制：
    1. 出牌阶段：玩家预输入目标（存储在 _pending_effect_target）
    2. 当前回合结算阶段结束：消耗预输入，锁定目标到 _ankang_locked_target
    3. 下回合结算阶段开始：消灭锁定的目标
    """
    from card_pools.effect_utils import set_effect_target_scope, get_effect_target, destroy_minion, on_turn_start, on_turn_end

    set_effect_target_scope(minion, lambda p, board: [
        m for m in board.minion_place.values() if m.is_alive() and m is not minion
    ])

    def on_turn_end_fn(event):
        """结算阶段结束：执行指向，将预输入目标锁定。"""
        if not minion.is_alive():
            return
        target = get_effect_target(minion, game=game)
        if target is None:
            return
        minion._ankang_locked_target = target
        print(f"  鮟鱇：锁定目标 {target.name}")

    def on_turn_start_fn(event):
        """结算阶段开始：消灭已锁定的目标。"""
        if not minion.is_alive():
            return
        target = getattr(minion, '_ankang_locked_target', None)
        if target is None:
            return
        if not target.is_alive():
            minion._ankang_locked_target = None
            return
        destroy_minion(target, game)
        print(f"  鮟鱇：消灭锁定的 {target.name}")
        minion._ankang_locked_target = None

    on_turn_end(minion, game, on_turn_end_fn)
    on_turn_start(minion, game, on_turn_start_fn)
    return True


@special
def _kun_special(minion, player, game, extras=None):
    """鲲：平地（非高地）均算作水路。部署：使全体友方非两栖异象获得"水生"。

    高地（col=0）不受地形覆盖影响。
    地形改变后，不具有两栖的异象会被淹没移除（不触发亡语）。
    鲲死亡后，具有水生但位于陆地的异象也会被移除（不触发亡语）。
    """

    from card_pools.effect_utils import _is_minion_legal_on_terrain

    # 1. 地形覆盖：所有非高地、非水路格子（山脊、中路、河岸）变为水路
    if not hasattr(game, "_terrain_overrides"):
        game._terrain_overrides = {}

    minion._kun_terrain_positions = []
    for r in range(5):
        for c in [1, 2, 3]:  # 山脊、中路、河岸
            game._terrain_overrides[(r, c)] = "水路"
            minion._kun_terrain_positions.append((r, c))
    print("  鲲：平地均算作水路（高地除外）")

    # 2. 给当前所有友方非两栖异象添加"水生"
    for m in game.board.get_minions_of_player(player):
        if m.is_alive() and not m.keywords.get("两栖", False):
            m.base_keywords["水生"] = True
            m.recalculate()
            print(f"  鲲：{m.name} 获得水生")

    # 3. 新部署的友方非两栖异象也获得"水生"
    def deploy_hook(g, deployed):
        if deployed.owner == player and not deployed.keywords.get("两栖", False):
            deployed.base_keywords["水生"] = True
            deployed.recalculate()
            print(f"  鲲：{deployed.name} 获得水生")

    minion.register_deploy_hook(game, deploy_hook)

    # 4. 鲲部署后立即检查：淹没不合法异象（不触发亡语）
    def _check_drowning():
        for pos in list(game.board.minion_place.keys()):
            m = game.board.minion_place.get(pos)
            if not m or not m.is_alive():
                continue
            terrain = "水路" if game.board._is_water_at(pos) else "陆地"
            if not _is_minion_legal_on_terrain(m, terrain):
                game.board.remove_minion(pos)
                print(f"  鲲淹没：{m.name} 被移除（不触发亡语）")

    _check_drowning()

    # 5. 鲲离场时清理地形覆盖，并检查陆地上的水生异象
    def _cleanup_terrain():
        if getattr(minion, "_kun_terrain_cleaned", False):
            return
        minion._kun_terrain_cleaned = True

        # 先恢复地形
        for pos in getattr(minion, "_kun_terrain_positions", []):
            game._terrain_overrides.pop(pos, None)
        print("  鲲离场：地形覆盖恢复")

        # 再检查：陆地上的纯水生异象被移除（不触发亡语）
        for pos in list(game.board.minion_place.keys()):
            m = game.board.minion_place.get(pos)
            if not m or not m.is_alive():
                continue
            terrain = "水路" if game.board._is_water_at(pos) else "陆地"
            if not _is_minion_legal_on_terrain(m, terrain):
                game.board.remove_minion(pos)
                print(f"  鲲退潮：{m.name} 被移除（不触发亡语）")

    def on_before_destroy(event):
        if event.data.get("minion") is minion:
            _cleanup_terrain()

    def on_removed(event):
        if event.data.get("minion") is minion:
            _cleanup_terrain()

    on("before_destroy", on_before_destroy, game, minion=minion)
    on("removed", on_removed, game, minion=minion)
    return True


@special
def _wujiu_special(minion, player, game, extras=None):
    """兀鹫：友方异象攻击后，若攻击目标 HP不小于2，令攻击目标失去1点HP。"""
    def on_after_attack_fn(event):
        attacker = event.data.get("attacker")
        defender = event.data.get("defender")
        if attacker is None or defender is None:
            return
        if getattr(attacker, "owner", None) is not player:
            return
        from tards.cards import Minion
        from tards.player import Player
        if isinstance(defender, Minion):
            if not defender.is_alive():
                return
            if defender.current_health >= 2:
                defender.current_health -= 1
                print(f"  兀鹫：{attacker.name} 攻击后，{defender.name} 失去1点HP（剩余 {defender.current_health}）")
        elif isinstance(defender, Player):
            if defender.health >= 2:
                defender.lose_hp(1)
                print(f"  兀鹫：{attacker.name} 攻击后，{defender.name} 失去1点HP（剩余 {defender.health}）")

    on("after_attack", on_after_attack_fn, game, minion=minion)
    return True


@special
def _heishanyang_special(minion, player, game, extras=None):
    """黑山羊：亡语：若作为祭品且此次部署的B点溢出，抽1张牌。"""

    def on_sacrifice(event):
        sac_minion = event.data.get("minion")
        if sac_minion is not minion:
            return
        total_blood = event.data.get("total_blood", 0)
        required_blood = event.data.get("required_blood", 0)
        if total_blood > required_blood:
            minion._sacrifice_overflow = True

    on("献祭", on_sacrifice, game, minion=minion)

    def _dr(m, p, b):
        if getattr(m, "_sacrifice_overflow", False):
            g = b.game_ref if hasattr(b, "game_ref") else None
            draw_cards(p, 1, game=g)
            print(f"  黑山羊：献祭溢出，抽1张牌")

    add_deathrattle(minion, _dr)


@special
def _xintianweng_special(minion, player, game, extras=None):
    """信天翁：部署：使异象更多一方的一个异象返回其所有者手中。"""
    # 统计部署前数量（排除自身）
    friendly_count = len([m for m in game.board.minion_place.values()
                          if m.owner == player and m.is_alive() and m != minion])
    opponent = game.p1 if player == game.p2 else game.p2
    enemy_count = len([m for m in game.board.minion_place.values()
                       if m.owner == opponent and m.is_alive()])

    target_side = None
    if friendly_count > enemy_count:
        target_side = player
    elif enemy_count > friendly_count:
        target_side = opponent
    else:
        print("  信天翁：双方异象数量相等，效果不触发")
        return True

    # 内部指向：选择"更多一方"的一个异象
    from tards.targeting import TargetingRequest

    def scope(p, board):
        return [m for m in board.minion_place.values()
                if m.is_alive() and m.owner == target_side and m != minion]

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = f"信天翁：选择{target_side.name}场上的一个异象弹回手牌"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False  # 取消 → 自动回滚

    return_minion_to_hand(target, game)
    print(f"  信天翁：将 {target.name} 弹回 {target.owner.name} 手牌")
    return True


@special
def _13_haizi_special(minion, player, game, extras=None):
    """13号孩子：被献祭后转换为13号（继承剩余献祭等级）。"""
    minion._immune_to_sacrifice = True

    def on_sacrifice(event, g):
        sac_minion = event.data.get("minion")
        if sac_minion is not minion:
            return
        # 清理旧监听器，避免重复注册和内存泄漏
        g.history.unlisten_by_owner(minion)
        target_def = DEFAULT_REGISTRY.get("13号")
        if target_def and target_def.card_type == CardType.MINION:
            new_minion = g.transform_minion(minion, target_def, preserve_summon_turn=False)
            if new_minion:
                # 继承剩余献祭次数
                new_minion._sacrifice_remaining = minion._sacrifice_remaining
                # 触发新形态的部署效果（设置immune、监听器、亡语）
                next_card = target_def.to_game_card(player)
                if next_card and next_card.special:
                    next_card.special(new_minion, player, g)
                print(f"  {minion.name} 献祭后变身为 {new_minion.name}！")

    game.history.listen(EVENT_SACRIFICE, on_sacrifice, owner=minion)
    return True


@special
def _13_hao_special(minion, player, game, extras=None):
    """13号：被献祭后转换为13号孩子（继承剩余献祭等级）。亡语：消灭伤害来源。"""
    minion._immune_to_sacrifice = True

    def on_sacrifice(event, g):
        sac_minion = event.data.get("minion")
        if sac_minion is not minion:
            return
        g.history.unlisten_by_owner(minion)
        target_def = DEFAULT_REGISTRY.get("13号孩子")
        if target_def and target_def.card_type == CardType.MINION:
            new_minion = g.transform_minion(minion, target_def, preserve_summon_turn=False)
            if new_minion:
                new_minion._sacrifice_remaining = minion._sacrifice_remaining
                next_card = target_def.to_game_card(player)
                if next_card and next_card.special:
                    next_card.special(new_minion, player, g)
                print(f"  {minion.name} 献祭后变身为 {new_minion.name}！")

    game.history.listen(EVENT_SACRIFICE, on_sacrifice, owner=minion)

    def deathrattle(m, p, board):
        source = m._last_damage_source
        if source and isinstance(source, Minion) and source.is_alive():
            destroy_minion(source, game)
            print(f"  13号亡语：消灭伤害来源 {source.name}")

    add_deathrattle(minion, deathrattle)
    return True


# ----- 策略卡效果 -----

def target_any_minion_or_enemy_player(player, board):
    """返回所有场上异象 + 敌方玩家（用于金牙齿等需要指向玩家或异象的策略）。"""
    targets = list(board.minion_place.values())
    if board.game_ref:
        for p in board.game_ref.players:
            if p != player:
                targets.append(p)
    return targets


@strategy
def _jin_yachi_strategy(player, target, game, extras=None):
    """金牙齿：对一个目标造成1点伤害。若将其消灭，获得1T，抽一张牌。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        from tards.cards import Minion
        result = [m for m in board.minion_place.values() if m.is_alive()]
        opponent = game.p2 if p == game.p1 else game.p1
        result.append(opponent)
        return result

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "金牙齿：选择1个目标"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  金牙齿：目标无效")
        return False
    from tards.cards import Minion

    if isinstance(target, Minion):
        deal_damage_to_minion(target, 1, source=None, game=game)
        # 注意：minion_death() 将实际移除操作放入 effect_queue，is_alive() 此时仍为 True
        # 应直接检查血量或 _pending_death 标记来判断是否已消灭
        if target.current_health <= 0 or getattr(target, "_pending_death", False):
            gain_resource(player, "t", 1)
            draw_cards(player, 1, game)
            print(f"  金牙齿消灭 {target.name}，{player.name} 获得1T并抽一张牌")
    else:
        # 对玩家造成伤害（无法消灭玩家，不触发后续）
        deal_damage_to_player(target, 1, source=None, game=game)
        print(f"  金牙齿对 {target.name} 造成1点伤害")
    return True


@strategy
def _shanzi_strategy(player, target, game, extras=None):
    """扇子：使一个异象具有空袭直到回合结束。抽1张牌。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "扇子：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  扇子：目标无效")
        return False
    from tards.cards import Minion

    if not isinstance(target, Minion) or not target.is_alive():
        print("  扇子：目标无效")
        return False
    gain_keyword(target, "空袭", value=True, permanent=False)
    draw_cards(player, 1, game)
    print(f"  扇子：{target.name} 获得空袭直到回合结束，{player.name} 抽1张牌")
    return True
# =============================================================================
# =============================================================================
# 自动迁移的效果函数
# =============================================================================
def _jiandao_effect(game, event_data, player):
    """对方失去4T。"""
    deploy_player = event_data.get("player")
    if deploy_player:
        print(f"  阴谋 [剪刀] 触发：{deploy_player.name} 失去 4T")
        deploy_player.t_point_change(-4)

def _fange_effect(game, event_data, player):
    """对打出异象的玩家造成等同于其T花费的伤害。"""
    card = event_data.get("card")
    if isinstance(card, MinionCard):
        damage = card.cost.t if card.cost else 0
        target = card.owner
        if target and damage > 0:
            print(f"  阴谋 [反戈] 触发：{card.name} 的反噬对 {target.name} 造成 {damage} 点伤害")
            target.health_change(-damage)

def _xurui_effect(game, event_data, player):
    """阴谋拥有者获得4T。"""
    print(f"  阴谋 [蓄锐] 触发：{player.name} 获得 4T")
    player.t_point_change(4)

def _moshui_effect(game, event_data, player):
    """对方使用花费不大于4T的策略时，改为将其洗入对方卡组。"""
    frame = event_data.get("frame")
    if not frame:
        print(f"  [警告] 阴谋 [墨水] 未找到堆栈帧")
        return

    card = getattr(frame, "source", None)
    if not card or not isinstance(card, Strategy):
        print(f"  [警告] 阴谋 [墨水] 未找到策略卡")
        return

    # 取消当前策略效果
    frame.cancelled = True

    # 将策略卡洗入对方卡组
    target_player = getattr(card, "owner", None)
    if target_player and card in target_player.card_hand:
        target_player.card_hand.remove(card)
        target_player.card_deck.append(card)
        import random
        random.shuffle(target_player.card_deck)
        from card_pools.effect_utils import clear_shown_in_deck
        clear_shown_in_deck(target_player)
        print(f"  阴谋 [墨水] 将 [{card.name}] 洗入 {target_player.name} 的卡组")
    else:
        print(f"  [警告] 阴谋 [墨水] 未能在手牌中找到 [{card.name}]")

def _jinfeng_effect(game, event_data, player):
    """弃掉对方抽到的牌，并随机使其一张手牌花费+1T。"""
    draw_player = event_data.get("player")
    card = event_data.get("card")
    if card and card in draw_player.card_hand:
        draw_player.card_hand.remove(card)
        draw_player.card_dis.append(card)
        print(f"  阴谋 [劲风] 弃掉了 {draw_player.name} 抽到的 [{card.name}]")
    if draw_player.card_hand:
        import random
        target_card = random.choice(draw_player.card_hand)
        target_card.cost.t += 1
        print(f"  阴谋 [劲风] 使 {draw_player.name} 的 [{target_card.name}] 花费 +1T")

def _liqun_effect(game, event_data, player):
    """消灭该列所有进入协同状态的敌方异象。"""
    minion = event_data.get("minion")
    c = minion.position[1]
    from card_pools.effect_utils import destroy_minion
    to_destroy = []
    for r in range(game.board.SIZE):
        m = game.board.minion_place.get((r, c))
        if m and m.owner == minion.owner:
            to_destroy.append(m)
    for m in to_destroy:
        destroy_minion(m, game)
    print(f"  阴谋 [离群] 消灭了 {len(to_destroy)} 个进入协同状态的异象")

def _ruhe_effect(game, event_data, player):
    """对方部署异象前，将其移除，在下回合开始后将其加入原位。"""
    frame = event_data.get("frame")
    if not frame:
        print(f"  [警告] 阴谋 [入河] 未找到堆栈帧")
        return

    # 取消当前部署
    frame.cancelled = True

    card = getattr(frame, "source", None)
    if not card or not isinstance(card, MinionCard):
        print(f"  [警告] 阴谋 [入河] 未找到被部署的异象")
        return

    deploy_player = getattr(card, "owner", None)
    pos = getattr(card, "_deploy_target", None)
    if not deploy_player or not pos:
        print(f"  [警告] 阴谋 [入河] 未找到部署信息")
        return

    # 保存到下回合重新部署
    if not hasattr(game, "_ruhe_pending"):
        game._ruhe_pending = []

    game._ruhe_pending.append({
        "card": card,
        "player": deploy_player,
        "pos": pos,
        "trigger_turn": game.current_turn + 1,
    })

    print(f"  阴谋 [入河] 将 [{card.name}] 移除，下回合重新部署至 {pos}")

    # 注册回合开始监听器
    listener_id = id(card)

    def _redeploy_listener(event):
        pending = getattr(game, "_ruhe_pending", [])
        to_remove = []
        for item in pending:
            if game.current_turn >= item["trigger_turn"]:
                card = item["card"]
                deploy_player = item["player"]
                pos = item["pos"]
                minion = Minion(
                    name=card.name,
                    owner=deploy_player,
                    position=pos,
                    attack=card.attack,
                    health=card.health,
                    source_card=card,
                    board=game.board,
                    keywords=dict(card.keywords) if card.keywords else {},
                    on_turn_start=card.on_turn_start,
                    on_turn_end=card.on_turn_end,
                    on_phase_start=card.on_phase_start,
                    on_phase_end=card.on_phase_end,
                    tags=list(card.tags) if card.tags else [],
                    hidden_keywords=dict(card.hidden_keywords) if card.hidden_keywords else {},
                )
                if hasattr(card, "statue_top"):
                    minion.statue_top = card.statue_top
                if hasattr(card, "statue_bottom"):
                    minion.statue_bottom = card.statue_bottom
                if hasattr(card, "statue_pair"):
                    minion.statue_pair = card.statue_pair
                minion.summon_turn = game.current_turn
                game.board.place_minion(minion, pos)
                print(f"  阴谋 [入河] 将 [{card.name}] 加入战场 {pos}")
                to_remove.append(item)
        for item in to_remove:
            pending.remove(item)
        game._ruhe_pending = pending
        if not pending:
            game.unregister_listeners_by_owner(listener_id)

    game.register_listener(EVENT_TURN_START, _redeploy_listener, priority=50, owner_id=listener_id)

def _guaishi_effect(game, event_data, player):
    """对方永久失去一个T槽。"""
    bell_player = event_data.get("player")
    if bell_player:
        bell_player.t_point_max_change(-1)
        print(f"  阴谋 [怪石] 触发：{bell_player.name} 失去一个T槽（当前上限 {bell_player.t_point_max}）")

def _haishi_effect(game, event_data, player):
    """重定向已在 condition_fn 中同步完成。"""
    print(f"  阴谋 [海市蜃楼] 结算完毕")

def _yanxing_effect(game, event_data, player):
    """阴谋拥有者抽2张牌。"""
    player.draw_card(2, game=game)
    print(f"  阴谋 [掩星] 触发：{player.name} 抽2张牌")

def _yexi_effect(game, event_data, player):
    """使其先获得-2攻击力。若具有迅捷，将其消灭。"""
    attacker = event_data.get("attacker")
    from card_pools.effect_utils import destroy_minion
    if attacker.keywords.get("迅捷", False):
        destroy_minion(attacker, game)
        print(f"  阴谋 [夜袭] 消灭了具有迅捷的 [{attacker.name}]")
    else:
        attacker.base_attack -= 2
        attacker.recalculate()
        print(f"  阴谋 [夜袭] 使 [{attacker.name}] 获得-2攻击力（当前 {attacker.current_attack}）")

def _songshuping_effect(player, target, game, extras=None):
    """松鼠瓶：将2张"松鼠"加入手牌，此前你每使用过一次"松鼠瓶"，额外加入一只"松鼠"。

    松鼠直接从卡池定义创建新 token（不消耗 squirrel_deck）。
    若手牌已满，超出部分弃置。
    """
    squirrel_def = DEFAULT_REGISTRY.get("松鼠")
    if not squirrel_def:
        print(f"  [警告] 找不到松鼠定义，松鼠瓶效果失败")
        return False

    used_count = getattr(player, "_squirrel_bottle_used", 0)
    count = 2 + used_count

    added = 0
    discarded = 0
    for _ in range(count):
        card = squirrel_def.to_game_card(player)
        player.add_card_to_hand(card, game=game, emit_events=False)
        added += 1
        discarded += 1

    player._squirrel_bottle_used = used_count + 1

    print(
        f"  {player.name} 使用松鼠瓶，将 {added} 张松鼠加入手牌"
        f"{'（' + str(discarded) + ' 张因手牌满被弃置）' if discarded else ''}"
    )
    return True

def _shudong_effect(player, target, game, extras=None):
    from card_pools.effect_utils import all_friendly_minions, deploy_card_copy, empty_positions

    # 1. 选择部署位置并部署松鼠
    squirrel_def = DEFAULT_REGISTRY.get("松鼠")
    if not squirrel_def:
        return False
    card = squirrel_def.to_game_card(player)

    empties = empty_positions(player, game.board)
    valid = [pos for pos in empties if game.board.is_valid_deploy(pos, player, card)]
    if not valid:
        print("  树洞：无合法空位部署松鼠")
        return False

    options = [f"{i+1}. 第{pos[0]+1}行第{pos[1]+1}列" for i, pos in enumerate(valid)]
    chosen = game.request_choice(player, options, title="树洞：选择部署位置")
    if not chosen:
        return False
    idx = int(chosen.split('.')[0]) - 1
    target_pos = valid[idx]

    ok = deploy_card_copy(player, game, card, target_pos)
    if not ok:
        return False

    # 2. 给友方 B=0 冥刻异象添加"虚化"
    affected = []
    for m in all_friendly_minions(game, player):
        source = getattr(m, "source_card", None)
        if source and getattr(source, "pack", None) == Pack.UNDERWORLD and source.cost.b == 0:
            m.temp_keywords["虚化"] = True
            m.recalculate()
            affected.append(m.name)
    if affected:
        print(f"  树洞：本回合 {', '.join(affected)} 虚化")

    return True

def _xueping_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest

    def scope(p, board):
        from tards.cards import MinionCard
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "血瓶：选择手牌中的1张异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if target not in player.card_hand:
        return False
    from tards.cards import MinionCard
    if not isinstance(target, MinionCard):
        return False
    # 弃掉目标异象
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  {player.name} 弃掉了 [{target.name}]")
    # 获得3B
    player.b_point_change(3)
    # 若非松鼠，抽一张牌
    if target.name != "松鼠":
        player.draw_card(1, game=game)
    return True

@strategy
def _qianzi_effect(player, target, game, extras=None):
    """钳子：对你造成2点伤害，然后对一个异象造成4点伤害。抽一张牌。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "钳子：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  钳子：目标无效")
        return False
    from tards.cards import Minion

    # 对自己造成2点伤害
    deal_damage_to_player(player, 2, game=game)
    print(f"  钳子：{player.name} 受到2点伤害")

    # 对目标异象造成4点伤害
    if isinstance(target, Minion) and target.is_alive():
        deal_damage_to_minion(target, 4, game=game)
        print(f"  钳子：{target.name} 受到4点伤害")

    # 抽一张牌
    player.draw_card(1, game=game)
    print(f"  钳子：{player.name} 抽1张牌")
    return True

def _linshu_daobing_effect(player, target, game, extras=None):
    import random
    from card_pools.effect_utils import all_enemy_minions
    from tards.cards import Minion

    # 1. 对你造成4点伤害
    deal_damage_to_player(player, 4, source=None, game=game)

    # 2. 8点伤害随机分配至所有敌方目标
    opponent = game.p2 if player == game.p1 else game.p1
    for _ in range(8):
        enemy_minions = [m for m in all_enemy_minions(game, player) if m.is_alive()]
        candidates = enemy_minions + [opponent]
        if not candidates:
            break
        chosen = random.choice(candidates)
        if isinstance(chosen, Minion):
            deal_damage_to_minion(chosen, 1, source=None, game=game)
        else:
            deal_damage_to_player(chosen, 1, source=None, game=game)

    return True

def _guwang_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest

    def scope(p, board):
        from tards.cards import MinionCard
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "骨王：选择手牌中的1张异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    from tards.cards import MinionCard
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        return False

    # 弃掉目标异象
    player.card_hand.remove(target)
    player.card_dis.append(target)

    # 计算献祭等级与丰饶等级
    sac_level = target.keywords.get("献祭", 0)
    if sac_level is True:
        sac_level = 1
    elif not isinstance(sac_level, int):
        sac_level = 0

    fer_level = target.keywords.get("丰饶", 0)
    if fer_level is True:
        fer_level = 1
    elif not isinstance(fer_level, int):
        fer_level = 0

    product = sac_level * fer_level
    card_name = "骨王之赏" if product >= 2 else "骨王之惠"

    card_def = DEFAULT_REGISTRY.get(card_name)
    if card_def:
        card = card_def.to_game_card(player)
        player.add_card_to_hand(card, game=game, emit_events=False)
        print(f"  骨王：弃掉 [{target.name}]（献祭{sac_level}×丰饶{fer_level}={product}），获得 [{card_name}]")
    else:
        print(f"  骨王：找不到 {card_name} 的定义")

    return True

def _guwangzhi_hui_effect(player, target, game, extras=None):
    """骨王之惠：抽一张牌，使其-2T1B。"""
    if not player.card_deck:
        print("  骨王之惠：牌库为空")
        return True
    card = player.card_deck.pop()
    card.cost.t = max(0, card.cost.t - 2)
    card.cost.b -= 1
    player.add_card_to_hand(card, game=game, emit_events=False)
    return True

def _guwangzhi_shang_effect(player, target, game, extras=None):
    """骨王之赏：抽2张牌，免除其献祭点数。"""
    drawn = []
    for _ in range(2):
        if not player.card_deck:
            break
        card = player.card_deck.pop()
        drawn.append(card)

    for card in drawn:
        # 免除献祭点数：将鲜血费用设为0
        card.cost.b = 0
        player.add_card_to_hand(card, game=game, emit_events=False)
    return True

def _lazhu_cost_modifier(card, cost):
    """蜡烛费用修正：此前每使用过一次'烛烟'，此牌花费-2T。"""
    player = getattr(card, "owner", None)
    if player:
        reduction = getattr(player, "_zhuyan_used_count", 0) * 2
        if reduction > 0:
            cost.t = max(0, cost.t - reduction)


def _lazhu_effect(player, target, game, extras=None):
    # 获得+6HP（上限+当前）
    player.health_max_change(6)
    player.health_change(6)
    # 抽2张牌
    player.draw_card(2, game=game)
    return True

def _zhiwuxuejia_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest

    def scope(p, board):
        from tards.cards import MinionCard
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "植物学家：选择手牌中的1张异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    from tards.cards import MinionCard
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        return False

    # 弃掉目标异象
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  植物学家：弃掉 [{target.name}]")

    # 在手牌中查找另一张同名异象
    same_name = [c for c in player.card_hand
                 if isinstance(c, MinionCard) and c.name == target.name]
    if not same_name:
        print(f"  植物学家：手牌中没有另一张 [{target.name}]")
        return True

    buff_card = same_name[0]
    buff_card.attack *= 2
    buff_card.health *= 2
    buff_card.cost.t += 1
    print(f"  植物学家：[{buff_card.name}] 攻防翻倍（{buff_card.attack}/{buff_card.health}），花费+1T")
    return True

def _pimaoshang_effect(player, target, game, extras=None):
    import random
    from tards.cards import MinionCard

    # 阶段1：随机将一张手牌（非自身）洗入卡组
    remaining = [c for c in player.card_hand if c.name != "皮毛商"]
    if remaining:
        chosen = random.choice(remaining)
        player.card_hand.remove(chosen)
        player.card_deck.append(chosen)
        random.shuffle(player.card_deck)
        from card_pools.effect_utils import clear_shown_in_deck
        clear_shown_in_deck(player)
        print(f"  皮毛商：将 [{chosen.name}] 洗入卡组")

    # 阶段2：抉择
    choice = game.request_choice(player, ["抽2张异象", "获得4T"], "皮毛商：抉择")
    if choice == "抽2张异象":
        minion_cards = [c for c in player.card_deck if isinstance(c, MinionCard)]
        drawn = 0
        for card in minion_cards[:2]:
            player.card_deck.remove(card)
            player.add_card_to_hand(card, game=game, emit_events=False)
            drawn += 1
        print(f"  皮毛商：从卡组中抽出 {drawn} 张异象")
    elif choice == "获得4T":
        player.t_point_change(4)
        print(f"  皮毛商：{player.name} 获得 4T")

    return True

def _lieren_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest

    def scope(p, board):
        return list(p.card_hand)

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "猎人：选择手牌中的1张牌"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    import copy
    import random
    if target not in player.card_hand:
        return False

    # 弃掉目标
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  猎人：弃掉 [{target.name}]")

    # 复制2张洗入牌库
    for _ in range(2):
        cloned = copy.copy(target)
        player.card_deck.append(cloned)
    random.shuffle(player.card_deck)
    from card_pools.effect_utils import clear_shown_in_deck
    clear_shown_in_deck(player)
    print(f"  猎人：将2张 [{target.name}] 的复制洗入牌库")
    return True

def _yugou_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive() and m.owner != p]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "鱼钩：选择1个敌方异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  鱼钩：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import convert_cost_to_t

    if not isinstance(target, Minion):
        return False

    # 检查费用折算不大于3T
    source_card = getattr(target, "source_card", None)
    if source_card and hasattr(source_card, "cost"):
        cost_t = convert_cost_to_t(source_card.cost)
    else:
        cost_t = 999
    if cost_t > 3:
        print(f"  鱼钩：{target.name} 折算费用 {cost_t}T > 3，无法移动")
        return False

    # 找到友方同一列最靠近前排的空位
    col = target.position[1]
    rows = sorted(player.get_friendly_rows(), key=lambda r: abs(r - 2))
    new_pos = None
    for r in rows:
        pos = (r, col)
        if pos not in game.board.minion_place:
            new_pos = pos
            break

    if new_pos is None:
        print(f"  鱼钩：友方第{col}列没有空位，移动失败")
        return False

    # 转移所有权并跨阵营移动
    target.owner = player
    ok = game.board.move_minion(target, new_pos, allow_cross_side=True)
    if ok:
        print(f"  鱼钩：将 [{target.name}] 转移至 {new_pos}")
    else:
        # 所有权回滚
        opponent = game.p2 if player == game.p1 else game.p1
        target.owner = opponent
        print(f"  鱼钩：移动 [{target.name}] 失败")
    return ok

def _bopidao_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "剥皮刀：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  剥皮刀：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import (
        destroy_minion, give_temp_keyword_until_turn_end,
    )
    if not isinstance(target, Minion) or not target.is_alive():
        return False

    if target.keywords.get("迅捷", False):
        destroy_minion(target, game)
        print(f"  剥皮刀：{target.name} 具有迅捷，被消灭")
    else:
        give_temp_keyword_until_turn_end(target, "眩晕", 1)
        print(f"  剥皮刀：{target.name} 被眩晕")
    return True

def _yanping_effect(player, target, game, extras=None):
    from tards.cards import MinionCard

    # 选择列
    options = [f"{i}. {game.board.COL_NAMES[i]}" for i in range(5)]
    chosen = game.request_choice(player, options, title="岩瓶：选择一列")
    if not chosen:
        return False
    col = int(chosen.split('.')[0])

    # 永久覆盖该列为高地
    if not hasattr(game, "_terrain_overrides"):
        game._terrain_overrides = {}
    for r in range(5):
        game._terrain_overrides[(r, col)] = "高地"
    print(f"  岩瓶：第 {col} 列（{game.board.COL_NAMES[col]}）永久视为高地")

    # 抽一张高地异象
    for i, card in enumerate(player.card_deck):
        if isinstance(card, MinionCard) and card.keywords.get("高地", False):
            player.card_deck.pop(i)
            player.add_card_to_hand(card, game=game, emit_events=False)
            print(f"  岩瓶：抽出高地异象 [{card.name}]")
            return True

    print("  岩瓶：卡组中没有高地异象")
    return True

def _lanyue_effect(player, target, game, extras=None):
    from card_pools.effect_utils import on
    from tards.constants import EVENT_PHASE_START, EVENT_PHASE_END

    # 防止多次打出叠加监听器
    if getattr(player, "_lan_yue_active", False):
        print("  蓝月：效果已在生效中")
        return True
    player._lan_yue_active = True
    player._lan_yue_pending = True

    def on_action_start(event_data):
        if event_data.get("phase") != getattr(game, "PHASE_ACTION", "action"):
            return
        if not getattr(player, "_lan_yue_pending", False):
            return
        player._lan_yue_pending = False

        affected = 0
        for m in game.board.minion_place.values():
            if m.owner == player and m.is_alive():
                m._sacrifice_remaining += 1
                m.gain_keyword("献祭", 1, permanent=False)
                m._lan_yue_affected = True
                affected += 1
        if affected:
            print(f"  蓝月：{affected} 个友方异象献祭等级+1")

    def on_resolve_end(event_data):
        if event_data.get("phase") != getattr(game, "PHASE_RESOLVE", "resolve"):
            return
        if not getattr(player, "_lan_yue_active", False):
            return
        player._lan_yue_active = False
        cleaned = 0
        for m in list(game.board.minion_place.values()):
            if getattr(m, "_lan_yue_affected", False):
                m._lan_yue_affected = False

                base = m.base_keywords.get("献祭", 0)
                if base is True:
                    base = 1
                elif not isinstance(base, int):
                    base = 0

                if m._sacrifice_remaining > base:
                    m._sacrifice_remaining -= 1
                    if base >= 1 and m._sacrifice_remaining < 1:
                        m._sacrifice_remaining = 1
                cleaned += 1
        if cleaned:
            print(f"  蓝月效果结束（{cleaned} 个异象）")

    on(EVENT_PHASE_START, on_action_start, game)
    on(EVENT_PHASE_END, on_resolve_end, game)
    return True

@strategy
def _zhadan_yao_effect(player, target, game, extras=None):
    """炸弹夫人的遥控器：使友方异象获得传染亡语。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive() and m.owner != p]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "炸弹夫人的遥控器：选择1个敌方异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  炸弹夫人的遥控器：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import add_deathrattle, deal_damage_to_minion
    import random

    if not isinstance(target, Minion) or not target.is_alive():
        print("  炸弹夫人：目标不合法")
        return False

    def _make_deathrattle():
        def _deathrattle(minion, owner, board):
            g = getattr(board, "game_ref", None)
            friends = [m for m in board.minion_place.values() if m.owner == owner and m.is_alive() and m != minion]
            if not friends:
                return
            victim = random.choice(friends)
            deal_damage_to_minion(victim, 2, game=g)
            print(f"  炸弹夫人亡语：{victim.name} 受到2点伤害")
            if victim.is_alive():
                add_deathrattle(victim, _deathrattle)
                print(f"  炸弹夫人亡语：{victim.name} 获得传染亡语")
        return _deathrattle

    add_deathrattle(target, _make_deathrattle())
    print(f"  炸弹夫人：{target.name} 获得传染亡语")
    return True

def _xiangji_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "相机：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  相机：目标无效")
        return False
    if not isinstance(target, Minion) or not target.is_alive():
        return False

    # 移除场上异象（不触发亡语）
    game.board.remove_minion(target.position)

    # 复制 source_card，所有权转移
    sc = target.source_card
    new_card = MinionCard(
        name=sc.name,
        owner=player,
        cost=sc.cost.copy() if hasattr(sc.cost, "copy") else sc.cost,
        targets=sc.targets,
        attack=sc.attack,
        health=sc.health,
        special=getattr(sc, "special", None),
        keywords=dict(sc.keywords) if hasattr(sc, "keywords") else {},
    )
    # 复制额外属性
    for attr in ("pack", "asset_id", "asset_back_id", "evolve_to",
                 "statue_top", "statue_bottom", "statue_pair",
                 "targets_count", "targets_repeat"):
        if hasattr(sc, attr):
            setattr(new_card, attr, getattr(sc, attr))
    if hasattr(sc, "tags"):
        new_card.tags = list(sc.tags)
    if hasattr(sc, "hidden_keywords"):
        new_card.hidden_keywords = dict(sc.hidden_keywords)
    if hasattr(sc, "extra_targeting_stages"):
        new_card.extra_targeting_stages = list(sc.extra_targeting_stages)
    # 复制回调
    for cb in ("on_turn_start", "on_turn_end", "on_phase_start", "on_phase_end"):
        if hasattr(sc, cb):
            setattr(new_card, cb, getattr(sc, cb))

    player.add_card_to_hand(new_card, game=game, emit_events=False)
    return True

def _shalou_effect(player, target, game, extras=None):
    import random
    opponent = game.p2 if player == game.p1 else game.p2

    # 随机将对方一张手牌放置至其卡组顶
    if opponent.card_hand:
        chosen = random.choice(opponent.card_hand)
        opponent.card_hand.remove(chosen)
        opponent.card_deck.insert(0, chosen)
        print(f"  沙漏：将 {opponent.name} 的 [{chosen.name}] 放置至其卡组顶")
    else:
        print(f"  沙漏：{opponent.name} 手牌为空")

    # 自己抽1张牌
    player.draw_card(1, game=game)
    return True

def _xueyue_effect(player, target, game, extras=None):
    affected = 0
    for m in game.board.minion_place.values():
        if m.owner == player and m.is_alive():
            m.temp_attack_bonus += 1
            m.temp_keywords["坚韧"] = m.temp_keywords.get("坚韧", 0) + 1
            m.recalculate()
            affected += 1
    if affected:
        print(f"  血月：{affected} 个友方异象+1攻击力，获得坚韧1")
    return True

@strategy
def _jiaoshui_effect(player, target, game, extras=None):
    """胶水：使一个异象获得：在受到致命伤害前，+0/1。若因此存活，+1/1。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "胶水：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  胶水：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import on
    from tards.constants import EVENT_BEFORE_DAMAGE, EVENT_AFTER_DAMAGE

    if not isinstance(target, Minion) or not target.is_alive():
        return False

    def protect(event_data):
        if event_data.get("target") is not target:
            return
        damage = event_data.get("damage", 0)
        if damage <= 0:
            return

        # 预判是否致命（考虑坚韧）
        tough = target.keywords.get("坚韧", 0)
        if target.keywords.get("脆弱", False) and tough == 0:
            tough = -1
        actual = max(0, damage - tough) if isinstance(tough, int) else damage
        if target.current_health > actual:
            return

        # +0/1：获得1HP（上限+当前）
        target.gain_health_bonus(1, permanent=True)
        target.current_health += 1
        target._jiaoshui_protected = True
        print(f"  胶水：{target.name} 受到致命伤害，+0/1")

    def check_survival(event_data):
        if event_data.get("target") is not target:
            return
        if not getattr(target, "_jiaoshui_protected", False):
            return
        target._jiaoshui_protected = False
        if target.is_alive():
            target.gain_attack(1, permanent=True)
            target.gain_health_bonus(1, permanent=True)
            target.current_health += 1
            print(f"  胶水：{target.name} 因此存活，+1/1")

    on(EVENT_BEFORE_DAMAGE, protect, game, minion=target,
       source_name="胶水", description="受到致命伤害前+0/1")
    on(EVENT_AFTER_DAMAGE, check_survival, game, minion=target,
       source_name="胶水", description="若因此存活+1/1")
    print(f"  胶水：{target.name} 获得致命伤害保护")
    return True

def _shizhong_effect(player, target, game, extras=None):
    from tards.cards import MinionCard, Minion
    from card_pools.effect_utils import on, empty_positions
    from tards.constants import EVENT_PHASE_START
    from tards.targeting import TargetingRequest
    import random

    def hand_scope(p, board):
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "时钟：选择手牌中的1张异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        return False

    # 弃掉目标
    player.card_hand.remove(target)
    player.card_dis.append(target)

    target_turn = game.current_turn + 3
    if not hasattr(player, "_shizhong_delayed"):
        player._shizhong_delayed = []
    player._shizhong_delayed.append({"turn": target_turn, "card": target})
    print(f"  时钟：弃掉 [{target.name}]，将在第 {target_turn} 回合抽牌阶段加入战场")

    def on_draw_phase(event_data):
        if event_data.get("phase") != getattr(game, "PHASE_DRAW", "draw"):
            return
        delayed = getattr(player, "_shizhong_delayed", [])
        to_deploy = [d for d in delayed if d["turn"] == game.current_turn]
        if not to_deploy:
            return

        for entry in to_deploy:
            card = entry["card"]
            empties = empty_positions(player, game.board)
            valid = [pos for pos in empties if game.board.is_valid_deploy(pos, player, card)]
            if not valid:
                print(f"  时钟：无合法空位部署 {card.name}")
                continue

            pos = random.choice(valid)
            minion = Minion(
                name=card.name,
                owner=player,
                position=pos,
                attack=card.attack,
                health=card.health,
                source_card=card,
                board=game.board,
                keywords=dict(card.keywords) if hasattr(card, "keywords") else {},
                on_turn_start=getattr(card, "on_turn_start", None),
                on_turn_end=getattr(card, "on_turn_end", None),
                on_phase_start=getattr(card, "on_phase_start", None),
                on_phase_end=getattr(card, "on_phase_end", None),
                tags=list(card.tags) if hasattr(card, "tags") else [],
                hidden_keywords=dict(card.hidden_keywords) if hasattr(card, "hidden_keywords") else {},
            )
            if hasattr(card, "statue_top"):
                minion.statue_top = card.statue_top
            if hasattr(card, "statue_bottom"):
                minion.statue_bottom = card.statue_bottom
            if hasattr(card, "statue_pair"):
                minion.statue_pair = card.statue_pair
            game.board.place_minion(minion, pos)
            print(f"  时钟：{card.name} 加入战场 {pos}")

        player._shizhong_delayed = [d for d in delayed if d["turn"] != game.current_turn]

    if not getattr(player, "_shizhong_listener_registered", False):
        on(EVENT_PHASE_START, on_draw_phase, game)
        player._shizhong_listener_registered = True
        player._shizhong_listener_registered = True

    return True

def _yinghuo_effect(player, target, game, extras=None):
    from tards.cards import MinionCard
    from tards.targeting import TargetingRequest

    def hand_scope(p, board):
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "营火：选择手牌中的1张异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        return False

    # +2/3（永久修改卡牌面板）
    target.attack += 2
    target.health += 3

    # 添加亡语：对方抽一张牌
    def deathrattle(minion, owner, board):
        opponent = game.p1 if owner == game.p2 else game.p2
        opponent.draw_card(1, game=game)
        print(f"  {minion.name} 亡语：{opponent.name} 抽1张牌")

    target.keywords["亡语"] = deathrattle
    print(f"  营火：{target.name} 获得+2/3和亡语（对方抽牌）")
    return True

@strategy
def _bingkuai_effect(player, target, game, extras=None):
    """冰块：使一个友方异象获得 +0/4 并冰冻2回合，期间其拥有坚韧I。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive() and m.owner == p]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "冰块：选择1个友方异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  冰块：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import on
    from tards.constants import EVENT_PHASE_END

    if not isinstance(target, Minion) or not target.is_alive() or target.owner != player:
        return False

    # +0/4 永久
    target.base_max_health_bonus += 4
    target.current_health += 4
    target.recalculate()

    # 冰冻2回合
    target.base_keywords["冰冻"] = 2

    # 坚韧I（冰冻期间生效）
    target.base_keywords["坚韧"] = 1
    target.recalculate()

    def on_resolve_end(event_data):
        if event_data.get("phase") != getattr(game, "PHASE_RESOLVE", "resolve"):
            return
        frozen = target.keywords.get("冰冻", 0)
        if not isinstance(frozen, int) or frozen <= 0:
            # 冰冻已解除，移除坚韧
            target.base_keywords.pop("坚韧", None)
            target.perm_keywords.pop("坚韧", None)
            target.temp_keywords.pop("坚韧", None)
            target.recalculate()
            print(f"  冰块：{target.name} 冰冻解除，坚韧消失")

    on(EVENT_PHASE_END, on_resolve_end, game, minion=target)
    print(f"  冰块：{target.name} +0/4，冰冻2回合，坚韧I")
    return True

def _mudiaoshi_effect(player, target, game, extras=None):
    # 开发一张座首
    top_defs = [c for c in DEFAULT_REGISTRY.all_cards() if getattr(c, "statue_top", False)]
    if top_defs:
        game.develop_card(player, top_defs, count=min(3, len(top_defs)))
        print("  木雕师：开发一张座首")
    else:
        print("  木雕师：无可用座首")

    # 开发一张底座
    bottom_defs = [c for c in DEFAULT_REGISTRY.all_cards() if getattr(c, "statue_bottom", False)]
    if bottom_defs:
        game.develop_card(player, bottom_defs, count=min(3, len(bottom_defs)))
        print("  木雕师：开发一张底座")
    else:
        print("  木雕师：无可用底座")

    return True

def _muqi_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive() and m.owner == p and (getattr(m, "statue_top", False) or getattr(m, "statue_bottom", False))]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "木漆：选择1个座首或底座异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not target.is_alive() or target.owner != player:
        return False
    if not (getattr(target, "statue_top", False) or getattr(target, "statue_bottom", False)):
        return False

    target.gain_health_bonus(6, permanent=True)
    target.current_health += 6
    target.base_keywords["绝缘"] = True
    target.recalculate()
    print(f"  木漆：{target.name} +6HP，获得绝缘")
    return True

def _make_effect(player, target, game, extras=None):
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "玛珂：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    def filter_fn(t, damage, source):
        return t is target

    def replace_fn(damage):
        return 0

    game.add_damage_replacement(filter_fn, replace_fn, once=True, reason="玛珂")

    if isinstance(target, Minion):
        player.draw_card(1, game=game)
        print(f"  玛珂：{target.name} 免疫下次伤害，{player.name} 抽1张牌")
    else:
        print(f"  玛珂：{getattr(target, 'name', str(target))} 免疫下次伤害")
    return True

def _hanji_effect(player, target, game, extras=None):
    """旱季：对所有陆地异象造成3点伤害，然后使所有陆地异象+1/+2。失去1个T槽。"""
    board = game.board
    from card_pools.effect_utils import deal_damage_to_minion

    def _get_land_minions():
        seen = set()
        result = []
        for m in list(board.minion_place.values()) + list(board.cell_underlay.values()):
            if m.is_alive() and m.position[1] != 4 and id(m) not in seen:
                result.append(m)
                seen.add(id(m))
        return result

    land_minions = _get_land_minions()
    for m in land_minions:
        deal_damage_to_minion(m, 3, game=game)
        print(f"  旱季：对 {m.name} 造成3点伤害")

    for m in _get_land_minions():
        m.gain_attack(1, permanent=True)
        m.gain_health_bonus(2, permanent=True)
        print(f"  旱季：{m.name} +1/+2")

    player.t_point_max_change(-1)
    print(f"  旱季：{player.name} 失去1个T槽")
    return True

def _shanhong_effect(player, target, game, extras=None):
    """山洪：使一列陆地算作水路直到下回合结束。失去1个T槽。"""
    from card_pools.effect_utils import register_terrain_enforcement

    # 选择列
    options = [f"{i}. {game.board.COL_NAMES[i]}" for i in range(4)]
    chosen = game.request_choice(player, options, title="山洪：选择一列（0-3）")
    if not chosen:
        return False
    col = int(chosen.split('.')[0])

    register_terrain_enforcement(game, col, "水路", game.current_turn + 1)
    print(f"  山洪：第 {col} 列（{game.board.COL_NAMES[col]}）被视为水路，直到下回合结束")

    player.t_point_max_change(-1)
    print(f"  山洪：{player.name} 失去1个T槽")
    return True

def _shuiyi_effect(player, target, game, extras=None):
    """水疫：若水路（列4）有敌方异象，对所有敌方异象造成1点伤害；若有异象被消灭，重复。"""
    opponent = game.p2 if player == game.p1 else game.p1
    board = game.board
    from card_pools.effect_utils import deal_damage_to_minion

    iteration = 0
    while True:
        iteration += 1
        # 检查水路是否有敌方异象
        water_enemies = board.get_enemy_minions_in_column(4, player)
        if not water_enemies:
            print(f"  水疫（第{iteration}轮）：水路无敌方异象，效果结束")
            break

        # 收集所有当前敌方异象（包含新召唤的）
        all_enemies = []
        seen = set()
        for m in list(board.minion_place.values()) + list(board.cell_underlay.values()):
            if m.is_alive() and m.owner == opponent and id(m) not in seen:
                all_enemies.append(m)
                seen.add(id(m))

        if not all_enemies:
            print(f"  水疫（第{iteration}轮）：无敌方异象可伤害")
            break

        any_killed = False
        for m in all_enemies:
            before_alive = m.is_alive()
            deal_damage_to_minion(m, 1, game=game)
            if before_alive and not m.is_alive():
                any_killed = True

        print(f"  水疫（第{iteration}轮）：对 {len(all_enemies)} 个敌方异象造成1点伤害")

        if not any_killed:
            print(f"  水疫（第{iteration}轮）：无异象被消灭，效果结束")
            break

    return True

def _shachen_effect(player, target, game, extras=None):
    """沙尘：眩晕一个敌方异象。若本回合对方先手，结束双方出牌阶段。"""
    from card_pools.effect_utils import give_temp_keyword_until_turn_end
    from tards.cards import Minion
    from tards.targeting import TargetingRequest

    def scope(p, board):
        opponent = game.p2 if p == game.p1 else game.p1
        return [m for m in board.minion_place.values() if m.is_alive() and m.owner == opponent]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "沙尘：选择1个敌方异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, Minion) or not target.is_alive():
        print("  沙尘：目标无效")
        return False

    give_temp_keyword_until_turn_end(target, "眩晕", 1)
    print(f"  沙尘：{target.name} 被眩晕")

    # 判断本回合对方是否先手
    first = game.p1 if game.current_turn % 2 == 1 else game.p2
    if first != player:
        # 对方先手，结束双方出牌阶段
        game.p1.braked = True
        game.p2.braked = True
        print(f"  沙尘：本回合对方先手，双方出牌阶段结束")

    return True

def _kuangfeng_effect(player, target, game, extras=None):
    """狂风：对方无法部署异象，直到下一个出牌阶段结束。"""
    opponent = game.p2 if player == game.p1 else game.p1

    def _restriction_fn(p, card):
        if p == opponent:
            return False
        return True

    game._global_deploy_restrictions.append(_restriction_fn)
    print(f"  狂风：{opponent.name} 无法部署异象，直到下回合结束")

    # 下回合结束时移除限制
    def _cleanup():
        if _restriction_fn in game._global_deploy_restrictions:
            game._global_deploy_restrictions.remove(_restriction_fn)
            print(f"  狂风：{opponent.name} 的部署限制已解除")

    game._delayed_effects.append({
        "trigger": "turn_end",
        "turn": game.current_turn + 1,
        "fn": _cleanup,
    })
    return True

def _gaozhi_effect(player, target, game, extras=None):
    opponent = game.p2 if player == game.p1 else game.p1
    player.t_point_max_change(1)
    opponent.t_point_max_change(-1)
    print(f"  稿纸：{player.name} 获得1T槽，{opponent.name} 失去1T槽")
    return True

@strategy
def _zhouyu_effect(player, target, game, extras=None):
    """骤雨：将1个异象返回其所有者手牌。对手下回合无法抽牌。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "骤雨：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  骤雨：目标无效")
        return False
    from card_pools.effect_utils import return_minion_to_hand

    if not isinstance(target, Minion) or not target.is_alive():
        print("  骤雨：目标不合法")
        return False

    return_minion_to_hand(target, game)
    print(f"  骤雨：{target.name} 返回其所有者手牌")

    opponent = game.p2 if player == game.p1 else game.p1
    opponent._skip_next_draw = True
    print(f"  骤雨：{opponent.name} 下回合无法抽牌")
    return True

def _fansheng_effect(player, target, game, extras=None):
    """繁盛：弃掉所有手牌，获得'抽牌阶段多抽1张'。"""
    from card_pools.effect_utils import on
    from tards.constants import EVENT_PHASE_START

    # 弃掉所有手牌
    discarded = list(player.card_hand)
    player.card_hand.clear()
    player.card_dis.extend(discarded)
    if discarded:
        names = ", ".join([c.name for c in discarded])
        print(f"  繁盛：{player.name} 弃掉 {len(discarded)} 张手牌（{names}）")
    else:
        print(f"  繁盛：{player.name} 手牌为空")

    # 注册一次性抽牌阶段监听器
    def _extra_draw(event_data):
        if event_data.get("phase") != game.PHASE_DRAW:
            return
        draw_player = event_data.get("player")
        if draw_player and draw_player != player:
            return
        # 检查是否已触发过
        if getattr(player, "_fansheng_triggered", False):
            return
        player._fansheng_triggered = True
        player.draw_card(1, game=game)
        print(f"  繁盛：{player.name} 额外抽1张牌")

    player._fansheng_triggered = False
    on(EVENT_PHASE_START, _extra_draw, game)
    print(f"  繁盛：{player.name} 获得'抽牌阶段多抽1张'")
    return True

def _tudao_effect(player, target, game, extras=None):
    """屠刀：将2张'松鼠'加入手牌。本回合，你每献祭一个异象，抽一张牌。"""
    from tards.constants import EVENT_SACRIFICE

    # 加入2张松鼠
    squirrel_count = 0
    for _ in range(2):
        if player.squirrel_deck:
            card = player.squirrel_deck.pop()
            player.add_card_to_hand(card, game=game, emit_events=False)
            squirrel_count += 1
        else:
            # squirrel_deck 空了，从 registry 创建
            squirrel_def = DEFAULT_REGISTRY.get("松鼠")
            if squirrel_def:
                card = squirrel_def.to_game_card(player)
                player.add_card_to_hand(card, game=game, emit_events=False)
                squirrel_count += 1
    print(f"  屠刀：{player.name} 将 {squirrel_count} 张松鼠加入手牌")

    # 注册献祭监听器
    def on_sacrifice(event_data):
        if event_data.get("player") == player:
            player.draw_card(1, game=game)
            print(f"  屠刀：{player.name} 献祭抽1张牌")

    owner_id = game.event_bus.register(EVENT_SACRIFICE, on_sacrifice)

    # 本回合结束时注销
    def cleanup():
        game.event_bus.unregister_by_owner(owner_id)
        print(f"  屠刀：献祭抽牌效果结束")

    game._delayed_effects.append({
        "trigger": "turn_end",
        "turn": game.current_turn,
        "fn": cleanup,
    })

    return True

def _zhenban_effect(player, target, game, extras=None):
    """砧板：弃一张牌，抽一张花费更高的牌。若弃牌献祭等级×丰饶等级≥2，获得2B。"""
    from tards.targeting import TargetingRequest

    def hand_scope(p, board):
        return [c for c in p.card_hand]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "砧板：选择1张手牌弃掉"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if target not in player.card_hand:
        print("  砧板：目标不在手牌中")
        return False

    # 弃掉选中的牌
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  砧板：{player.name} 弃掉 [{target.name}]")

    # 计算弃牌总费用
    def _cost_total(cost):
        return cost.t + cost.c + cost.b + cost.s + cost.ct + sum(cost.minerals.values())

    discarded_cost = _cost_total(target.cost)

    # 从牌库顶找第一张费用更高的牌
    drawn = None
    for i, card in enumerate(player.card_deck):
        if _cost_total(card.cost) > discarded_cost:
            drawn = player.card_deck.pop(i)
            break

    if drawn:
        player.add_card_to_hand(drawn, game=game, emit_events=False)
    else:
        print("  砧板：牌库中没有更高费的牌")

    # 计算献祭等级 × 丰饶等级
    sacrifice_kw = getattr(target, "keywords", {}).get("献祭", False)
    if sacrifice_kw is True:
        sacrifice_level = 1
    elif isinstance(sacrifice_kw, int):
        sacrifice_level = sacrifice_kw
    else:
        sacrifice_level = 0

    feng_rang_kw = getattr(target, "keywords", {}).get("丰饶", False)
    if feng_rang_kw is True:
        feng_rang_level = 1
    elif isinstance(feng_rang_kw, int):
        feng_rang_level = feng_rang_kw
    else:
        feng_rang_level = 0

    if sacrifice_level * feng_rang_level >= 2:
        player.b_point += 2
        print(f"  砧板：{player.name} 获得 2B（献祭{sacrifice_level}×丰饶{feng_rang_level}={sacrifice_level * feng_rang_level}）")

    return True

def _haichen_effect(player, target, game, extras=None):
    """还尘：消灭一个受伤异象。若是友方异象，抽三张牌。"""
    from tards.cards import Minion
    from card_pools.effect_utils import destroy_minion
    from tards.targeting import TargetingRequest

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive() and m.current_health < m.max_health]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "还尘：选择1个受伤异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, Minion) or not target.is_alive():
        print("  还尘：目标无效")
        return False

    if target.current_health >= target.max_health:
        print("  还尘：目标未受伤")
        return False

    destroy_minion(target, game)
    print(f"  还尘：消灭受伤异象 {target.name}")

    if target.owner == player:
        player.draw_card(3, game=game)
        print(f"  还尘：{player.name} 抽3张牌（友方异象）")

    return True

@strategy
def _jidai_effect(player, target, game, extras=None):
    """继代：使一个异象获得亡语，将其-1/1的复制加入你的手牌。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "继代：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  继代：目标无效")
        return False
    from tards.cards import Minion
    from card_pools.effect_utils import add_deathrattle

    if not isinstance(target, Minion) or not target.is_alive():
        print("  继代：目标不合法")
        return False

    def _deathrattle(minion, owner, board):
        sc = minion.source_card
        new_card = MinionCard(
            name=sc.name,
            owner=owner,
            cost=sc.cost.copy(),
            targets=sc.targets,
            attack=max(0, sc.attack - 1),
            health=max(1, sc.health - 1),
            special=getattr(sc, "special", None),
            keywords=dict(sc.keywords) if hasattr(sc, "keywords") else {},
        )
        if hasattr(sc, "tags"):
            new_card.tags = list(sc.tags)
        if hasattr(sc, "hidden_keywords"):
            new_card.hidden_keywords = dict(sc.hidden_keywords)
        for attr in ("statue_top", "statue_bottom", "statue_pair"):
            if hasattr(sc, attr):
                setattr(new_card, attr, getattr(sc, attr))
        owner.add_card_to_hand(new_card, game=game, emit_events=False)

    add_deathrattle(target, _deathrattle)
    print(f"  继代：{target.name} 获得亡语")
    return True

@strategy
def _yehuo_effect(player, target, game, extras=None):
    """野火：弃1张牌，将1个异象返回其所有者牌库顶，眩晕周围异象。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "野火：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  野火：目标无效")
        return False
    from card_pools.effect_utils import get_adjacent_positions, give_temp_keyword_until_turn_end
    from card_pools.effect_utils import place_at_deck_top
    from tards.cards import Minion

    # 阶段1：弃牌
    if target not in player.card_hand:
        print("  野火：弃牌目标不在手牌中")
        return False
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  野火：{player.name} 弃掉 [{target.name}]")

    # 阶段2：选异象
    minion_target = (extras or [None])[0]
    if not isinstance(minion_target, Minion) or not minion_target.is_alive():
        print("  野火：异象目标不合法")
        return False

    owner = minion_target.owner
    pos = minion_target.position
    sc = minion_target.source_card

    # 从场上移除
    game.board.remove_minion(pos)
    print(f"  野火：{minion_target.name} 从场上移除")

    # 将 source_card 放入所有者牌库顶
    place_at_deck_top(owner, [sc])
    print(f"  野火：{sc.name} 返回 {owner.name} 牌库顶")

    # 眩晕周围异象
    adj_positions = get_adjacent_positions(pos, game.board)
    for adj_pos in adj_positions:
        m = game.board.get_minion_at(adj_pos)
        if m and m.is_alive():
            give_temp_keyword_until_turn_end(m, "眩晕", 1)
            print(f"  野火：{m.name} 被眩晕")

    return True

def _lunhui_effect(player, target, game, extras=None):
    """轮回：弃1张牌，抽1张。若弃掉回响，对目标造成4点伤害。"""
    from card_pools.effect_utils import deal_damage_to_minion, deal_damage_to_player
    from tards.cards import Minion
    from tards.targeting import TargetingRequest

    def hand_scope(p, board):
        return [c for c in p.card_hand]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "轮回：选择1张手牌弃掉"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if target not in player.card_hand:
        print("  轮回：目标不在手牌中")
        return False

    # 弃牌
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  轮回：{player.name} 弃掉 [{target.name}]")

    # 抽1张
    player.draw_card(1, game=game)
    print(f"  轮回：{player.name} 抽1张牌")

    # 若弃掉回响，造成4点伤害
    if target.keywords.get("回响", False):
        dmg_target = (extras or [None])[0]
        if isinstance(dmg_target, Minion) and dmg_target.is_alive():
            deal_damage_to_minion(dmg_target, 4, game=game)
            print(f"  轮回：{dmg_target.name} 受到4点伤害")
        elif dmg_target is player or dmg_target is (game.p2 if player == game.p1 else game.p1):
            deal_damage_to_player(dmg_target, 4, game=game)
            print(f"  轮回：{dmg_target.name} 受到4点伤害")
        else:
            print("  轮回：伤害目标不合法")

    return True

def _gengti_effect(player, target, game, extras=None):
    """更替：使手牌中的1个回响异象回响等级+1。"""
    from tards.cards import MinionCard
    from tards.targeting import TargetingRequest

    def hand_scope(p, board):
        return [c for c in p.card_hand if isinstance(c, MinionCard) and getattr(c, "echo_level", 0) > 0]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "更替：选择手牌中的1个异放异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        print("  更替：目标不合法")
        return False

    if getattr(target, "echo_level", 0) <= 0:
        print("  更替：目标不是异放异象")
        return False

    # 增加异放等级
    target.echo_level += 1
    # 同步更新关键词
    if "异放" in target.keywords:
        current = target.keywords["异放"]
        if isinstance(current, int):
            target.keywords["异放"] = current + 1
        elif current is True:
            target.keywords["异放"] = 2
    else:
        target.keywords["异放"] = target.echo_level

    print(f"  更替：{target.name} 异放等级+1（当前 {target.echo_level}）")
    return True

def _poxiao_effect(player, target, game, extras=None):
    """破晓：抽2张牌。若剩余T点≤1，获得两倍于本对局失去T槽数的T点。"""
    from card_pools.effect_utils import total_t_max_lost

    player.draw_card(2, game=game)
    print(f"  破晓：{player.name} 抽2张牌")

    if player.t_point <= 1:
        total_lost = total_t_max_lost(game, player)
        gain = total_lost * 2
        if gain > 0:
            player.t_point_change(gain)
            print(f"  破晓：{player.name} 剩余T点≤1，获得 {gain}T（失去过{total_lost}个T槽）")
        else:
            print(f"  破晓：{player.name} 剩余T点≤1，但未失去过T槽")

    return True

def _liulinfengsheng_effect(player, target, game, extras=None):
    """柳林风声：弃1异象，将5T复制加入对方手牌。对方部署其它异象时，复制卡加入友方区域。"""
    from tards.cards import MinionCard, Minion
    from tards.cost import Cost
    from card_pools.effect_utils import empty_positions
    from tards.targeting import TargetingRequest
    import random

    def hand_scope(p, board):
        return [c for c in p.card_hand if isinstance(c, MinionCard)]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = hand_scope
    req.prompt = "柳林风声：选择手牌中的1张异象弃掉"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False
    if not isinstance(target, MinionCard) or target not in player.card_hand:
        print("  柳林风声：目标不在手牌中")
        return False

    # 弃掉
    player.card_hand.remove(target)
    player.card_dis.append(target)
    print(f"  柳林风声：{player.name} 弃掉 [{target.name}]")

    opponent = game.p2 if player == game.p1 else game.p1

    # 创建5T复制卡
    shadow_card = MinionCard(
        name=target.name,
        owner=opponent,
        cost=Cost(t=5),
        targets=target.targets,
        attack=target.attack,
        health=target.health,
        special=target.special,
        keywords=dict(target.keywords) if target.keywords else {},
    )
    shadow_card.pack = getattr(target, "pack", None)
    shadow_card._liulin_shadow = True

    opponent.add_card_to_hand(shadow_card, game=game, emit_events=False)

    # deploy_hook：对方部署异象时触发
    def deploy_hook(minion):
        sc = getattr(minion, "source_card", None)
        # 检查是否是复制卡本身被部署
        if sc is shadow_card or getattr(sc, "_liulin_shadow", False):
            if deploy_hook in game.deploy_hooks:
                game.deploy_hooks.remove(deploy_hook)
            print(f"  柳林风声：{opponent.name} 手动部署了复制卡，效果不触发")
            return

        # 对方部署了其它异象，将复制卡加入友方区域
        if shadow_card in opponent.card_hand:
            opponent.card_hand.remove(shadow_card)
            valid_positions = empty_positions(player, game.board)
            if valid_positions:
                deploy_pos = random.choice(valid_positions)
                shadow_minion = Minion(
                    name=shadow_card.name,
                    owner=player,
                    position=deploy_pos,
                    attack=shadow_card.attack,
                    health=shadow_card.health,
                    source_card=shadow_card,
                    board=game.board,
                    keywords=dict(shadow_card.keywords) if shadow_card.keywords else {},
                )
                game.board.place_minion(shadow_minion, deploy_pos)
                shadow_minion.summon_turn = game.current_turn
                print(f"  柳林风声：{shadow_card.name} 加入 {player.name} 友方区域 {deploy_pos}")
            else:
                print(f"  柳林风声：{player.name} 友方区域无空位，复制卡被弃置")
        else:
            print(f"  柳林风声：复制卡已不在 {opponent.name} 手牌中")

        # 只触发一次，移除钩子
        if deploy_hook in game.deploy_hooks:
            game.deploy_hooks.remove(deploy_hook)

    game.deploy_hooks.append(deploy_hook)
    print(f"  柳林风声：已注册部署钩子")
    return True

def _hesheng_effect(player, target, game, extras=None):
    """贺胜：展示牌库顶4张，抽取最高费的一张，使其花费为0T。"""
    from card_pools.effect_utils import peek_deck_top, place_at_deck_bottom
    from tards.cost import Cost

    candidates = peek_deck_top(player, 4)
    if not candidates:
        print("  贺胜：牌库为空")
        return True

    # 展示
    for c in candidates:
        c._shown_to_opponent = True
    names = ", ".join([f"[{c.name}]" for c in candidates])
    print(f"  贺胜：{player.name} 牌库顶展示 {len(candidates)} 张：{names}")

    # 找最高费
    def _cost_total(card):
        c = card.cost
        return c.t + c.c + c.b + c.s + c.ct + sum(c.minerals.values())

    best = max(candidates, key=_cost_total)
    print(f"  贺胜：最高费为 [{best.name}]")

    # 费用T设为0
    best.cost.t = 0
    print(f"  贺胜：[{best.name}] T花费设为 0")

    # 从牌库移除并加入手牌
    player.card_deck.remove(best)
    player.add_card_to_hand(best, game=game, emit_events=False)

    # 其余置底
    remaining = [c for c in candidates if c is not best]
    if remaining:
        place_at_deck_bottom(player, remaining)

    return True

@strategy
def _shanqian_effect(player, target, game, extras=None):
    """善潜：使一个异象立刻成长，然后+1/+1。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "善潜：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  善潜：目标无效")
        return False
    from tards.cards import Minion

    if not isinstance(target, Minion) or not target.is_alive():
        print("  善潜：目标不合法")
        return False

    pos = target.position
    success = target.evolve(game)
    if success:
        new_minion = game.board.get_minion_at(pos)
        if new_minion and new_minion.is_alive():
            new_minion.gain_attack(1, permanent=True)
            new_minion.gain_health_bonus(1, permanent=True)
            print(f"  善潜：{new_minion.name} +1/+1")
    else:
        print(f"  善潜：{target.name} 无法成长")

    return True

@strategy
def _culi_effect(player, target, game, extras=None):
    """粗粝：使1个异象获得：成长时，+2/2。"""
    from tards.targeting import TargetingRequest
    from tards.cards import Minion

    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = player
    req.scope_fn = scope
    req.prompt = "粗粝：选择1个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    if not isinstance(target, Minion) or not target.is_alive():
        print("  粗粝：目标无效")
        return False
    from tards.cards import Minion

    if not isinstance(target, Minion) or not target.is_alive():
        print("  粗粝：目标不合法")
        return False

    target._on_evolve_buff = (2, 2)
    print(f"  粗粝：{target.name} 获得成长时+2/+2")
    return True


@strategy
def _xinyue_effect(player, target, game, extras=None, card=None):
    """新月：你获得：阴谋的花费-1T。你的阴谋每被触发2次，不论何处，将此卡加入你的手牌（被移除除外）。"""
    from tards.cards import Conspiracy
    from tards.constants import EVENT_CONSPIRACY_TRIGGERED

    # --- 1. 阴谋花费-1T（持续费用修正）---
    def _conspiracy_cost_modifier(c, cost):
        if isinstance(c, Conspiracy):
            cost.t = max(0, cost.t - 1)

    player._cost_modifiers.append(_conspiracy_cost_modifier)
    print(f"  新月：{player.name} 的阴谋花费-1T")

    # --- 2. 阴谋触发计数与回收 ---
    if card is None:
        print("  新月：警告，未获取到策略卡实例，回收效果未注册")
        return True

    player._xinyue_conspiracy_count = getattr(player, "_xinyue_conspiracy_count", 0)

    def _on_conspiracy_triggered(event_data):
        triggered_player = event_data.get("player")
        if triggered_player is not player:
            return

        player._xinyue_conspiracy_count += 1
        print(f"  新月：{player.name} 的阴谋被触发（{player._xinyue_conspiracy_count}/2）")

        if player._xinyue_conspiracy_count < 2:
            return

        # 达到2次，重置计数
        player._xinyue_conspiracy_count = 0

        # 检查新月当前位置
        loc = getattr(card, "_location", None)

        if loc == "exile":
            print(f"  新月：此卡已被移除，无法加入手牌")
            return

        if loc == "hand":
            print(f"  新月：此卡已在手牌中")
            return

        # 从牌库或弃牌堆中取出
        if loc == "deck" and card in player.card_deck:
            player.card_deck.remove(card)
        elif loc == "discard" and card in player.card_dis:
            player.card_dis.remove(card)
        elif loc == "resolving":
            # 正在结算中（极罕见），不处理
            print(f"  新月：此卡正在结算中，暂不移入")
            return
        else:
            # 位置未知或已不在标准区域，尝试在牌库/弃牌堆中查找
            if card in player.card_deck:
                player.card_deck.remove(card)
            elif card in player.card_dis:
                player.card_dis.remove(card)
            else:
                print(f"  新月：未找到此卡，无法加入手牌")
                return

        # 加入手牌（手牌满则弃置）
        player.add_card_to_hand(card, game=game, emit_events=False)

    card.on(EVENT_CONSPIRACY_TRIGGERED, _on_conspiracy_triggered)
    print(f"  新月：已注册阴谋触发监听器")
    return True
# =============================================================================
# 迁移的 lambda 效果 (underworld)
# =============================================================================

def _fushu_special(p, t, g, extras=None):
    return g.develop_card(p, p.original_deck_defs)

def _biyi_special(p, t, g, extras=None):
    return g.develop_card(p, [c for c in DEFAULT_REGISTRY.all_cards() if c.pack == Pack.UNDERWORLD and c.card_type == CardType.CONSPIRACY])

def _jinyangpi_effect(p, t, g, extras=None):
    return g.develop_card(p, [c for c in DEFAULT_REGISTRY.all_cards() if c.pack == Pack.UNDERWORLD and c.rarity == Rarity.GOLD and c.card_type == CardType.MINION])

_shudong_targets = target("position", friendly=True, empty=True)




def _pimaoshang_choice(player, board):
    return ["抽2张异象", "获得4T"]




_lieren_targets = target("hand")




_yanping_targets = target("column", range=[0, 1, 2, 3, 4])




def _shalou_cost_modifier(card, cost):
    owner = getattr(card, "owner", None)
    if owner and len(owner.card_hand) <= 3:
        cost.t = max(0, cost.t - 2)




_shizhong_targets = target("hand", card_type="minion", custom_filter=lambda c: convert_cost_to_t(c.cost) <= 7)




_muqi_targets = target("minion", friendly=True, enemy=False, custom_filter=lambda m: getattr(m, "statue_top", False) or getattr(m, "statue_bottom", False))




_make_targets = target_mix(target("minion"), target("player", enemy=True))




_shanhong_targets = target("column", range=[0, 1, 2, 3])










def _gaozhi_cost_modifier(card, cost):
    player = getattr(card, "owner", None)
    if not player:
        return
    game = getattr(getattr(player, "board_ref", None), "game_ref", None)
    if not game:
        return
    from card_pools.effect_utils import minions_deployed_this_turn
    count = minions_deployed_this_turn(game, player)
    if count > 0:
        cost.t = max(0, cost.t - count)
        print(f"  稿纸费用：本回合部署 {count} 个异象，费用-{count}T")






_zhenban_targets = target("hand")




_haichen_targets = target("minion", injured=True)




_yehuo_targets = target("hand")


_yehuo_minion_choice = target("minion")




_lunhui_targets = target("hand")


_lunhui_target_choice = target_mix(target("minion", friendly=False, enemy=True), target("player", enemy=True))




_gengti_targets = target("hand", card_type="minion", custom_filter=lambda c: getattr(c, "echo_level", 0) > 0)




_liulinfengsheng_targets = target("hand", card_type="minion")






# =============================================================================
# 食蚁兽
# =============================================================================

def _shiyi_shou_join_battlefield(player, game, card):
    """将食蚁兽从当前区域（手牌/弃牌堆/牌库）移除，并加入战场。"""
    from card_pools.effect_utils import empty_positions, summon_minion_by_name

    # 从当前区域移除（如果还在的话）
    if card in player.card_hand:
        player.card_hand.remove(card)
    elif card in player.card_dis:
        player.card_dis.remove(card)
    elif card in player.card_deck:
        player.card_deck.remove(card)
    # 否则：卡已经被从区域中移除了（如 remove_top_of_deck 的 pop），无需再移除

    # 找合法空位
    valid = empty_positions(player, game.board)
    if not valid:
        print("  食蚁兽：没有合法空位，无法加入战场")
        player.card_dis.append(card)
        return

    import random
    pos = random.choice(valid)

    # 召唤到战场（会触发 special_fn，即部署效果）
    new_minion = summon_minion_by_name(game, "食蚁兽", player, pos)
    if new_minion:
        print(f"  食蚁兽：从弃置/移除加入战场 {pos}")
        # 成功部署后注销原卡牌的监听器
        game.history.unlisten_by_owner(card)
    else:
        # 部署失败，放回弃牌堆
        player.card_dis.append(card)


def _shiyi_shou_draw_trigger(player, game, card):
    """食蚁兽抽取触发器：注册被弃掉/从牌库移除时的监听器。"""

    def on_discarded(event, _game):
        discarded = event.data.get("card")
        if discarded is not card:
            return
        # 确保卡确实在弃牌堆中（可能被其他效果提前移走）
        if card not in player.card_dis:
            return
        _shiyi_shou_join_battlefield(player, _game, card)

    def on_removed_from_deck(event, _game):
        removed = event.data.get("card")
        if removed is not card:
            return
        _shiyi_shou_join_battlefield(player, _game, card)

    game.history.listen(EVENT_DISCARDED, on_discarded, owner=card)
    game.history.listen("card_removed_from_deck", on_removed_from_deck, owner=card)


@special
def _shiyi_shou_special(minion, player, game, extras=None):
    """食蚁兽：部署：双方随机弃一张牌。"""
    import random

    # 己方随机弃一张牌
    if player.card_hand:
        card = random.choice(player.card_hand)
        player.discard_card(card, game, reason="effect")
        print(f"  食蚁兽：{player.name} 随机弃掉 {card.name}")

    # 敌方随机弃一张牌
    opponent = game.p1 if player == game.p2 else game.p2
    if opponent.card_hand:
        card = random.choice(opponent.card_hand)
        opponent.discard_card(card, game, reason="effect")
        print(f"  食蚁兽：{opponent.name} 随机弃掉 {card.name}")

    return True


# =============================================================================
# 头鹿
# =============================================================================

@special
def _tou_lu_special(minion, player, game, extras=None):
    """头鹿：你的手牌花费-1T。成长时，若场上有B=0异象，改为重置计时。"""

    # === 效果1：手牌花费-1T ===
    def cost_modifier(card, cost):
        cost.t = max(0, cost.t - 1)

    player._cost_modifiers.append(cost_modifier)
    minion._tou_lu_cost_modifier = cost_modifier

    # 保存原始成长值，用于重置计时
    minion._tou_lu_original_grow = minion.keywords.get("成长", 2)

    # === 效果2：成长时检查场上是否有B=0异象 ===
    def on_grow(m, p, g):
        # B=0 异象：部署费用中不含 B 点（cost.b == 0）
        has_b0 = any(
            target.is_alive()
            and target.source_card
            and target.source_card.cost.b == 0
            for target in g.board.get_minions_of_player(p)
        )
        if has_b0:
            original = getattr(m, "_tou_lu_original_grow", 2)
            m.keywords["成长"] = original
            print(f"  头鹿：场上有B=0异象，成长计时重置为 {original}")
            return True  # 取消本次成长
        return False

    minion._on_grow_callbacks = getattr(minion, "_on_grow_callbacks", [])
    minion._on_grow_callbacks.append(on_grow)

    # === 清理：死亡/移除时移除费用修正器 ===
    def cleanup():
        mod = getattr(minion, "_tou_lu_cost_modifier", None)
        if mod and mod in player._cost_modifiers:
            player._cost_modifiers.remove(mod)
            print(f"  头鹿离场：手牌费用-1T修正移除")

    def on_death(event):
        if event.data.get("minion") is minion:
            cleanup()

    def on_removed(event):
        if event.data.get("minion") is minion:
            cleanup()

    on("death", on_death, game, minion=minion)
    on("removed", on_removed, game, minion=minion)

    return True


# =============================================================================
# 老鹿
# =============================================================================

def _lao_lu_apply(minion, player, game):
    """老鹿核心效果：手牌花费+1T。"""
    def cost_modifier(card, cost):
        cost.t += 1

    player._cost_modifiers.append(cost_modifier)
    minion._lao_lu_cost_modifier = cost_modifier

    # 清理：死亡/移除时移除费用修正器
    def cleanup():
        mod = getattr(minion, "_lao_lu_cost_modifier", None)
        if mod and mod in player._cost_modifiers:
            player._cost_modifiers.remove(mod)
            print(f"  老鹿离场：手牌费用+1T修正移除")

    def on_death(event):
        if event.data.get("minion") is minion:
            cleanup()

    def on_removed(event):
        if event.data.get("minion") is minion:
            cleanup()

    on("death", on_death, game, minion=minion)
    on("removed", on_removed, game, minion=minion)


@special
def _lao_lu_special(minion, player, game, extras=None):
    """老鹿：你的手牌花费+1T。具有虚化（通过 keywords 实现）。"""
    _lao_lu_apply(minion, player, game)
    return True


def _lao_lu_evolve(new_minion, player, game):
    """老鹿进化回调。"""
    _lao_lu_apply(new_minion, player, game)


# =============================================================================
# 鼯鼱
# =============================================================================

def _wujing_effect(player, target, game, extra_targets=None, card=None):
    """鼯鼱：必须是本轮部署的第一个异象。"""
    from card_pools.effect_utils import minions_deployed_this_turn
    from tards.cards import _default_minion_effect

    if minions_deployed_this_turn(game, player) > 0:
        print("  鼯鼱：本回合已部署过异象，无法部署")
        return False

    return _default_minion_effect(player, target, game, extra_targets or [], card)


# =============================================================================
# 豺
# =============================================================================

@special
def _chai_special(minion, player, game, extras=None):
    """豺：部署：失去1个T槽。亡语：所有手牌花费-1T。"""

    # 效果1：失去1个T槽
    player.t_point_max_change(-1)
    print(f"  豺：{player.name} 失去1个T槽，当前T槽上限 {player.t_point_max}")

    # 效果2：亡语 - 当前手牌花费-1T
    def _chai_deathrattle(m, p, b):
        for card in list(p.card_hand):
            if hasattr(card, "cost") and card.cost:
                card.cost.t = max(0, card.cost.t - 1)
        print(f"  豺亡语：{p.name} 当前手牌花费-1T")

    add_deathrattle(minion, _chai_deathrattle)

    return True


# =============================================================================
# 追猎者
# =============================================================================

@special
def _zhuiliezhe_special(minion, player, game, extras=None):
    """追猎者：部署：指向一个不处于本列的异象。亡语：将其消灭。"""
    from tards.targeting import TargetingRequest

    # 部署效果：指向一个不处于本列的异象
    my_col = minion.position[1]

    def scope(p, board):
        return [m for m in board.minion_place.values()
                if m.is_alive() and m.position[1] != my_col]

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = "追猎者：选择一个不处于本列的异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False  # 取消 → 自动回滚

    minion._zhuilie_target = target
    print(f"  追猎者：锁定 {target.name}")

    # 亡语：消灭目标
    def _zhuilie_deathrattle(m, p, b):
        t = getattr(m, "_zhuilie_target", None)
        if t and t.is_alive():
            destroy_minion(t, game)
            print(f"  追猎者亡语：消灭 {t.name}")

    add_deathrattle(minion, _zhuilie_deathrattle)

    return True


# =============================================================================
# 木鹊
# =============================================================================

@special
def _muque_special(minion, player, game, extras=None):
    """木鹊：你的手牌花费-1B。回合结束：若本回合对手受到的伤害累计不小于3，你获得1B。"""

    # === 效果1：手牌花费-1B ===
    def cost_modifier(card, cost):
        cost.b = max(0, cost.b - 1)

    player._cost_modifiers.append(cost_modifier)
    minion._muque_cost_modifier = cost_modifier

    # === 清理：死亡/移除时移除费用修正器 ===
    def cleanup():
        mod = getattr(minion, "_muque_cost_modifier", None)
        if mod and mod in player._cost_modifiers:
            player._cost_modifiers.remove(mod)
            print(f"  木鹊离场：手牌费用-1B修正移除")

    def on_death(event):
        if event.data.get("minion") is minion:
            cleanup()

    def on_removed(event):
        if event.data.get("minion") is minion:
            cleanup()

    on("death", on_death, game, minion=minion)
    on("removed", on_removed, game, minion=minion)

    # === 效果2：回合结束时检查对手本回合受到的伤害 ===
    def on_turn_end_fn(event):
        if not minion.is_alive():
            return

        opponent = game.p1 if player == game.p2 else game.p2

        from tards.constants import EVENT_PLAYER_DAMAGE
        damage_events = game.history.query_events(
            turn=game.current_turn,
            event_type=EVENT_PLAYER_DAMAGE,
            filter_fn=lambda e: e.get("player") is opponent,
        )
        total_damage = sum(e.get("damage", 0) for e in damage_events)

        if total_damage >= 3:
            player.b_point_change(1)
            print(f"  木鹊：本回合对手受到 {total_damage} 点伤害，{player.name} 获得 1B")

    def on_phase_end_fn(event):
        if event.data.get("phase") != game.PHASE_RESOLVE:
            return
        on_turn_end_fn(event)

    game.history.listen(EVENT_PHASE_END, on_phase_end_fn, owner=minion)

    return True


# =============================================================================
# 牛虻
# =============================================================================

@special
def _niufeng_special(minion, player, game, extras=None):
    """牛虻：敌方目标被指向后，也算作是被本异象指向。
    回合开始：使所有被本异象指向的目标失去1点HP。
    部署：指向一个目标。
    """
    opponent = game.p1 if player == game.p2 else game.p2
    minion._niufeng_targets = set()

    # === 被动监听：敌方目标被指向后计入牛虻目标列表 ===
    def on_targeting_completed(event, g):
        t = event.data.get("target")
        if t is None:
            return
        # 只记录敌方目标
        if hasattr(t, "owner"):
            if t.owner == player:
                return
        elif t is player:
            return
        minion._niufeng_targets.add(t)
        print(f"  牛虻：{getattr(t, 'name', t)} 被指向，加入目标列表")

    game.history.listen("targeting_completed", on_targeting_completed, owner=minion)

    # === 部署：指向一个目标 ===
    from tards.targeting import TargetingRequest

    def scope(p, board):
        candidates = list(board.minion_place.values())
        candidates.append(opponent)
        return candidates

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = "牛虻：指向一个目标"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        # 取消部署，清理已注册的监听器
        game.history.unlisten_by_owner(minion)
        return False

    minion._niufeng_targets.add(target)
    print(f"  牛虻：部署指向 {getattr(target, 'name', target)}")

    # === 回合开始：所有被指向的目标失去1点HP ===
    def on_turn_start_fn(event, g):
        if not minion.is_alive():
            return

        for t in list(minion._niufeng_targets):
            # 跳过已死亡目标
            if hasattr(t, "is_alive") and not t.is_alive():
                continue
            # 玩家目标：使用 lose_hp
            if hasattr(t, "lose_hp"):
                t.lose_hp(1)
            # 异象目标：直接扣血
            elif hasattr(t, "current_health"):
                t.current_health -= 1
                print(f"  牛虻：{getattr(t, 'name', t)} 失去 1 点HP")
                if t.current_health <= 0 and t.is_alive():
                    t.minion_death()

    from tards.constants import EVENT_TURN_START
    game.history.listen(EVENT_TURN_START, on_turn_start_fn, owner=minion)

    return True


# =============================================================================
# 野牛
# =============================================================================

@special
def _yeniue_special(minion, player, game, extras=None):
    """野牛：攻击目标的HP不大于3时，本异象具有串击。

    实现方式：在 before_attack 时根据实时目标HP动态注入/移除 temp_keywords["串击"]，
    让 attack_target() 内部的串击逻辑自然接管；after_attack 时清理，避免残留。
    """

    def on_before_attack(event, g):
        if event.data.get("attacker") is not minion:
            return
        target = event.data.get("target")
        # 目标HP <= 3 时赋予串击
        if target and hasattr(target, "current_health") and target.current_health <= 3:
            minion.temp_keywords["串击"] = True
            minion.recalculate()
            print(f"  野牛：目标 {target.name} HP为{target.current_health}，获得串击")
        else:
            if "串击" in minion.temp_keywords:
                del minion.temp_keywords["串击"]
                minion.recalculate()

    def on_after_attack(event, g):
        if event.data.get("attacker") is not minion:
            return
        if "串击" in minion.temp_keywords:
            del minion.temp_keywords["串击"]
            minion.recalculate()

    on("before_attack", on_before_attack, game, minion=minion)
    on("after_attack", on_after_attack, game, minion=minion)

    return True


# =============================================================================
# 跳蛛
# =============================================================================

@special
def _tiaozhu_special(minion, player, game, extras=None):
    """跳蛛：直到本异象被部署的出牌阶段结束，友方异象部署时，本异象失去迅捷。
    你部署献祭点数大于0的异象时，对对手造成1点伤害。
    """
    opponent = game.p1 if player == game.p2 else game.p2
    minion._tiaozhu_deploy_turn = game.current_turn

    def on_deployed(event, g):
        deployed = event.data.get("minion")
        card = event.data.get("card")
        if not deployed or deployed.owner != player:
            return

        # 效果1：部署当回合的出牌阶段内，友方异象部署时跳蛛失去迅捷
        if deployed is not minion:
            if g.current_turn == minion._tiaozhu_deploy_turn and g.current_phase == g.PHASE_ACTION:
                if "迅捷" in minion.base_keywords:
                    del minion.base_keywords["迅捷"]
                    minion.recalculate()
                    print(f"  跳蛛：友方异象 {deployed.name} 部署，跳蛛失去迅捷")

        # 效果2：部署献祭点数>0的异象时，对对手造成1点伤害
        if card and hasattr(card, "cost") and card.cost.b > 0:
            opponent.health_change(-1, source=deployed)
            print(f"  跳蛛：部署 {deployed.name}（献祭{card.cost.b}B），对 {opponent.name} 造成1点伤害")

    game.history.listen(EVENT_DEPLOYED, on_deployed, owner=minion)

    return True


@special
def _sheshei_special(minion, player, game, extras=None):
    """射水鱼：对空袭与昆虫异象伤害翻倍。受到本异象伤害的异象本回合改为在回合结束时攻击。"""
    from tards.cards import Minion
    from card_pools.effect_utils import perform_attack_action

    # 追踪本结算阶段已经攻击过的异象
    _attacked_this_phase: set = set()
    _delayed_targets: list = []

    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        _attacked_this_phase.clear()
        _delayed_targets.clear()

    def on_after_attack(event, g):
        attacker = event.data.get("attacker")
        if attacker and isinstance(attacker, Minion):
            _attacked_this_phase.add(id(attacker))

    def on_before_damage(event, g):
        if not minion.is_alive():
            return
        source = event.data.get("source_minion")
        if source is not minion:
            return
        target = event.data.get("target")
        if not isinstance(target, Minion) or target is minion:
            return
        if not target.is_alive():
            return

        # 效果1：对空袭与昆虫异象伤害翻倍
        is_air = target.keywords.get("空袭", False)
        is_insect = "昆虫" in getattr(target, "tags", [])
        if is_air or is_insect:
            old_damage = event.data.get("damage", 0)
            event.data["damage"] = old_damage * 2
            tag_str = ""
            if is_air:
                tag_str += "空袭"
            if is_air and is_insect:
                tag_str += "/"
            if is_insect:
                tag_str += "昆虫"
            print(f"  射水鱼：{target.name} 为 {tag_str} 异象，伤害从 {old_damage} 翻倍至 {old_damage * 2}")

        # 效果2：若目标未攻击过，推迟攻击
        if id(target) not in _attacked_this_phase and not getattr(target, "_sheshei_delayed", False):
            target._sheshei_delayed = True
            target._skip_resolve_attack = True
            _delayed_targets.append(target)
            print(f"  射水鱼：{target.name} 的攻击被推迟至回合结束")

    def on_phase_end(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        if not _delayed_targets:
            return

        print(f"  [射水鱼延迟攻击] 共 {len(_delayed_targets)} 个异象")
        for target in list(_delayed_targets):
            if not target.is_alive():
                continue

            # 清除跳过标志，执行攻击
            target._skip_resolve_attack = False
            perform_attack_action(target, g)

            # 清理标记
            target._skip_resolve_attack = False
            target._sheshei_delayed = False

        _delayed_targets.clear()
        _attacked_this_phase.clear()

    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    game.history.listen(EVENT_AFTER_ATTACK, on_after_attack, owner=minion)
    game.history.listen(EVENT_BEFORE_DAMAGE, on_before_damage, owner=minion)
    game.history.listen(EVENT_PHASE_END, on_phase_end, owner=minion)
    return True


@special
def _guan_special(minion, player, game, extras=None):
    """鹳：将其消灭的异象的回响加入手牌。"""

    def on_after_destroy(event, g):
        destroyed = event.data.get("minion")
        if not destroyed or destroyed is minion:
            return
        if not minion.is_alive():
            return

        # 检查被消灭异象的最后一击来源是否是鹳
        last_source = getattr(destroyed, "_last_damage_source", None)
        if last_source is not minion:
            return

        # 获取源卡创建回响
        source_card = getattr(destroyed, "source_card", None)
        if not source_card:
            return

        echo = create_echo_card(source_card, echo_level=1)
        echo.owner = player

        player.add_card_to_hand(echo, game=game, emit_events=False)

    game.history.listen(EVENT_AFTER_DESTROY, on_after_destroy, owner=minion)
    return True


@special
def _yan_special(minion, player, game, extras=None):
    """燕：部署：失去一个T槽。"""
    player.t_point_max_change(-1)
    print(f"  燕：{player.name} 失去1个T槽，当前T槽上限 {player.t_point_max}")
    return True


def _mang_effect(player, target, game, extra_targets=None, card=None):
    """蟒：必须是本回合双方部署的第2个异象。"""
    from tards.cards import _default_minion_effect
    from tards.constants import EVENT_DEPLOYED

    current_turn = getattr(game, "current_turn", 0)
    deployed = game.history.query_events(
        turn=current_turn,
        event_type=EVENT_DEPLOYED,
    )
    total_deployed = len(deployed)
    if total_deployed != 1:
        print(f"  蟒：本回合已部署 {total_deployed} 个异象，无法部署（必须是第2个）")
        return False

    return _default_minion_effect(player, target, game, extra_targets or [], card)


@special
def _mang_special(minion, player, game, extras=None):
    """蟒：亡语：若消灭过异象，随机消灭一个敌方异象。"""
    from card_pools.effect_utils import destroy_minion
    import random

    minion._has_killed = False

    # 追踪消灭
    def on_after_destroy(event, g):
        if not minion.is_alive():
            return
        destroyed = event.data.get("minion")
        if not destroyed:
            return
        last_source = getattr(destroyed, "_last_damage_source", None)
        if last_source is not minion:
            return
        if not minion._has_killed:
            minion._has_killed = True
            print(f"  蟒：已消灭 {destroyed.name}，亡语条件达成")

    # 亡语
    def deathrattle(m, p, g):
        if not getattr(m, "_has_killed", False):
            print(f"  蟒亡语：未消灭过异象，不触发")
            return
        enemies = [e for e in g.board.minion_place.values() if e.is_alive() and e.owner != p]
        if not enemies:
            print(f"  蟒亡语：场上无敌方异象")
            return
        target = random.choice(enemies)
        destroy_minion(target, g)
        print(f"  蟒亡语：随机消灭 {target.name}")

    game.history.listen(EVENT_AFTER_DESTROY, on_after_destroy, owner=minion)
    add_deathrattle(minion, deathrattle)
    return True


@special
def _xuebao_special(minion, player, game, extras=None):
    """雪豹：部署：将1个花费不大于2T的异象移动至友方区域。"""
    from tards.targeting import TargetingRequest
    import random

    def scope(p, board):
        targets = []
        for m in board.minion_place.values():
            if not m.is_alive():
                continue
            if m.owner == p:
                continue
            source_card = getattr(m, "source_card", None)
            if not source_card:
                continue
            cost_t = convert_cost_to_t(source_card.cost)
            if cost_t <= 2:
                targets.append(m)
        return targets

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = "雪豹：选择一个花费不大于2T的敌方异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    positions = empty_positions(player, game.board)
    if not positions:
        print("  雪豹：友方区域没有空位，无法移动")
        return True

    new_pos = random.choice(positions)
    from card_pools.effect_utils import move
    move(target, new_pos, game, allow_cross_side=True)
    # 改变所有权（策反）
    target.owner = player
    print(f"  雪豹：将 {target.name} 策反至友方区域 {new_pos}")
    return True


@special
def _shuishiyan_special(minion, player, game, extras=None):
    """水螅岩：亡语：若是由于异象效果被消灭，改为在回合结束时成长。"""
    from tards.cards import Minion

    minion._shuishiyan_last_damage_from_minion = False

    def on_before_damage(event, g):
        target = event.data.get("target")
        if target is not minion:
            return
        source = event.data.get("source_minion")
        minion._shuishiyan_last_damage_from_minion = (source is not None and isinstance(source, Minion))

    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        minion._shuishiyan_last_damage_from_minion = False

    def on_before_destroy(event, g):
        if event.data.get("minion") is not minion:
            return
        if not getattr(minion, "_shuishiyan_last_damage_from_minion", False):
            return
        event.cancelled = True
        minion.keywords["成长"] = True
        print(f"  水螅岩：被异象效果消灭，阻止死亡并将在回合结束时成长")

    game.history.listen("before_damage", on_before_damage, owner=minion)
    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    game.history.listen(EVENT_BEFORE_DESTROY, on_before_destroy, owner=minion)
    return True


@special
def _shuixiqun_special(minion, player, game, extras=None):
    """水螅群：抽牌阶段：对方失去3T。"""

    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_DRAW:
            return
        if not minion.is_alive():
            return
        opponent = g.p1 if player == g.p2 else g.p1
        old_t = opponent.t_point
        opponent.t_point = max(0, opponent.t_point - 3)
        lost = old_t - opponent.t_point
        if lost > 0:
            print(f"  水螅群：{opponent.name} 在抽牌阶段失去 {lost}T")

    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    return True


@special
def _yachong_special(minion, player, game, extras=None):
    """蚜虫：亡语：T槽更少的一方失去1个T槽。"""

    def deathrattle(m, p, g):
        opponent = g.p1 if p == g.p2 else g.p2
        p_t = p.t_point_max
        o_t = opponent.t_point_max
        if p_t < o_t:
            p.t_point_max_change(-1)
            print(f"  蚜虫亡语：{p.name} T槽更少，失去1个T槽（当前上限 {p.t_point_max}）")
        elif o_t < p_t:
            opponent.t_point_max_change(-1)
            print(f"  蚜虫亡语：{opponent.name} T槽更少，失去1个T槽（当前上限 {opponent.t_point_max}）")
        else:
            print(f"  蚜虫亡语：双方T槽相同（{p_t}），无效果")

    add_deathrattle(minion, deathrattle)
    return True


@special
def _wen_special(minion, player, game, extras=None):
    """蚊：对方所有异象花费+2T。对方异象部署前，本异象返回手牌。"""
    from tards.cards import MinionCard
    from card_pools.effect_utils import return_minion_to_hand

    opponent = game.p1 if player == game.p2 else game.p1

    # 效果1：对方所有异象花费+2T
    def cost_modifier(card, cost):
        if isinstance(card, MinionCard):
            cost.t += 2

    opponent._cost_modifiers.append(cost_modifier)
    print(f"  蚊：{opponent.name} 所有异象花费+2T")

    # 效果2：对方异象部署前，蚊返回手牌
    def on_before_deploy(event, g):
        if not minion.is_alive():
            return
        deploy_player = event.data.get("player")
        if deploy_player is not opponent:
            return
        card = event.data.get("card")
        if not isinstance(card, MinionCard):
            return

        print(f"  蚊：{opponent.name} 部署 {card.name} 前，蚊返回手牌")
        # 清理费用修饰器
        if cost_modifier in opponent._cost_modifiers:
            opponent._cost_modifiers.remove(cost_modifier)
        # 清理监听器
        g.history.unlisten_by_owner(minion)
        # 返回手牌
        return_minion_to_hand(minion, g)

    # 死亡时清理费用修饰器
    def on_before_destroy(event, g):
        if event.data.get("minion") is not minion:
            return
        if cost_modifier in opponent._cost_modifiers:
            opponent._cost_modifiers.remove(cost_modifier)

    game.history.listen(EVENT_BEFORE_DEPLOY, on_before_deploy, owner=minion)
    game.history.listen(EVENT_BEFORE_DESTROY, on_before_destroy, owner=minion)
    return True


@special
def _luci_special(minion, player, game, extras=None):
    """鸬鹚：友方异象更少时，使所有敌方异象具有-1攻击力。"""

    def debuff_fn(m):
        if not minion.is_alive():
            return 0
        friendly_count = len([x for x in game.board.minion_place.values() if x.is_alive() and x.owner == player])
        enemy_count = len([x for x in game.board.minion_place.values() if x.is_alive() and x.owner != player])
        if friendly_count < enemy_count:
            return -1
        return 0

    # 给所有现存敌方异象添加 aura
    for m in game.board.minion_place.values():
        if m.is_alive() and m.owner != player:
            if debuff_fn not in m._aura_attack_fns:
                m.add_aura_attack(debuff_fn)

    # 监听新部署的敌方异象
    def on_deploy(event, g):
        deployed = event.data.get("minion")
        if deployed and deployed.owner != player and deployed.is_alive():
            if debuff_fn not in deployed._aura_attack_fns:
                deployed.add_aura_attack(debuff_fn)
        # 更新所有敌方异象的攻击力
        for m in game.board.minion_place.values():
            if m.is_alive() and m.owner != player:
                m.recalculate()

    # 监听死亡事件，更新所有敌方异象
    def on_death(event, g):
        for m in game.board.minion_place.values():
            if m.is_alive() and m.owner != player:
                m.recalculate()

    game.history.listen(EVENT_DEPLOYED, on_deploy, owner=minion)
    game.history.listen(EVENT_DEATH, on_death, owner=minion)

    # 死亡时移除 aura
    def on_before_destroy(event, g):
        if event.data.get("minion") is not minion:
            return
        for m in game.board.minion_place.values():
            if m.is_alive() and m.owner != player:
                if debuff_fn in m._aura_attack_fns:
                    m.remove_aura_attack(debuff_fn)

    game.history.listen(EVENT_BEFORE_DESTROY, on_before_destroy, owner=minion)
    return True


@special
def _hu_tiger_special(minion, player, game, extras=None):
    """虎：对方无法使用策略指向友方异象。"""
    player._global_insulation_count = getattr(player, "_global_insulation_count", 0) + 1
    print(f"  虎：{player.name} 的友方异象获得全局绝缘")

    def on_before_destroy(event, g):
        if event.data.get("minion") is not minion:
            return
        player._global_insulation_count = max(0, getattr(player, "_global_insulation_count", 1) - 1)
        if player._global_insulation_count == 0:
            print(f"  虎：{player.name} 的友方异象失去全局绝缘")

    game.history.listen(EVENT_BEFORE_DESTROY, on_before_destroy, owner=minion)
    return True


@special
def _huanxingchong_special(minion, player, game, extras=None):
    """环形虫：部署：指向一个异象。亡语：使指向目标与随机一个敌方异象对战。"""
    from tards.targeting import TargetingRequest
    import random

    # 部署指向
    def scope(p, board):
        return [m for m in board.minion_place.values() if m.is_alive()]

    req = TargetingRequest()
    req.source = minion
    req.scope_fn = scope
    req.prompt = "环形虫：选择一个异象"
    req.deciding_player = player

    target = game.targeting_system.request_target(req)
    if target is None:
        return False

    minion._huanxingchong_target = target
    print(f"  环形虫：记录目标 {target.name}")

    # 亡语
    def deathrattle(m, p, g):
        recorded = getattr(m, "_huanxingchong_target", None)
        if not recorded or not recorded.is_alive():
            print("  环形虫亡语：记录的目标已消失")
            return

        enemies = [e for e in g.board.minion_place.values() if e.is_alive() and e.owner != recorded.owner]
        if not enemies:
            print("  环形虫亡语：记录目标无敌方异象可对战")
            return

        enemy = random.choice(enemies)
        print(f"  环形虫亡语：{recorded.name} 与 {enemy.name} 对战")
        initiate_combat(recorded, enemy, g)

    add_deathrattle(minion, deathrattle)
    return True


@special
def _shiqianzi_special(minion, player, game, extras=None):
    """石钱子：亡语：将一张"断尾"加入原位。"""
    def _dr(m, p, b):
        pos = m.position
        if pos is None:
            print("  石钱子亡语：位置已丢失，无法召唤断尾")
            return
        from card_pools.effect_utils import summon_minion_by_name
        game = b.game_ref if hasattr(b, "game_ref") else None
        result = summon_minion_by_name(game, "断尾", p, pos)
        if result:
            print(f"  石钱子亡语：在原位 {pos} 召唤断尾")
        else:
            print(f"  石钱子亡语：原位 {pos} 被占用，无法召唤断尾")

    add_deathrattle(minion, _dr)
    return True


@special
def _duanwei_special(minion, player, game, extras=None):
    """断尾：回合结束：转换为"石钱子"。"""
    def on_phase_end(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        if not minion.is_alive():
            return
        from card_pools.effect_utils import transform_minion_to
        new_minion = transform_minion_to(minion, "石钱子", g)
        if new_minion:
            # 手动触发石钱子的 special_fn 注册亡语
            from tards.card_db import DEFAULT_REGISTRY
            target_def = DEFAULT_REGISTRY.get("石钱子")
            if target_def:
                next_card = target_def.to_game_card(player)
                if next_card and next_card.special:
                    import inspect
                    sig = inspect.signature(next_card.special)
                    if len(sig.parameters) >= 4:
                        next_card.special(new_minion, player, g, [])
                    else:
                        next_card.special(new_minion, player, g)
            print("  断尾：回合结束转换为石钱子")

    game.history.listen(EVENT_PHASE_END, on_phase_end, owner=minion)
    return True


@special
def _yixue_special(minion, player, game, extras=None):
    """蚁穴：场上有昆虫类异象时，HP无法降至1以下。回合开始：将1张"兵蚁"加入战场。"""

    # 效果1：场上有昆虫时，HP无法降至1以下
    def on_before_damage(event):
        if not minion.is_alive():
            return
        if event.data.get("target") is not minion:
            return
        # 检查场上是否有存活昆虫异象
        has_insect = any(
            "昆虫" in getattr(m, "tags", [])
            for m in game.board.minion_place.values()
            if m.is_alive()
        )
        if not has_insect:
            return

        damage = event.data.get("damage", 0)
        if damage <= 0:
            return

        tough = minion.keywords.get("坚韧", 0)
        if isinstance(tough, int):
            actual = max(0, damage - tough)
        else:
            actual = damage

        if actual >= minion.current_health:
            # 调整伤害，使HP不低于1
            if isinstance(tough, int):
                event.data["damage"] = max(0, minion.current_health - 1 + tough)
            else:
                event.data["damage"] = max(0, minion.current_health - 1)
            print(f"  蚁穴：场上有昆虫，HP无法降至1以下")

    game.history.listen(EVENT_BEFORE_DAMAGE, on_before_damage, owner=minion)

    # 效果2：回合开始（拥有者回合）召唤兵蚁
    def on_phase_start(event, g):
        if event.data.get("phase") != g.PHASE_RESOLVE:
            return
        if event.data.get("first") is not player:
            return
        if not minion.is_alive():
            return

        from card_pools.effect_utils import empty_positions, summon_minion_by_name
        empties = empty_positions(player, g.board)
        if not empties:
            print("  蚁穴：没有友方空位，无法召唤兵蚁")
            return

        pos = empties[0]
        result = summon_minion_by_name(g, "兵蚁", player, pos)
        if result:
            print(f"  蚁穴：在 {pos} 召唤兵蚁")

    game.history.listen(EVENT_PHASE_START, on_phase_start, owner=minion)
    return True


@special
def _liegou_special(minion, player, game, extras=None):
    """鬣狗：将其消灭的异象的回响加入手牌。你打出或弃掉回响时，本异象返回手牌。"""
    from card_pools.effect_utils import create_echo_card, return_minion_to_hand

    # 效果1：消灭异象 → 回响加入手牌
    def on_after_destroy(event, g):
        destroyed = event.data.get("minion")
        if not destroyed or destroyed is minion:
            return
        if not minion.is_alive():
            return

        last_source = getattr(destroyed, "_last_damage_source", None)
        if last_source is not minion:
            return

        source_card = getattr(destroyed, "source_card", None)
        if not source_card:
            return

        echo = create_echo_card(source_card, echo_level=1)
        echo.owner = player

        player.add_card_to_hand(echo, game=game, emit_events=False)

    # 效果2：打出或弃掉回响 → 鬣狗返回手牌
    def on_card_played_or_discarded(event, g):
        if not minion.is_alive():
            return
        # 只响应鬣狗主人的动作
        evt_player = event.data.get("player")
        if evt_player is not player:
            return
        card = event.data.get("card")
        if not card:
            return
        # 检查是否为回响卡
        if not getattr(card, "_is_echo", False):
            return

        print(f"  鬣狗：{player.name} 打出/弃掉回响 [{card.name}]，鬣狗返回手牌")
        return_minion_to_hand(minion, g)

    game.history.listen(EVENT_AFTER_DESTROY, on_after_destroy, owner=minion)
    game.history.listen(EVENT_CARD_PLAYED, on_card_played_or_discarded, owner=minion)
    game.history.listen(EVENT_DISCARDED, on_card_played_or_discarded, owner=minion)
    return True
